# MTS Governance v1.1 — 可执行 Agent 架构

本文件是 MTS 的现行运行规范，替代 v1.0 作为新的决策和系统实现基准。v1.0 保留为历史制度记录，不被覆盖。v1.1 的目标是把“部门隔离、独立认证、冲突暂缓、可审计”落实为系统强制约束，而不是依赖 Agent 自觉。

## 1. 系统边界与最高规则

MTS 是研究、投资决策和交易治理系统；它不是自动下单授权，也不能取代法定负责人、持牌机构、交易所规则或人工合规审批。

以下规则不可由任何 Agent、管理层或临时指令覆盖：

1. Research、Trading、Risk、Compliance、Execution 使用独立身份、独立上下文和最小权限工具集。
2. 研究结论不是交易批准；交易信号不是研究事实；盈利结果不是事前证据。
3. Risk 和 Compliance 的硬否决不可被 Management 覆盖。
4. Research 与 Trading 的未解决冲突一律进入 `CONFLICT_HOLD`，禁止下单。
5. 所有状态变化、证据引用、工具调用和人工决定必须记录为 Markdown/Excel 台账；历史记录以新增记录方式更正，不覆盖原条目。
6. 自动化只能在明确的、未过期的、已批准交易授权范围内执行；默认行为是 `NO_ACTION`。

## 2. 组织与独立性

```text
                         Management / Decision Council
                                      │
        ┌─────────────────────────────┼─────────────────────────────┐
        │                             │                             │
Research Department            Trading Department          Independent Control
├─ Market Research             ├─ Strategy                 ├─ Risk
├─ Industry Research           ├─ Technical Setup          ├─ Compliance
│  └─ industry-chain-research  ├─ Portfolio Construction   ├─ Red Team
├─ Company Research            └─ Execution Proposal       ├─ Audit
└─ Quant / Data Validation                                  └─ Monitoring
                                                                    │
                                                             Execution Service
```

`Portfolio Construction` 属于 Trading Department，只能根据 Risk 已批准的预算形成组合建议；它不是 Risk。`Execution Service` 只接收已批准且未过期的订单意图，不属于任何研究、交易或管理 Agent 的可写范围。

### 2.1 部门职责边界

| 部门 | 唯一职责 | 可输出 | 明确禁止 |
|---|---|---|---|
| Research | 发现、解释、验证产业与公司事实 | Research Package、Claims、Watchlist | 下单、批准、设置仓位 |
| Trading | 将独立信息转为某策略的可执行提案 | Trading Proposal、执行参数 | 改写研究、认证基本面、成交 |
| Risk | 约束损失、暴露、相关性与可执行风险 | `PASS/REDUCE/REJECT/HALT` | 选股、提高仓位、批准研究 |
| Compliance | 检查法律、授权、限制与信息隔离 | `CLEAR/HOLD/REJECT` | 交易方向判断、覆盖 Risk |
| Red Team | 独立提出最强反证与失败路径 | Challenge Report | 修改 Thesis、选择标的 |
| Management | 在已锁定材料上作统一决策 | `APPROVE/HOLD/RETURN/REJECT` | 补写证据、覆盖 Risk/Compliance |
| Execution | 在市场条件合格时执行已批准意图 | `FILLED/PARTIAL/NO_FILL/CANCEL` | 改变方向、仓位、止损或授权 |

## 3. Agent 身份、上下文与工具隔离

每一个运行 Agent 必须携带不可复用的 `agent_id`、部门、角色、模型版本、Prompt 版本、权限策略版本和会话 ID。Agent 不能仅靠名称切换部门角色。

### 3.1 强制访问策略

```text
Research Agent    → 可写 Research/Evidence Ledger；只读市场数据
Trading Agent     → 只读已发布 Research Package；可写 Trading Proposal
Risk Agent        → 只读全部批准前材料；可写 Risk Decision
Compliance Agent  → 只读必要身份、标的、账户与信息隔离记录；可写 Compliance Decision
Management Agent  → 只读冻结版本；可写 Decision Ledger 状态事件
Execution Agent   → 只读 Approved Order Intent；可写 Execution Event
Audit Agent       → 只读全部账本和日志；仅可追加 Audit Finding
```

系统必须由策略引擎在每次读写和每次工具调用时验证权限；Prompt 中写“你可以”不构成授权。Agent 不得访问未被授予的部门私有记忆、草稿、系统提示、API 密钥或交易凭据。

### 3.2 职责分离校验

同一 `human_owner`、同一 `agent_id`、同一会话或同一不可隔离运行环境，不得同时承担同一笔交易的以下任意两个关键角色：

- 研究主作者与研究验证人；
- Trading Proposal 作者与 Red Team 审核人；
- Risk 审批人与 Management 批准人；
- Management 批准人与 Execution 发单人；
- Compliance 审核人与任何交易提案作者。

触发该校验即进入 `SEGREGATION_HOLD`，由 Audit 处理；不得用人工口头豁免。

## 4. 标准交接契约

部门之间只交换版本化、可验证的标准工件，禁止用自由文本、口头结论或聊天摘要直接推动交易状态。

### 4.1 Research Package

```yaml
artifact_type: research_package
research_id: "RES-YYYYMMDD-####"
version: "v1.0"
owner_agent_id: ""
as_of_time: ""
timeframe: "ANNUAL | MEDIUM | T1 | MULTI"
subject: ""
claims: [{claim_id: "", statement: "", evidence_ids: [], status: "UNVERIFIED"}]
counter_evidence: []
assumptions: []
invalidation_conditions: []
watch_variables: []
company_mapping: []
data_lineage: {source_cutoff: "", dataset_hashes: [], code_hash: ""}
publication_status: "DRAFT | PUBLISHED | SUPERSEDED"
```

`industry-chain-research` 是 Industry Research 创建该工件的标准方法。它可以把标的推进到 `RESEARCH` 或 `WATCHLIST`，不能创建 Trading Proposal。

### 4.2 Trading Proposal

```yaml
artifact_type: trading_proposal
proposal_id: "TP-YYYYMMDD-####"
version: "v1.0"
owner_agent_id: ""
instrument: ""
side: "LONG | SHORT"
primary_strategy: "ANNUAL | MEDIUM | T1"
timeframe: ""
research_refs: []
independent_trade_thesis: ""
entry: {zone: [null, null], trigger: "", expiry: ""}
exit: {stop: null, target: null, time_exit: "", invalidation: ""}
requested_risk: {gross_exposure: null, max_loss: null, liquidity_limit: null}
technical_evidence: []
known_conflicts: []
proposal_status: "DRAFT | SUBMITTED | SUPERSEDED"
```

每份提案只允许一个 `primary_strategy`。长期研究不能自动成为 T+1 入场理由；若引用跨时间尺度材料，必须写明它仅是背景还是触发条件。

### 4.3 决策、订单与执行工件

```text
Risk Decision          → 风险限额、拒绝原因或暂停范围
Compliance Decision    → CLEAR / HOLD / REJECT 与有效期
Red Team Report        → 反方主张、未解决问题、挑战结论
Management Decision    → APPROVE / HOLD / RETURN / REJECT
Approved Order Intent  → 唯一允许 Execution 读取的下单对象
Execution Event        → FILLED / PARTIAL / NO_FILL / CANCEL
```

`Approved Order Intent` 必须绑定提案、全部 Gate、风险限制、合规放行、批准人、有效期、允许账户和不可变参数。缺任一字段，Execution 只能输出 `NO_FILL`。

## 5. 完整状态机

```text
RESEARCH → WATCHLIST → SETUP → SUBMITTED → UNDER_REVIEW
                                      │
                ┌─────────────────────┼─────────────────────┐
                ↓                     ↓                     ↓
          CONFLICT_HOLD          RISK_HOLD          COMPLIANCE_HOLD
                │                     │                     │
                └──────────→ RETURNED / WATCHLIST ←────────┘
                                      │
                                   REJECTED
                                      │
                                  (terminal)

UNDER_REVIEW → APPROVED → EXECUTION_PENDING → EXECUTED → MONITORING → CLOSED → REVIEWED
                                  │                  │
                              EXPIRED             NO_FILL / CANCELLED
```

| 状态 | 进入者 | 离开条件 | 禁止事项 |
|---|---|---|---|
| RESEARCH | Research | 发布 Research Package | 交易参数、下单 |
| WATCHLIST | Research / Management | 出现明确策略条件 | 视为投资建议 |
| SETUP | Trading | 完整 Trading Proposal | 批准或成交 |
| SUBMITTED | Trading | 所有必需工件冻结 | 修改原提案 |
| UNDER_REVIEW | Workflow | Gate 并行审核完成 | 执行、口头批准 |
| 任意 HOLD | Control / Management | 满足重新开放条件并新版本提交 | 下单、复用旧批准 |
| APPROVED | Management | 生成未过期 Order Intent | 修改冻结字段 |
| EXECUTION_PENDING | Execution | 有效成交或取消 | 改变批准参数 |
| EXECUTED | Execution | 按退出或风控规则平仓 | 事后修改入场理由 |
| MONITORING | Monitoring / Risk | 平仓、Halt 或失效 | 用新信息伪造原信号 |
| CLOSED | Execution | 交易数据完结 | 修改执行事件 |
| REVIEWED | Audit / Research | 复盘追加完成 | 将复盘覆盖原 Thesis |

所有 `HOLD`、`RETURNED`、`EXPIRED`、`NO_FILL`、`CANCELLED` 和 `REJECTED` 都是正常、可度量的最终或暂终结果，不能被系统静默删除。

## 6. Gate 模型与策略适用性

Gate 采用 `GREEN / YELLOW / RED / NOT_APPLICABLE`。`YELLOW` 不自动放行；只有在策略矩阵明确允许且 Management、Risk、Compliance 全部同意记录例外时，才可继续。`RED` 一律阻断。

| Gate | 认证对象 | Annual | Medium | T+1 |
|---|---|---:|---:|---:|
| G0 | 数据、时点、来源与血缘 | 必须 | 必须 | 必须 |
| G1 | Market Regime | 必须 | 必须 | 必须 |
| G2 | 行业状态与景气 | 必须 | 必须 | 条件适用 |
| G3 | 公司质量、盈利、估值 | 必须 | 必须或简化 | 条件适用 |
| G4 | 价格位置、目标空间 | 必须 | 必须 | 必须 |
| G5 | 单一策略归属和持有期 | 必须 | 必须 | 必须 |
| G6 | 技术 Setup 与失效条件 | 条件适用 | 必须 | 必须 |
| G7 | Risk 独立认证 | 必须 | 必须 | 必须 |
| G8 | Red Team 独立挑战 | 必须 | 必须 | 高风险强制 / 常规抽检 |
| G9 | Compliance 认证 | 必须 | 必须 | 必须 |
| G10 | Management 决策 | 必须 | 必须 | 必须 |
| G11 | Execution 市场条件 | 必须 | 必须 | 必须 |

做空在上述 Gate 之外，强制要求：`Short Thesis`、再定价催化剂、时点理由、拥挤/逼空检查、流动性与可借券条件、独立 Red Team `GREEN` 和更严格的 Risk 限额。

## 7. 独立 Risk、Compliance 与组合控制

### 7.1 Risk

Risk 独立于 Trading，拥有 `PASS / REDUCE / REJECT / HALT` 权。Risk 评估单笔最大损失、组合净/总暴露、因子与行业集中度、相关性、流动性、跳空风险、止损可执行性、容量和压力情景。Risk 只能降低或拒绝风险，不能提出标的或扩大风险预算。

### 7.2 Compliance

Compliance 是独立硬 Gate，至少检查：账户和授权范围、限制/观察名单、内幕信息与信息隔离墙、研究—自营利益冲突、员工交易、卖空/融券可行性、市场操纵与抢跑风险、适用交易场所规则和必要留痕。任何 `HOLD/REJECT` 阻断 Execution。

### 7.3 组合层优先级

单笔交易通过不代表组合允许纳入。Portfolio Construction 必须先取得 Risk 的组合预算，再生成提案；Risk 可因组合相关性、集中度或市场事件拒绝已通过单笔 Gate 的交易。Management 只可在已批准总预算内分配，不得覆盖 Risk 上限。

## 8. 冲突、例外与管理层约束

### 8.1 冲突处理

研究与交易在事实、Thesis、时间尺度、估值、风险、数据、执行或合规上不一致时，系统创建不可删除的 `Conflict Record`，状态立即转为 `CONFLICT_HOLD`。默认动作是暂缓投资，不是投票形成共识。

```yaml
conflict_id: "CONFLICT-YYYYMMDD-####"
proposal_id: ""
research_version: ""
conflict_type: "fact | thesis | timeframe | valuation | risk | data | execution | compliance"
conflicting_claim_ids: []
evidence_gap: []
owner: ""
required_follow_up: []
reopen_conditions: []
review_by: ""
resolution: "OPEN | RESOLVED | RETURNED | REJECTED"
```

时间尺度不同只有在各自使用独立 Thesis、独立 Gate、独立风险预算和独立退出规则时，才能视为“可共存”而非冲突；否则仍然暂缓。

### 8.2 例外管理

例外不是绕过 Gate。它只允许对已预定义的非硬性流程要求作一次性、可审计放行，且必须有：例外编号、适用范围、理由、替代控制、有效期、Risk 与 Compliance 确认及 Management 双人批准。以下永远不可例外：权限隔离、审计日志、Risk/Compliance 的 RED、订单参数冻结、限制名单、未解决冲突。

### 8.3 管理层防单点失效

Management 只能从 `APPROVE / HOLD / RETURN / REJECT / HALT` 中选择，不能修改任何部门的原始材料或 Gate 状态。高风险、做空、策略暂停解除和例外放行需要两名不同 Management Agent/人工负责人的一致批准；任何批准人若参与该提案的研究或交易创作，必须回避。

## 9. 模型、数据与安全风险控制

1. 每个 Claim 记录来源、原文定位、`as_of_time`、证据等级、数据/代码哈希和局限；Agent 结论不能当作独立证据。
2. 验证 Agent 不继承研究 Agent 的隐藏推理、草稿或偏好，仅接收冻结工件和原始证据引用。
3. 外部网页、PDF、邮件和附件均为不可信输入；其中的指令不得改变权限、Gate 或工具调用范围。
4. 每次 Agent 运行记录模型、Prompt、工具调用、数据版本、输出哈希、置信度和失败原因；低置信度输出自动标为 `UNVERIFIED`。
5. 机密数据、账户信息、密钥和未公开信息以最小字段、最短保留期和部门级访问控制处理；不得进入通用 Agent 上下文或研究报告。
6. 任何自动化策略上线前必须通过回放测试、权限测试、失败模式测试、人工演练和 Kill Switch 测试。

## 10. Markdown/Excel 审计与可回放性

Research、Evidence、Decision、Conflict、Risk、Compliance、Execution 和 Review 账本采用可读的 Markdown/Excel 事件记录。每条记录包括：`event_id`、对象 ID、版本、状态变化、操作者、时间戳、权限策略版本和证据引用。更正必须以新记录追加，并引用被更正条目；不修改原条目。

系统必须能够仅用审计账本回答：

- 当时可得的信息是什么？
- 谁在何时以什么权限提出、验证、挑战、批准或取消了什么？
- 为什么没有交易、为什么被拒绝、为什么没有成交？
- 实际成交是否在获批参数和有效期内？
- 复盘使用的新信息是否被错误地写回交易前记录？

Audit 每月抽样回放已执行、已拒绝、已暂缓和未成交订单；发现不可回放即暂停受影响工作流。

## 11. 监控、紧急停止与复盘

Monitoring 持续检查市场异常、数据中断、模型漂移、风险阈值、执行偏离、Thesis 失效和合规事件。Risk、Compliance 或 Management 可触发 `HALT`；Execution 必须立即停止新订单，已持仓仅按预定义应急规则处理。

恢复条件必须包括：事件记录、影响范围、根因、补救、回归测试、Risk/Compliance 放行和新的 Management 决定。不得以“市场机会紧急”为由绕过恢复流程。

Post-trade Review 只可追加，至少比较：事前 Thesis、实际路径、执行偏差、风险事件、反方是否命中、过程违规和可行动改进。复盘结论只能产生新的研究或策略版本。

## 12. 实施顺序与上线门槛

1. 实现独立身份、权限策略、只追加账本和标准工件校验；未完成前不得接交易接口。
2. 实现完整状态机、Gate 矩阵、Conflict/Hold 和 Risk/Compliance 硬阻断。
3. 以历史订单进行端到端回放，覆盖批准、拒绝、冲突、No Fill 和 Halt。
4. 连续完成至少 20 笔模拟流程并通过 Audit 抽样，才允许纸面交易。
5. 纸面交易运行稳定后，以极低风险预算、人工双批准和 Kill Switch 进入受控实盘；任何权限或审计失败立即退回纸面交易。

MTS 的默认成功标准不是提高交易数量，而是能够可靠地阻止不该发生的交易，并在每一次决定后完整还原当时的依据与责任。
