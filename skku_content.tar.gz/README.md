# Fintech-Paper 工作区

本工作区于 2026-08-23 分离为两个互不干扰的研究线和一个共享数据层。冗余产物
按下述生命周期规则清理，顶层只保留研究入口、共享数据和审计归档。

## 目录结构

```
Fintech-Paper/
├── academic_research/   # 学术研究谱系：预注册收益排序论文（横截面 RankIC / H={1,5,15,45}）
├── trading_strategy/    # 交易策略谱系：博弈力度 + K线屏障分类（TP/SL/None，HB-RAG/KNN）
├── shared_data/         # 共享数据集与工作区审计档案
└── obsidian_notes/      # Obsidian 分层知识库：路线图、MOC、原子笔记与双链
```

## 产物生命周期

| 类别 | 位置 | 处理规则 |
|---|---|---|
| 冻结研究数据 | `academic_research/confirmatory_research/data/` | 不删除；确认期与复现共同依赖 |
| 共享开发数据 | `shared_data/` | 物理存储一次，通过符号链接访问 |
| 正式稿件与 PDF | `academic_research/manuscript/`、`academic_research/output/pdf/` | 保留并纳入一致性审计 |
| 正式统计结果 | `academic_research/confirmatory_research/results/confirmation/` | 仅允许冻结流水线生成 |
| 探索性策略结果 | `trading_strategy/kb_out_*`、`trading_strategy/hierarchical_out/` | 保留有结论引用的版本；demo、smoke 移入 `archive/` |
| 可重建缓存 | `__pycache__`、`.pytest_cache`、`output/cache/` | 不纳入交付，可随时删除 |
| 历史材料 | 各研究线的 `archive/` | 只作溯源，不作为当前正文证据 |
| 项目知识笔记 | `obsidian_notes/` | 由当前正式材料生成；证据状态随 `claim_registry` 更新 |

## 关键设计

1. **代码/稿件脚本**物理搬入各自谱系目录，互不引用。
2. **大型数据集**（`us_stock_data`、`ashare_full_data`、`market_data_audit` 等）只存一份于
   `shared_data/`，两个谱系目录内用**符号链接（symlink）**指回，脚本原相对路径不变即可运行，
   不占用双倍磁盘空间。
3. **交汇产物**（如 `hierarchical_out/`、`kb_out_us_stock/` 本是交易谱系输出，但学术的
   `build_claim_registry.py`、`us_stock_factor_rankic.py` 需读取）在 `academic_research/` 内以符号
   链接指回 `trading_strategy/`，保证学术脚本不改代码可运行。

## 在其他软件中打开

- 本机使用 Finder / VS Code / 任意编辑器直接打开 `academic_research/` 或 `trading_strategy/` 即可，
  符号链接在 macOS 默认生效。
- **跨机器/跨平台迁移注意**：`cp -r` 在部分系统会**把符号链接解析为真实文件副本**（导致重复且后续脱节），
  或把符号链接原样复制（目标机器缺 `shared_data/` 会断链）。最稳妥的迁移方式见下方。
- 若需把某个谱系单独打包发给他人，请连同 `shared_data/` 一起打包，或先运行该谱系内的
  `resolve_symlinks_before_pack.sh`（已随附，会把链接还原为真实副本）。

## 审计与回滚

- 分离前后完整文件清单和 2026-08-23 文件夹审计见 `shared_data/audit/`。
- 所有移动均为 `mv`（物理移动，未删任何文件）。如需回滚，可依据清单手动还原。

## 两谱系互不干扰的边界

| 维度 | academic_research | trading_strategy |
|------|-------------------|------------------|
| 目标变量 | 横截面收益排序 RankIC | TP/SL/None 屏障三分类 |
| 核心方法 | paper_research 模块 + 预注册确认期 | kline_kb_feasibility + HB-RAG/KNN |
| 评估口径 | Macro/HAC t、positive-IC ratio | Macro-F1、LogLoss、bootstrap Δ |
| 数据契约 | point-in-time、禁止幸存者偏差 | 含 ashare_full_data（已标注幸存者偏差，仅开发期） |
| 结论措辞 | 确认期待跑（confirmation 结果尚未产出） | 同标的时间制度复现为主效应，非方向 alpha |
