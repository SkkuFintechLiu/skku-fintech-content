---
title: 价格行为研究资料集（跨任务入口）
---

<Paragraph id="st2kafrvsrMWkfh29FLX1x">
  本资料集汇总价格行为学习与研究的全部成果，供跨任务调用。所有节点均在「我的文档」下。
</Paragraph>

<Heading id="2I70bJiGr8IDF3WQjHyqUg" level="2">
  一、学习手册
</Heading>

<Heading id="JkkYPLISvBGvb33r3KnmUz" level="3">
  1. 方方土 PriceAction 学习手册（基础·正统体系）
</Heading>

<Paragraph id="dCUGHqietqwduSjP9vFlv7">
  [在线浏览](https://www.workbuddy.cn/space/d/hpIFQRsI0zjQGFJHKV57Ef)
</Paragraph>

<Paragraph id="WHlBxjTPsEzFMFt4rdE1Ia">
  Al Brooks 价格行为体系中文权威实践者 Louie 的频道全解。16 板块：方法论、学习路线图、市场周期结构、数学期望、入场体系、止损与实际风险、仓位管理、订单工具、止盈目标位、陷阱清单、期权应用、A股与中国期货适配、8 个实盘案例、新手十诫、全部 157 集视频目录。基于 25 集全文字幕精读。
</Paragraph>

<Heading id="TIIPmbG9dSswNMkoOHCZbs" level="3">
  2. 价格行为进阶手册 II（进阶·中文实战派视角）
</Heading>

<Paragraph id="oWWm61UENpbgO8v6KJYMXX">
  [在线浏览](https://www.workbuddy.cn/space/d/RR9MxU2Q3f8BwuykbCUSol)
</Paragraph>

<Paragraph id="xv1jMEy4nQY1fT34A8wZbT">
  承接基础手册，补足中文实战派三个源头：z说交易的缺口与支撑阻力画法（被套者成本线）、forecho 的 Prop Firm 数学模型与实盘心路、PA Hub CN 社区形态交易记录库。含与 Louie/Brooks 体系的逐维度对照表与进阶练习路径。
</Paragraph>

<Heading id="AtAJJ1JmY5DKApUDaSsdNo" level="2">
  二、数据与工具
</Heading>

<Heading id="mf7PaFlD1DBPJl32j6S9yc" level="3">
  3. 申万行业 · 上市公司名单工作台
</Heading>

<Paragraph id="cN9aMtTDjTXKghF8VbjMRO">
  [在线浏览](https://www.workbuddy.cn/space/d/pKUdiQu1MlqT1lpC91bye6)
</Paragraph>

<Paragraph id="x2iIjh6DVIhNvEJzTlUxyX">
  申万一/二/三级行业分类（31/131/336）+ 5195 家成分股映射，可搜索可收藏，单文件离线可用。
</Paragraph>

<Heading id="eOJOWaKCmzVEufGAs81OeD" level="3">
  4. 研究资料包（数据+脚本+25集转录）
</Heading>

<Paragraph id="qwRRT8Vln3m8rWWlfVaaUS">
  [在线浏览](https://www.workbuddy.cn/space/d/v2iyHQ4voQLCk0RlhULakA)
</Paragraph>

<Paragraph id="YayFo3eRlzo6iEsiZf8SlX">
  zip 包，含 `index.html` 说明页 + `sw_final.json`/`catalog.json` 等数据 + 5 个可复现脚本 + 25 集纯文本转录（31 万字）。刷新数据重跑对应脚本。
</Paragraph>

<Heading id="19OQPTjvhYW7QiHRF2kJih" level="2">
  三、概览
</Heading>

<Heading id="DbuVGWR4M9uE5TkEn3OU14" level="3">
  5. 研究资料概览
</Heading>

<Paragraph id="MUanrO84tFSxyTYTfkeYAo">
  [在线浏览](https://www.workbuddy.cn/space/d/pBNFzXBnVPP4LlRKidFWMy)
</Paragraph>

<Paragraph id="H6ew8eZimjdb8se6Mmo09T">
  两个研究项目的整体说明、关键结论、文件清单与复现方式。跨任务协作时先看这个。
</Paragraph>

<Divider id="Ti2jtQfkHhJYg4Px3rpKtN" />

<Heading id="JdeVpKdfjDHBYcInLVvWDT" level="2">
  跨任务调用提示
</Heading>

<BulletedList id="jgHdSRoKSGl78jp6xABR8E">
  <Mark bold>引用行业分类</Mark>：读资料包内 `sw_final.json`（股票 code 为 6 位纯数字）。
</BulletedList>

<BulletedList id="FML8tOynlBU8ZZre2aczB3">
  <Mark bold>引用频道内容</Mark>：读 `catalog.json` 取视频清单与转录可用性，正文读 `transcripts/<videoId>.txt`。
</BulletedList>

<BulletedList id="GmZicFzukC45eQBd48CzXz">
  <Mark bold>价格行为复盘</Mark>：以两本手册为方法论框架，结合通达信（tdx-connector）与腾讯自选股（westock-mcp）行情数据，每日收盘后自动复盘（见自动化任务）。
</BulletedList>

<Heading id="R8QnPs6RlGGK7NbDSDPxJB" level="2">
  数据来源与版权
</Heading>

<BulletedList id="lyEUbUN2yyFH31XFQnzQ2x">
  视频数据：YouTube @LouiePriceAction 公开数据（2026-08-26 抓取）。
</BulletedList>

<BulletedList id="2f0HM64YPgogQ9l5tIas1O">
  行业数据：akshare 申万行业指数接口（2026-08-26）。
</BulletedList>

<BulletedList id="8F0lJAFoULUCo1dtK3Qpw0">
  方法论：Al Brooks 价格行为体系 + z说交易 + forecho Blog + PA Hub CN。
</BulletedList>

<BulletedList id="USS5nErUzur3BRonfdixya">
  仅供学习研究，不构成投资建议；视频版权归频道主所有。
</BulletedList>
KS_DOC_REVIEWS	fdVGSJTv3oEbsl9verv4lC	4477	https://www.workbuddy.cn/space/d/fdVGSJTv3oEbsl9verv4lC
