# MTS Governance v1.0

Multi-Timeframe Trading System 的治理与运行规范。本文把“研究—认证—决策—执行—复盘”固化为可审计流程。

## 0. Research OS：行业研究与上市公司发掘 Skill

`industry-chain-research` 是 MTS Research OS 的标准行业研究模块，负责把一个宽泛行业或主题收敛为可研究、可验证、可映射到上市公司的细分节点。

### 0.1 模块定位

```text
Research OS
├── Market Research
├── Industry Research
│   └── industry-chain-research skill
├── Company Research
└── Quant / Data
```

该 Skill 的产出是“研究候选”和“产业逻辑”，不是直接交易指令。它不能跳过公司研究、策略归属、技术认证、Risk、Red Team 或 IC。

### 0.2 标准研究流程

1. **界定对象**：明确行业边界、区域、研究目的和分类口径；大行业必须先拆成细分节点。
2. **拆解产业链**：分析上游原料、设备与能源，中游制造与工艺，下游应用、客户和配套环节。
3. **还原转换流程**：对材料和制造业写清“原料 → 中间体 → 核心工艺 → 产物 → 部件/系统 → 终端”。
4. **分析运行机制**：识别需求驱动、供给约束、价格/库存/产能/订单等景气变量及生命周期阶段。
5. **分析竞争壁垒**：比较成本、技术、认证、客户、规模、全球工业能力和中国与海外差距。
6. **落到财务结果**：分析量价结构、利润率、现金流、资本开支、ROIC、周期属性和估值锚。
7. **映射上市公司**：区分核心、观察、映射三层标的，说明公司与产业节点的真实相关度。
8. **形成跟踪表**：记录关键指标、催化因素、风险因素和推翻原判断的条件。

### 0.3 研究输出契约

每次行业研究至少输出：

```yaml
research_id: ""
subject: ""
wind_classification: ""
region: "CN"
purpose: "investment / industry_scan / company_discovery"
industry_stage: ""
chain_nodes: []
conversion_path: []
key_drivers: []
constraints: []
global_comparison: []
financial_implications: []
tracking_indicators: []
companies:
  core: []
  watch: []
  mapping: []
claims: []
uncertainties: []
source_cutoff: ""
skill_version: "industry-chain-research"
status: DRAFT
```

上市公司不得只列名称。每家公司必须标注：证券代码、上市地、产业链位置、核心产品、赛道相关度、竞争优势、跟踪指标和主要风险。数据不足时允许定性判断，但必须标注依据与不确定性。

### 0.4 与 Gate 的接口

| Skill 产出 | 对应 Gate | 作用 | 不能替代 |
|---|---|---|---|
| 市场与行业状态 | G1 / G2 | 提供市场和行业背景 | Market 最终认证 |
| 公司产业链映射 | G3 | 提供公司研究入口 | Company 认证 |
| 价格、供需、生命周期变量 | G4 | 支持“为什么现在研究/关注” | 价格入场认证 |
| 产业催化与风险 | G5 / G8 | 支持策略归属和反方材料 | Strategy / Red Team |
| 财务与估值分析 | G3 / G7 | 支持基本面与风险判断 | Quant 数据认证、Risk 否决 |

Skill 研究完成后，默认只能推动标的进入 `RESEARCH` 或 `WATCHLIST`。只有完成独立公司研究、Quant 验证和对应策略 Checklist，才可进入 `SETUP`。

### 0.5 权限边界

`industry-chain-research` 可以：

- 界定行业和细分赛道；
- 拆解产业链、工艺链和价值分配；
- 发掘、分类和初步评分上市公司；
- 提出行业景气判断、催化剂、风险和跟踪指标；
- 生成 Research Ledger 条目和待验证 Claims。

`industry-chain-research` 不可以：

- 直接批准买入或做空；
- 决定 Entry、Stop、Target、仓位或执行时间；
- 修改 Market Regime、Risk 限额或历史数据；
- 把主题映射公司写成核心受益公司；
- 用未经验证的市占率、订单、利润率或客户信息作为确定事实；
- 替代 Company Research、Quant、Red Team、Risk 或 IC。

### 0.6 证据与版本要求

行业研究中的每个重要判断都必须进入 Evidence Ledger，并记录来源、来源截止日期、计算口径、证据状态和局限。研究观点发生变化时创建新版本，不覆盖旧版：

```text
Industry Thesis v1.0
→ 新数据/新证据
→ Industry Thesis v1.1
→ 填写 Change Reason 与受影响 Gate
```

行业研究的 `VERIFIED` 只表示产业或事实主张通过证据核验，不表示交易已经获批。

## 0.7 分级 Agent 制度：研究与交易完全隔离

MTS 采用“部门隔离、权限分级、管理层决策”的 Agent 组织制度。研究 Agent 不执行交易，交易 Agent 不重写研究结论；两者之间只通过标准化文件和 Gate 状态交换信息。

### 组织层级

```text
Management Layer / Decision Council
        │
        ├── Research Department
        │   ├── Market Research Agent
        │   ├── Industry Research Agent
        │   ├── Company Research Agent
        │   └── Quant / Data Validation Agent
        │
        ├── Trading Department
        │   ├── Strategy Agent
        │   ├── Technical Setup Agent
        │   ├── Portfolio / Risk Execution Agent
        │   └── Execution Agent
        │
        └── Independent Control Agents
            ├── Red Team Agent
            ├── Audit Agent
            └── Monitoring Agent
```

### A. Research Department

研究部门负责回答：

> 行业和公司发生了什么？证据是否支持？未来哪些变量值得跟踪？

研究 Agent 可以产生行业判断、公司候选、估值区间、景气变量和研究结论，但不得：

- 直接批准交易；
- 直接下单或修改订单；
- 代替 Trading Department 判断交易时机；
- 因为交易部门需要成交而修改研究结论；
- 把“值得研究”表达成“可以投资”。

### B. Trading Department

交易部门负责回答：

> 当前是否存在符合某一策略的可执行机会？如果执行，如何控制 Entry、Stop、Target、仓位和退出？

交易 Agent 可以提出交易方案、识别技术 Setup、制定执行参数和提交投资申请，但不得：

- 修改研究部门的原始 Thesis、证据或风险结论；
- 为了形成交易信号而选择性忽略研究反证；
- 自行认证行业、公司或基本面研究；
- 在管理层未批准前执行真实交易；
- 把历史盈利结果倒推为交易前的研究依据。

### C. Management Layer / Decision Council

管理层是唯一的统一决策制定层，负责：

- 接收 Research Department 与 Trading Department 的独立报告；
- 判断研究结论与交易方案是否属于同一时间尺度和同一投资命题；
- 处理部门冲突并记录冲突；
- 决定批准、退回、观察或暂缓；
- 分配风险预算，但不得突破 Risk 的硬上限；
- 在信息不一致、关键 Gate 未通过或冲突无法解释时暂停本次投资。

管理层不是“替研究或交易部门补逻辑”的超级 Agent。管理层只能基于已提交、已锁定、可追溯的材料决策。

### D. Independent Control Agents

Red Team、Audit 和 Monitoring Agent 不属于 Research Department 或 Trading Department 的上下级链条：

- `Red Team Agent`：提出最强反方和失效路径；
- `Audit Agent`：检查时点、版本、权限、证据和审批链；
- `Monitoring Agent`：监控市场、风险、执行和 Thesis 失效事件。

控制 Agent 可以提出 `CHALLENGE`、`REJECT` 或 `HALT`，但不能自行选择投资标的。

## 0.8 Agent 权限级别

| 级别 | Agent 类型 | 可以做什么 | 明确不能做什么 |
|---|---|---|---|
| L0 | Data Agent | 采集、清洗、标记数据质量 | 改写事实、形成投资结论 |
| L1 | Research Agent | 研究、解释、提出候选和 Claims | 批准、下单、修改他部门结论 |
| L2 | Validation Agent | 验证数据、回测、证据和口径 | 为了结果调参或批准交易 |
| L3 | Trading Agent | 形成策略方案、技术 Setup、执行计划 | 代替研究认证或直接成交 |
| L4 | Control Agent | 挑战、审计、监控、否决风险流程 | 自行选股或自行批准交易 |
| L5 | Management Agent | 统一决策、批准、暂缓、暂停策略 | 修改历史记录、绕过硬风险限制 |

任何 Agent 只能调用其权限级别以内的工具。权限提升必须产生审计日志，并且不得临时改变当前交易的历史记录。

## 0.9 研究—交易冲突处理协议

研究与交易出现以下任一情况，即视为冲突：

- Research 判定行业或公司逻辑不成立，Trading 仍提出买入；
- Research 为长期看多，Trading 的中短期 Setup 却要求反向交易，且没有独立策略解释；
- Research 的估值、盈利或景气判断与 Trading 的目标收益和持有期不匹配；
- Research 给出 `YELLOW/RED`，Trading 将其解释为 `GREEN`；
- 研究资料、交易参数、时间尺度或标的归属无法对齐；
- 任何部门要求另一部门修改结论以促成交易。

冲突发生后，必须执行：

```text
Research Report + Trading Proposal
        ↓
Conflict Record
        ↓
Management Review
        ↓
暂缓本次投资
        ↓
补充研究 / 重新提交 / 维持不投资
```

在冲突解决前，强制状态为 `CONFLICT_HOLD`，不得进入 `APPROVED`、`EXECUTED` 或任何真实下单状态。管理层不得通过口头指令绕过该状态。

### Conflict Record 最小字段

```yaml
conflict_id: "CONFLICT-YYYYMMDD-####"
instrument: ""
primary_strategy: ""
research_version: ""
trading_proposal_version: ""
research_position: ""
trading_position: ""
conflict_type: "thesis / timeframe / valuation / risk / execution / data"
conflicting_claims: []
missing_evidence: []
management_decision: "HOLD"
hold_reason: ""
required_follow_up: []
reopen_conditions: []
next_review_time: ""
recorded_by: ""
```

管理层的默认处理不是强行协调成一个共识，而是记录冲突并暂缓本次投资。只有当冲突被新增证据、明确的时间尺度拆分或独立风险判断解决后，才可创建新的审批版本。

### 重新开放条件

重新提交必须满足：

1. Research 与 Trading 各自提交不可覆盖旧版本的新报告；
2. 明确冲突是否已消失、被解释，或仅被接受为独立策略差异；
3. 重新运行受影响的 Gate；
4. Risk、Red Team 和 Management 重新签字；
5. 产生新的 `approval_id`，不得复用原审批。

如果冲突无法解释，状态保持 `CONFLICT_HOLD` 或退回 `WATCHLIST`，不设置强制解决期限。

## 1. 决策状态机

```text
RESEARCH → WATCHLIST → SETUP → APPROVED → EXECUTED → CLOSED
```

任何状态只能按顺序推进。Gate 未通过时只能停留或回退，不能跳级。交易后的认知变化必须创建新版本，不得覆盖原记录。

## 2. RACI 权限矩阵

| 工作项 | Market | Industry | Company | Quant | Strategy | Risk | Red Team | IC | Execution | Audit |
|---|---|---|---|---|---|---|---|---|---|---|
| 市场状态 | R/A | C | C | C | C | C | C | A | I | I |
| 行业状态 | C | R/A | C | C | C | I | C | A | I | I |
| 公司研究 | I | C | R/A | C | C | I | C | A | I | I |
| 数据与回测 | I | C | C | R/A | C | C | C | I | I | A |
| 策略方案 | C | C | C | C | R/A | C | C | A | I | I |
| 风险认证 | I | I | I | C | C | R/A | C | I | I | A |
| 反方挑战 | C | C | C | C | C | C | R/A | I | I | A |
| 最终批准 | I | I | I | I | C | C | C | R/A | I | I |
| 下单与拒绝执行 | I | I | I | I | I | C | I | I | R/A | A |
| 历史记录修改 | × | × | × | × | × | × | × | × | × | A（仅更正日志） |

`R`=负责执行，`A`=最终负责，`C`=咨询，`I`=知会。任何人不得同时对同一交易承担 Research、Certification、Approval、Execution 四个闭环角色。

## 3. Gate 认证标准

每个 Gate 只能是 `GREEN`、`YELLOW` 或 `RED`，不能用投票替代证据。关键 Gate 为 `RED` 或 `YELLOW` 时，交易不得进入 APPROVED。

| Gate | 必须回答的问题 | GREEN 标准 |
|---|---|---|
| G0 Data | 数据是否可追溯、时点是否正确？ | 来源、时间戳、样本、计算版本齐全 |
| G1 Market | 市场环境允许该策略吗？ | Regime 与策略方向相容，或已有明确例外规则 |
| G2 Industry | 行业是否支持？ | 行业状态、景气方向、证据时效明确 |
| G3 Company | 公司是否满足基本面条件？ | 只对需要公司研究的策略执行；Bull/Base/Bear 完整 |
| G4 Price | 为什么现在交易？ | Entry zone、等待条件、目标空间和机会成本明确 |
| G5 Strategy | 归属哪一套策略？ | 仅一个主策略，持有期和退出规则预先写明 |
| G6 Technical | 结构是否触发？ | Setup、确认条件、失效条件均已记录 |
| G7 Risk | 最大损失可接受且可执行吗？ | 仓位、止损、组合暴露、相关性和流动性通过 |
| G8 Red Team | 最强反方是什么？ | 反方独立完成，关键反证已回应 |
| G9 IC | 是否批准进入交易状态？ | 前置 Gate 全部通过，批准范围和有效期明确 |
| G10 Execution | 当前还能按计划成交吗？ | 价格、流动性、事件状态未突破执行阈值 |

## 4. 策略 Entry Checklist

### Annual

- 行业周期与长期供需链完整
- 公司质量、盈利、估值和 Bull/Base/Bear Case 完整
- 长期结构与长期 Entry Zone 明确
- 长期失效条件、目标和持有期明确
- 不因短期波动改写 Thesis

### Medium-term

- Market Regime 与市场主线明确
- 行业动量与公司盈利预期同向或有明确冲突解释
- 价格处于相对低位或预设回撤区
- HTF 结构、量价、SMC、ITP 条件满足
- 预期持有数周至数月，退出规则独立于 Annual

### T+1 / Intraday

- 明确下一交易窗口的价格优势
- 当日 Regime、主线、量价、流动性和结构可验证
- Entry、Stop、Target、最大持有时间在开仓前冻结
- 不引用长期 Thesis 作为入场理由
- 收盘后自动失效，除非创建新版本并重新认证

## 5. Long / Short Approval Form

```yaml
approval_id: "APP-YYYYMMDD-####"
instrument: ""
side: LONG # LONG or SHORT
primary_strategy: ANNUAL # ANNUAL / MEDIUM / T1
thesis_version: ""
signal_time: ""
entry:
  zone: [null, null]
  trigger: ""
  execution_deadline: ""
risk:
  stop: null
  target: null
  expected_rr: null
  max_loss: null
  portfolio_exposure: null
  invalidation: ""
gates: {G0: RED, G1: RED, G2: RED, G3: RED, G4: RED, G5: RED, G6: RED, G7: RED, G8: RED, G9: RED}
red_team:
  strongest_counter_case: ""
  unresolved_risk: ""
  reviewer: ""
short_only:
  catalyst: ""
  timing: ""
  crowding_squeeze: ""
  borrow_or_execution_constraint: ""
decision: PENDING
decision_owner: ""
valid_until: ""
```

做空必须额外填写 `catalyst`、`timing`、`crowding_squeeze` 和可借/可执行约束，并由独立 Red Team 审核。

## 6. 三本账

### Research Ledger

记录研究对象与观点来源：`research_id`、对象、作者、时间尺度、核心主张、证据、反证、假设、失效条件、置信度、版本和关联数据。

### Evidence Ledger

记录每个主张的可验证证据：`claim_id`、证据类型、来源、as-of 时间、样本、计算方法、代码/数据哈希、结果、局限、验证人和状态。状态只能为 `UNVERIFIED`、`PARTIAL`、`VERIFIED`、`REJECTED`。

### Decision Ledger

记录每次状态变化：`decision_id`、approval_id、旧状态、新状态、触发 Gate、决策人、时间戳、理由、版本、执行结果和是否允许回退。禁止删除，只能追加更正事件。

## 7. 冻结与复盘

批准或执行前冻结 `Thesis`、`Entry`、`Stop`、`Target`、`Confidence`、`Invalidation`、`Expected R:R`。交易后只能新增 `Post-trade Review`，不得编辑冻结字段。

Execution 在实际市场条件恶化时拥有 `NO_FILL` / `CANCEL` 权。Risk 的硬否决不可被 IC 覆盖；IC 可以暂停系统，但不能修改历史证据。

## 8. 最小落地顺序

1. 先使用 YAML 审批表和三本账，不等待软件系统。
2. 为 Annual、Medium-term、T+1 各建立一份真实空白模板。
3. 选一笔历史交易进行“当时信息”回放，检查是否能还原冻结状态。
4. 连续完成 5 笔模拟审批后，再接入自动化评分或下单。
