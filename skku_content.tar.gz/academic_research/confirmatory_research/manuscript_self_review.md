# Manuscript Adversarial Self-Review

## 1. Contribution

- **Pass:** The paper separates causal price-structure encoding, historical-neighbor state classification, local outcome-distribution estimation, and execution risk control rather than treating chart recognition as a direct trading claim.
- **Pass:** The evidence-gated separation between cross-sectional predictability and tradability is explicit and falsifiable.
- **Needs evidence:** Novelty is methodological and governance-oriented; it cannot be elevated to an empirical contribution until the locked 2025 tests are complete.

## 2. Writing Clarity

- **Pass:** KNN and HB-RAG have distinct estimands; HB-RAG is defined as historical-behavior retrieval rather than an LLM system.
- **Pass:** OHLCV variables are described as low-frequency price-formation proxies, not direct order-flow or institutional-intent measures.
- **Pass:** Tables, figures, manuscript claims, and source files are linked through machine-readable registries.

## 3. Experimental Strength

- **Pass:** Existing development evidence is labeled diagnostic and reports both ranking strength and trading failure.
- **Needs evidence:** No 2025 effect size may be assessed before data coverage, implementation freeze, and confirmatory computation pass.
- **Needs evidence:** CRSP point-in-time external validation remains pending interactive WRDS extraction.

## 4. Evaluation Completeness

- **Pass:** The registered matrix includes traditional factors, linear and tree models, component ablations, joint models, structure conditioning, risk control, placebos, heterogeneity, parameter stability, time-series diagnostics, and execution-aware benchmarks.
- **Pass:** Overlapping horizons use Newey-West inference, date blocks, within-date permutation, simultaneous intervals, and Holm correction.
- **Needs evidence:** Formal Figures 3--6 and 8 and Tables 2--8 remain closed until their registered source files exist.

## 5. Method Soundness

- **Pass:** Tests cover future-append invariance, pivot confirmation delay, label maturity, IPO/delisting boundaries, official ST/trading status, next-open execution, transaction costs, delisting losses, and lagged futures exposure.
- **Pass:** The strategy does not infer trading validity from RankIC alone and retains null-result branches.
- **Residual risk:** Historical ST reconstruction and public-source auxiliary-field coverage must remain visible in Table 1 and cannot be silently imputed as directly observed microstructure.

## Claim-Evidence Map

| Claim | Evidence | Status |
|---|---|---|
| KNN+HB-RAG contains development-period ranking information | `hierarchical_out/knn_hbrag_effectiveness/factor_rank_ic.csv` | Supported for viewed development diagnostics only |
| Development ranking gains establish trading alpha | Registered block comparison in `hierarchical_out/knn_hbrag_effectiveness/results.json` | Not supported |
| Causal price structure adds 2025 predictive information | `structure_increment_tests.csv` under the locked pipeline | Needs confirmatory evidence |
| The registered strategy is tradable in 2025 | Net active returns, block tests, and drawdown gate | Needs confirmatory evidence |
| Frozen rules transfer to U.S. common stocks | CRSP point-in-time effect sizes including delisting returns | Needs external evidence |
