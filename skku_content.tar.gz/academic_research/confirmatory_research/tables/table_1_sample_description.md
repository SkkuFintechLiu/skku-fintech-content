**表 1. 数据样本、覆盖门槛与允许用途**

| 样本                               | 期间                     | 预期/观测证券数   | 股票日覆盖率   | 辅助字段最低覆盖率   | 状态            | 允许用途                     |
|:-----------------------------------|:-------------------------|:------------------|:---------------|:---------------------|:----------------|:-----------------------------|
| A-share point-in-time build        | 2015-01-01 to 2025-12-31 | 5,415/5,415       | 97.81%         | 13.36%               | PASS            | 2025 confirmation            |
| Legacy A-share development archive | 2015-01-01 to 2024-12-31 | --/4,455          | --             | --                   | SURVIVOR-BIASED | development diagnostics only |
| WRDS/CRSP external validation      | 2015-01-01 to 2025-12-31 | --/--             | --             | --                   | PENDING         | none before extraction audit |

注：覆盖率按证券主表中应出现的合格股票日计算；门控未通过时不报告 2025 确认性估计。

**Panel B. 股票池与股票日统计**

| metric                             | value              | definition                                |
|:-----------------------------------|:-------------------|:------------------------------------------|
| Observed securities                | 5415               | Unique assets with OHLCV                  |
| Observed stock-days                | 10542802           | Unique asset-date OHLCV rows              |
| Start date                         | 2015-01-05         | First observed OHLCV date                 |
| End date                           | 2025-12-31         | Last observed OHLCV date                  |
| Securities: ChiNext                | 1443               | Security-master board count               |
| Securities: Main                   | 3483               | Security-master board count               |
| Securities: STAR                   | 618                | Security-master board count               |
| Delisted securities                | 333                | Non-missing delisting date                |
| ST stock-days                      | 254742             | Audited ST proxy flag                     |
| Limit-locked stock-days            | 35585              | One-price daily limit flag                |
| Suspended/missing-price stock-days | 281374             | Untradable days excluding limit locks     |
| Daily amount p25                   | 30058494.5         | Currency units                            |
| Daily amount p50                   | 72856546.5         | Currency units                            |
| Daily amount p75                   | 179129639.19       | Currency units                            |
| Annualized volatility p25          | 0.443862644693538  | Asset-level daily close-return volatility |
| Annualized volatility p50          | 0.4975191148926842 | Asset-level daily close-return volatility |
| Annualized volatility p75          | 0.5564056590927952 | Asset-level daily close-return volatility |
