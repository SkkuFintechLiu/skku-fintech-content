# Upstream Workflow

Upstream project: `https://github.com/deep-diver/paper-reviewer`

## Purpose

The repository automates two stages:

1. `collect.py`
   Downloads or parses the paper and generates structured review artifacts.
2. `convert.py`
   Renders collected artifacts into a markdown blog post using a template.

Use this reference when you need exact setup details or CLI flags.

## Setup

Required environment:

- `GEMINI_API_KEY`

Optional environment:

- `UPSTAGE_API_KEY`
  Use when `--use-upstage` is enabled for better PDF/image figure extraction.
- `R2_ACCESS_KEY_ID`
- `R2_SECRET_ACCESS_KEY`
- `R2_S3_ENDPOINT_URL`
- `R2_DOMAIN_NAME`
  Use these only when uploading rendered images to Cloudflare R2.
- `GCP_API_KEY`
  Needed by the Vertex AI voice synthesis path noted in `pipeline/script_to_speech_vertexai.py`.

Dependencies:

- `pip install -r requirements.txt`
- Poppler is required for PDF-to-image conversion.
  On macOS the upstream README recommends `brew install poppler`.

MinerU path:

- Requires Python `3.10`
- Install with `pip install -U 'magic-pdf[full]==0.10.5' --extra-index-url https://wheels.myhloli.com`
- The upstream README notes `~/magic-pdf.json` may need `"device-mode": "cuda"` or `"cuda:0"` for GPU use

## Collection Step

Entry point: `collect.py`

Important flags from the upstream CLI:

- `--arxiv-id`
- `--openreview-id`
- `--skip-comparision-openreview-arxiv`
- `--skip-page-threshold`
  Default in code is `50`
- `--workers`
  Default in code is `10`
- `--use-upstage`
- `--use-mineru`
- `--stop-at-no-html`
- `--known-affiliations-path`
  Default is `configs/known_affiliations.txt`
- `--known-categories-path`
  Default is `configs/known_categories.json`
- `--voice-synthesis {vertexai,local}`

Recommended run order:

1. Try HTML-first:

```bash
python collect.py --arxiv-id "<id>" --stop-at-no-html
```

2. If the paper has no usable HTML and image extraction quality matters:

```bash
python collect.py --arxiv-id "<id>" --use-upstage
```

3. If cost sensitivity matters more than perfect figure localization:

```bash
python collect.py --arxiv-id "<id>"
```

4. Use MinerU only when its environment is already prepared:

```bash
python collect.py --arxiv-id "<id>" --use-mineru
```

## Conversion Step

Entry point: `convert.py`

Important flags:

- `--arxiv-id`
- `--openreview-id`
- `--template`
  Default in code is `templates/article_tmpl.md`
- `--hf-daily-papers-date-tag`
- `--upload-images-r2`
- `--stop-at-no-html`

Typical conversion command:

```bash
python convert.py --arxiv-id "<id>" --template templates/article_tmpl.md
```

If image hosting is enabled:

```bash
python convert.py --arxiv-id "<id>" --template templates/article_tmpl.md --upload-images-r2
```

## Files And Templates

Relevant upstream paths:

- `collect.py`
- `convert.py`
- `templates/article_tmpl.md`
- `configs/known_affiliations.txt`
- `configs/known_categories.json`
- `pipeline/`

The helper script `convert-local.sh` loops through `2410.*` directories and runs:

```bash
python convert.py --arxiv-id $arxiv_id --template templates/article_tmpl.md --upload-images-r2
```

## Practical Guidance

- Start with `collect.py` and only run `convert.py` after collection artifacts exist.
- If `--stop-at-no-html` exits early, switch to `--use-upstage` or the default Gemini fallback.
- Treat the upstream template as the article contract. If you customize it, keep variable names aligned with what `convert.py` renders.
- If uploads fail, disable `--upload-images-r2` and verify the four `R2_*` variables before debugging templates.
- If voice synthesis fails, verify whether the run expects `vertexai` or `local`, then check the corresponding environment and scripts.
