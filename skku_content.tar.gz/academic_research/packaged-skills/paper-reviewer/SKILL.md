---
name: paper-reviewer
description: Use when Codex needs to set up, run, adapt, or troubleshoot the deep-diver/paper-reviewer workflow for arXiv or OpenReview papers. Covers collecting paper artifacts, generating structured reviews, extracting figures from HTML or PDFs, converting results into blog posts, choosing between Gemini, Upstage, and MinerU paths, and customizing the output template.
---

# Paper Reviewer

Package the upstream `deep-diver/paper-reviewer` project into a Codex-friendly workflow for paper review and blog generation.

## Workflow

1. Confirm the user's goal.
   Goals usually fall into one of four buckets:
   - review one paper from arXiv
   - review one paper from OpenReview
   - convert an existing collected review into a blog post
   - customize or debug the upstream pipeline

2. Build context from the upstream repo before changing anything.
   Read [references/upstream-workflow.md](references/upstream-workflow.md) for setup requirements, environment variables, CLI flags, output paths, and known caveats.

3. Choose the extraction path deliberately.
   - Prefer `--stop-at-no-html` when the paper has arXiv HTML and the user wants lower cost.
   - Prefer `--use-upstage` when the paper lacks dedicated HTML and figure extraction quality matters.
   - Use the default Gemini-only image path only when the user accepts best-effort figure extraction.
   - Use `--use-mineru` only if the environment can support the extra Python 3.10 and MinerU setup.

4. Run the workflow in two phases unless the user explicitly wants only one.
   - Phase 1: `collect.py`
   - Phase 2: `convert.py`

5. Keep outputs inspectable.
   Summarize which command ran, which parser mode was selected, where artifacts were written, and which optional services were required.

## Common Tasks

### Run a single-paper review

Use the upstream commands from the reference file. Prefer starting with a cheap HTML-first collection run, then escalate to image parsing only when needed.

### Convert to blog post

Use `convert.py` with the default template unless the user asks for a custom article layout.

### Customize the generated article

Inspect `templates/article_tmpl.md` in the upstream repo and adapt it carefully. Keep the data contract expected by `convert.py`.

### Troubleshoot failures

Check environment variables first, then parser prerequisites, then missing intermediate files from the collection step.

## Notes

- This skill documents and operationalizes the upstream repository. It does not bundle the upstream code itself.
- If the user wants a runnable local copy, clone `deep-diver/paper-reviewer` into the workspace and work inside that checkout.
