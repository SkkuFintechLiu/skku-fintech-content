# Upstream Workflow

Upstream project: `https://github.com/dzhng/deep-research`

## Purpose

The repository runs recursive, search-driven web research and synthesizes either:

- `report.md`
- `answer.md`

It combines Firecrawl for search and scraping with an OpenAI-compatible model or Fireworks-backed DeepSeek R1.

## Setup

Runtime requirements from the repo:

- Node.js `22.x`
- `npm install`

Core environment variables:

- `FIRECRAWL_KEY`
- `OPENAI_KEY`

Optional environment variables:

- `FIRECRAWL_BASE_URL`
  Use for self-hosted Firecrawl.
- `OPENAI_ENDPOINT`
  Use for custom OpenAI-compatible endpoints.
- `CUSTOM_MODEL`
  Use to override the default model selection.
- `FIREWORKS_KEY`
  Enables Fireworks-hosted DeepSeek R1 in the provider layer.
- `CONTEXT_SIZE`
  Used in `trimPrompt()` to override the default `128000` token context cap.
- `FIRECRAWL_CONCURRENCY`
  The code reads this variable to set concurrency. The README mentions `CONCURRENCY_LIMIT`, but the implementation uses `FIRECRAWL_CONCURRENCY`.

Environment file:

- The upstream scripts expect `.env.local`

## Commands

Install dependencies:

```bash
npm install
```

Run the interactive CLI:

```bash
npm start
```

Run the API server:

```bash
npm run api
```

Run the Docker entry path described by the repo:

```bash
docker compose up -d
docker exec -it deep-research npm run docker
```

## Interactive Flow

`src/run.ts` prompts for:

1. research query
2. breadth
   Code prompt recommends `2-10`, default `4`
3. depth
   Code prompt recommends `1-5`, default `2`
4. output mode
   `report` or `answer`

If the user chooses report mode, `src/feedback.ts` generates up to `3` follow-up questions before the recursive search begins.

## Outputs

CLI outputs:

- `report.md`
  Used for long-form synthesis and appends a `## Sources` section with visited URLs.
- `answer.md`
  Used for concise direct answers.

The CLI also prints:

- selected model id
- collected learnings
- visited URLs

## Internal Behavior Worth Remembering

Key implementation points from the source:

- Default concurrency is `2`
- Firecrawl search uses `limit: 5` results per query
- Recursive breadth halves each time via `Math.ceil(breadth / 2)`
- Each research branch can generate learnings plus follow-up directions
- Final report generation explicitly aims for a detailed multi-page markdown output

Provider selection in `src/ai/providers.ts`:

1. `CUSTOM_MODEL` via the OpenAI-compatible provider if set
2. Fireworks DeepSeek R1 if `FIREWORKS_KEY` exists
3. OpenAI `o3-mini` if `OPENAI_KEY` exists

If none are configured, the code throws `No model found`.

## Practical Guidance

- Start with `breadth=3-4` and `depth=2` unless the user has generous rate limits.
- Reduce breadth first when Firecrawl errors or rate limits appear.
- Use answer mode only for tightly scoped questions because the upstream prompt explicitly tries to keep the output extremely short.
- If results are shallow, improve the initial question and follow-up answers before increasing depth.
- For automation, consider patching `src/run.ts` or calling library functions directly instead of driving the interactive CLI by hand.
