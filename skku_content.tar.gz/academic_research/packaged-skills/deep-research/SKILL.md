---
name: deep-research
description: Use when Codex needs to set up, run, adapt, or troubleshoot the dzhng/deep-research project for recursive web research. Covers breadth and depth tuning, Firecrawl and model configuration, CLI or API usage, iterative follow-up questioning, report generation, and debugging output or rate-limit issues.
---

# Deep Research

Package the upstream `dzhng/deep-research` project into a Codex-friendly workflow for iterative web research and markdown report generation.

## Workflow

1. Confirm the operating mode.
   The upstream project can run as:
   - an interactive CLI session
   - an API service
   - a Docker-based environment

2. Read the upstream operating details before execution.
   Open [references/upstream-workflow.md](references/upstream-workflow.md) for environment variables, commands, outputs, and implementation caveats.

3. Gather the minimum user inputs.
   - research question
   - breadth
   - depth
   - report versus short answer

4. Tune the run instead of accepting defaults blindly.
   - Keep breadth modest when rate limits are tight.
   - Increase depth only when the topic benefits from recursive exploration.
   - Prefer `report` mode for open-ended investigations.
   - Prefer `answer` mode for targeted factual questions.

5. Verify final artifacts.
   The upstream CLI writes `report.md` or `answer.md` in the working directory. Summarize both the saved artifact and the effective model and search configuration.

## Common Tasks

### Run a research session

Use the upstream `npm start` flow and answer the interactive prompts, or patch the repo if the user wants non-interactive automation.

### Switch providers

Use OpenAI-compatible providers via `OPENAI_KEY` and optional `OPENAI_ENDPOINT`, or switch to Fireworks by setting `FIREWORKS_KEY`.

### Expose an API

Use the API server mode from the upstream repo when the user wants to integrate the research engine into another service.

### Debug weak or slow runs

Check the configured provider, Firecrawl access, concurrency, context size, and whether the query is too broad for the selected depth.

## Notes

- This skill documents and operationalizes the upstream repository. It does not bundle the upstream code itself.
- If the user wants a runnable local copy, clone `dzhng/deep-research` into the workspace and work inside that checkout.
