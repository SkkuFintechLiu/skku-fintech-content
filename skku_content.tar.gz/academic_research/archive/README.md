# 学术研究归档

本目录保存不进入当前确认性证据链、但仍有溯源价值的材料。

- `legacy_reports/`：被规范 Markdown/PDF 替代的旧 HTML 报告。
- `smoke_results/2026-08-23/`：20 标的管线试跑及其 Figure 7。只能验证代码流程，不能作为 5,415 标的开发或确认结果。

归档文件不得被 `build_paper_tables.py`、`build_paper_figures.py` 或 `claim_registry` 当作正式输入。
