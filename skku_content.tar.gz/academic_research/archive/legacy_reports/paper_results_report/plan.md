# Report Plan

## Meta
- **Type**: Research Report
- **Topic**: 论文实验数据、结果、图像与统计检验说明
- **Audience**: 学术论文读者、量化研究者、审稿人
- **Language**: 中文

## Theme
- **Name**: Modern Minimalist
- **Colors**:
  - Background: `#fafafa`
  - Surface: `#f0f0f0`
  - Text: `#36454f`
  - Text Muted: `#708090`
  - Border: `#d3d3d3`
  - Primary: `#36454f`
  - Secondary: `#e8edf0`
- **Document Font**: InstrumentSans
- **Monospace Font**: GeistMono

## Structure
1. 实验设置 — 数据、标签、样本与评估口径
2. 核心结果 — `core`、`force`、`retrieval_aug` 的指标对比
3. 图像说明 — F1、LogLoss、bootstrap 分布、k 扫描曲线
4. 统计检验 — 配对 bootstrap 的均值、标准差、95% 置信区间与解释
5. 论文可直接引用的结论 — 如何在正文中描述结果与局限

## Visuals
| Visual | Type | Tool | Purpose |
|--------|------|------|---------|
| Chart 1 | Bar | ECharts | 展示 `core`、`force`、`retrieval_aug` 的 Macro-F1 |
| Chart 2 | Bar | ECharts | 展示三种模型的 LogLoss |
| Figure 3 | Histogram | PNG | 展示 bootstrap 的 ΔMacro-F1 分布 |
| Chart 4 | Line | ECharts | 展示不同 k 下 retrieval_aug 的 Macro-F1 |

## Key Arguments / Thesis
- “博弈力度”特征提供了稳定但有限的增益。
- 检索增强显著提高了屏障事件三分类的 Macro-F1。
- 检索增强当前主要改善判别能力，概率校准仍需后续优化。
- 配对 bootstrap 支持该提升具有统计显著性。

