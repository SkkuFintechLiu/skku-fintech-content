# Data and sample summary

| Market | Files | Rows | Parse OK | Canonical OK | Nonpositive OHLC | Duplicate Close cols | Start | End |
|---|---:|---:|---:|---:|---:|---:|---|---|
| China stocks | 41 | 99985 | 40 | 40 | 0 | 0 | 2015-09-14 | 2026-08-11 |
| Futures | 28 | 66004 | 28 | 28 | 6 | 18 | 2015-01-02 | 2026-08-11 |
| Crypto | 15 | 50788 | 15 | 15 | 12 | 12 | 2010-07-17 | 2026-08-11 |
| US stocks | 0 | 0 | 0 | 0 | 0 | 0 | - | - |
| Total | 84 | 216777 | 83 | 83 | 18 | 30 | 2010-07-17 | 2026-08-11 |

## Main experiment sample

- Effective assets: 6
- Samples used: 15000
- Window length: L=60
- Horizon: H=3
- Label distribution: TP 11.21%, SL 33.88%, None 54.91%