# academic_research — 学术研究谱系

## 这是什么

预注册（pre-registered）的**收益排序实证研究**论文工作区。核心研究问题：K线"结构/博弈力度"
特征能否对未来横截面收益排序产生稳定、可外推的预测力（以 RankIC、HAC t、positive-IC ratio 评估）。

- 目标变量：横截面收益排序（多 horizons H ∈ {1, 5, 15, 45} 日）
- 核心模块：`paper_research/`（config / guard / strategy / baselines / placebos / statistics / crsp / hedge / retrieval / structure）
- 稿件：`manuscript/`（paper.md + 各 section + references.bib + latex）
- 预注册确认期：`confirmatory_research/`（含 decision_report / audit_report / coverage_report）
- 编译产物：`output/pdf/main.pdf`
- 历史报告：`archive/legacy_reports/`（只作溯源，不进入当前证据链）
- 单元测试：`tests/`

## 运行入口（在 academic_research/ 内执行）

- 跑确认期流水线：`python run_confirmatory_pipeline.py`
- 编译稿件（依赖 pandoc + tectonic）：`python compile_manuscript.py`
- 跑测试：`python -m pytest tests`
- 美股 RankIC 验证：`python us_stock_factor_rankic.py`

## 数据依赖（符号链接，勿删）

- `us_stock_data` → `../shared_data/us_stock_data`
- `market_data_audit` → `../shared_data/market_data_audit`
- `hierarchical_out` → `../trading_strategy/hierarchical_out`（交汇产物：交易谱系的 KNN/HB-RAG 诊断输出，被 build_claim_registry 引用）
- `kb_out_us_stock` → `../trading_strategy/kb_out_us_stock`（交汇产物：交易谱系的逐样本面板，被 S_i 因子验证引用）
- `data/000906_constituents` — A股成分股（学术谱系自带，非链接）

## 完整性校验

`python -c "import os; print(os.path.exists('us_stock_data') and os.path.exists('paper_research') and os.path.exists('manuscript'))"`

应为 `True`。若返回 `False`，说明符号链接未生效（多见于跨机器拷贝后）——见根目录 README 的迁移说明。

## 注意事项

- `confirmatory_research/decision_report.json` 中 `confirmation_ready=true` 仅表示审计门控开放，
  `results/confirmation/` 目录尚未产出（2025 确认计算待执行），4 项 2025 主张仍为 PENDING。
  不要把 "audit passed" 误读为 "结论成立"。
- `confirmatory_research/results/` 不保存 smoke 面板；开发或抽样试跑必须写入临时目录，防止
  小样本产物被图表构建器误识别为正式证据。
- 本谱系与 `trading_strategy/` 目标变量、标签、评估完全不同，**请勿在正文互引对方数值**。
