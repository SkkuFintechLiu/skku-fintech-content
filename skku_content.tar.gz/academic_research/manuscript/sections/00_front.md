# 价格结构、历史类比与股票收益可预测性：来自中国 A 股的证据

## 摘要

本文研究一个基础但尚未得到严格回答的问题：由日频开盘价、最高价、最低价、收盘价与成交量形成的价格结构，是否包含可重复的横截面收益信息，以及这种信息能否在真实交易约束下转化为经济收益。本文将主观的 K 线观察改写为因果状态机，以已确认的周线趋势、日线 swing、BOS、CHoCH、突破后收回事件和结构反应区描述当前状态；随后在严格成熟的历史样本中，由 KNN 估计 SELL/WAIT/BUY 状态概率，由历史行为检索增强模型（HB-RAG）估计未来收益、胜率、尾部收益、MFE、MAE 与最佳等待和持有期分布。两类信息在未来 1、5、15 与 45 个交易日分别形成横截面秩，再等权合成为联合选股因子。

本文把“预测信息”和“可交易性”设为两个相互独立的确认性主张。2015--2024 年只用于开发，2025 年为不再调参的确认期；标签成熟、邻居检索、模型估计和成交执行均服从时点约束。预测证据由 RankIC、Fama--MacBeth 回归、日期分块 bootstrap、横截面置换与跨期限 Holm 校正共同裁定；交易证据则进一步要求扣费后相对等权股票池和中证 800 的主动收益为正、差异显著且最大回撤不劣于基准。既有开发期证据显示，KNN+HB-RAG 具有显著的横截面排序信息，但相对基准的交易收益差尚未得到统计确认。2025 估计量只有在预注册、实现冻结、95% 时点股票日覆盖和确认计算全部通过后，才允许由主张注册表写入正文；否则论文保留门控状态并不作可部署策略结论。该处理使零结果、策略失效与数据门槛成为研究设计的一部分，而非事后删除的异常。

**关键词：** 价格结构；技术分析；最近邻；检索增强；横截面收益；预注册；A 股

## Abstract

This paper examines whether causal price structures extracted from daily OHLCV records contain repeatable information about the cross-section of stock returns and whether such information survives realistic implementation constraints. We encode weekly and daily market structure as a causal state machine and combine two historical-analogy estimators: KNN state probabilities and an HB-RAG local outcome distribution. The two components produce horizon-specific ranks for 1-, 5-, 15-, and 45-trading-day returns. We pre-register separate evidentiary gates for predictive ranking and tradability. Data from 2015--2024 are used only for development, while 2025 is a locked confirmation period. Existing development evidence supports cross-sectional ranking information but does not establish statistically significant trading alpha. A 2025 estimate may enter the manuscript only after preregistration, implementation-freeze, 95% point-in-time stock-day coverage, and confirmatory-computation gates have all passed; otherwise the registry preserves the blocked state and no deployability claim is made. The design therefore treats data coverage, null results, and execution failures as first-class research outcomes rather than ex post exclusions.

**Keywords:** price structure; technical analysis; nearest neighbors; retrieval augmentation; cross-sectional returns; preregistration
