# Causal price-structure trading factor: development evidence

> Exploratory 2019--2024 evidence only. The frozen 2025 confirmation set is not read or changed.

## Factor definition

`structure_entry_factor = 0.30 trend alignment + 0.25 continuation + 0.15 pullback location + 0.15 price-volume confirmation + 0.15 reward space - 0.30 exhaustion risk`.

`structure_reversal_factor = 0.45 reward space + 0.35 exhaustion risk + 0.20 (1 - continuation)`. It is an explicitly post-hoc diagnostic from this development run and requires an unseen-period test before use.

The entry gate requires a positive local trend, non-bear market state, an active positive structure phase, a 0.25--4 ATR pullback, reward-to-risk proxy >= 1, and no immediate exhaustion/reversal state.

## Scope

- Candidate rows: 58,200
- Assets: 1,618
- Dates: 2019-01-08 to 2024-12-30
- Mean gate coverage: 14.43%

## Factor results

| model                     |   horizon |   dates |   mean_rank_ic |    hac_t |   positive_ic_rate |
|:--------------------------|----------:|--------:|---------------:|---------:|-------------------:|
| retrieval_only            |         1 |     291 |      0.0345152 |  2.62441 |           0.587629 |
| retrieval_only            |         5 |     290 |      0.0877989 |  7.24526 |           0.665517 |
| retrieval_only            |        15 |     288 |      0.127729  |  7.47719 |           0.739583 |
| retrieval_only            |        45 |     282 |      0.163948  |  7.18466 |           0.815603 |
| structure_only            |         1 |     291 |     -0.0144556 | -1.43523 |           0.457045 |
| structure_only            |         5 |     290 |     -0.0373392 | -3.76725 |           0.393103 |
| structure_only            |        15 |     288 |     -0.0531371 | -3.53667 |           0.381944 |
| structure_only            |        45 |     282 |     -0.06852   | -3.08532 |           0.358156 |
| structure_reversal_only   |         1 |     291 |      0.0280592 |  2.5508  |           0.563574 |
| structure_reversal_only   |         5 |     290 |      0.0576919 |  5.62542 |           0.62069  |
| structure_reversal_only   |        15 |     288 |      0.0725296 |  4.91189 |           0.652778 |
| structure_reversal_only   |        45 |     282 |      0.0813594 |  3.57136 |           0.680851 |
| structure_retrieval_blend |         1 |     291 |      0.0127427 |  1.68667 |           0.556701 |
| structure_retrieval_blend |         5 |     290 |      0.0337741 |  3.66917 |           0.568966 |
| structure_retrieval_blend |        15 |     288 |      0.0480748 |  4.31825 |           0.604167 |
| structure_retrieval_blend |        45 |     282 |      0.0582913 |  3.07859 |           0.648936 |

## Incremental RankIC relative to retrieval-only

| model                     | base_model     |   horizon |   mean_delta |     ci_low |     ci_high |   p_one_sided |   holm_p |
|:--------------------------|:---------------|----------:|-------------:|-----------:|------------:|--------------:|---------:|
| structure_only            | retrieval_only |         1 |  -0.0489708  | -0.0809799 | -0.00799681 |         0.991 |        1 |
| structure_only            | retrieval_only |         5 |  -0.125138   | -0.157328  | -0.0872753  |         1     |        1 |
| structure_only            | retrieval_only |        15 |  -0.180866   | -0.231732  | -0.12231    |         1     |        1 |
| structure_only            | retrieval_only |        45 |  -0.232468   | -0.310665  | -0.178646   |         1     |        1 |
| structure_reversal_only   | retrieval_only |         1 |  -0.00645598 | -0.0244072 |  0.0164769  |         0.663 |        1 |
| structure_reversal_only   | retrieval_only |         5 |  -0.0301071  | -0.0514017 | -0.00733947 |         0.997 |        1 |
| structure_reversal_only   | retrieval_only |        15 |  -0.0551993  | -0.0836127 | -0.0249587  |         1     |        1 |
| structure_reversal_only   | retrieval_only |        45 |  -0.0825891  | -0.137919  | -0.0372938  |         1     |        1 |
| structure_retrieval_blend | retrieval_only |         1 |  -0.0217725  | -0.0392516 |  5.7077e-05 |         0.974 |        1 |
| structure_retrieval_blend | retrieval_only |         5 |  -0.0540248  | -0.0738819 | -0.0332761  |         1     |        1 |
| structure_retrieval_blend | retrieval_only |        15 |  -0.0796541  | -0.111214  | -0.0452795  |         1     |        1 |
| structure_retrieval_blend | retrieval_only |        45 |  -0.105657   | -0.152352  | -0.0727316  |         1     |        1 |

## Portfolio diagnostics

| system                   |   periods |   total_return |   annualized_return |    sharpe |   max_drawdown |   positive_period_rate |   average_holdings |   average_turnover |   average_gate_coverage |
|:-------------------------|----------:|---------------:|--------------------:|----------:|---------------:|-----------------------:|-------------------:|-------------------:|------------------------:|
| retrieval_top30          |       291 |       0.164703 |           0.0267583 |  0.126024 |      -0.332224 |               0.498282 |            29.8935 |           0.612829 |                 1       |
| structure_top30          |       291 |      -0.625479 |          -0.156417  | -0.521134 |      -0.791619 |               0.450172 |            29.8969 |           0.667125 |                 1       |
| structure_reversal_top30 |       291 |      -0.322279 |          -0.065157  | -0.23708  |      -0.624041 |               0.4811   |            29.8763 |           0.502176 |                 1       |
| structure_gate_retrieval |       291 |      -0.29809  |          -0.0594615 | -0.257741 |      -0.597114 |               0.295533 |            18.4227 |           0.560398 |                 0.14433 |
| structure_gate_blend     |       291 |      -0.358942 |          -0.0741185 | -0.314854 |      -0.612189 |               0.28866  |            18.4227 |           0.544246 |                 0.14433 |

## Incremental portfolio returns relative to retrieval-only

| system                   | base_system     |   mean_delta |      ci_low |      ci_high |   p_one_sided |   holm_p |
|:-------------------------|:----------------|-------------:|------------:|-------------:|--------------:|---------:|
| structure_top30          | retrieval_top30 |  -0.00389888 | -0.00715308 | -0.000140903 |         0.981 |        1 |
| structure_reversal_top30 | retrieval_top30 |  -0.00186078 | -0.00432246 |  0.000928602 |         0.911 |        1 |
| structure_gate_retrieval | retrieval_top30 |  -0.00174026 | -0.00429071 |  0.000795273 |         0.889 |        1 |
| structure_gate_blend     | retrieval_top30 |  -0.00205189 | -0.00454441 |  0.000618541 |         0.927 |        1 |

## Interpretation boundary

- This is a fixed-form factor construction, not a return-optimized parameter search.
- Structure-only, structure-reversal, structure-gated, and blended systems are reported separately; no ranking result is treated as evidence of deployability.
- `structure_exit_risk` is a daily-monitoring contract for later execution work, not an evaluated intraperiod exit in this weekly diagnostic.