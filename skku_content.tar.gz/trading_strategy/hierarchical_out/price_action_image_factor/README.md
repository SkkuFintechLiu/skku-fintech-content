# Price Action structure-image factor: development experiment

> This is exploratory evidence using data no later than 2024. It does not alter the frozen confirmatory pipeline and must not be described as 2025 confirmation.

## Data

- Source files: 5415
- Usable assets: 5267
- Weekly rows before liquidity filtering: 1,858,077
- Candidate observations: 92,600
- Assets in candidate panel: 1,889
- Dates: 2015-07-01 to 2024-12-30

## Best model by horizon

|   horizon | variant        |   mean_rank_ic |   hac_t |   observations |
|----------:|:---------------|---------------:|--------:|---------------:|
|         1 | F0_aggregate   |      0.0258431 | 2.52329 |          58200 |
|         5 | I6_reward_only |      0.0744032 | 7.15951 |          58200 |
|        15 | I6_reward_only |      0.121626  | 7.62307 |          58200 |
|        45 | I6_reward_only |      0.171487  | 7.55328 |          58200 |

## Full structure-image factor

|   horizon |   mean_rank_ic |   hac_t |   positive_ic_rate |   mean_neighbor_distance |   mean_effective_n |
|----------:|---------------:|--------:|-------------------:|-------------------------:|-------------------:|
|         1 |      0.0164023 | 2.23702 |           0.508591 |                  3.37966 |            29.7637 |
|         5 |      0.0416797 | 6.01818 |           0.635739 |                  3.37966 |            29.7637 |
|        15 |      0.0700881 | 7.04329 |           0.731959 |                  3.37966 |            29.7637 |
|        45 |      0.100633  | 8.40172 |           0.780069 |                  3.37966 |            29.7637 |

## Increment relative to F0

| variant                 | base_variant          |   horizon |   mean_delta |     ci_low |     ci_high |   p_one_sided |   holm_p |
|:------------------------|:----------------------|----------:|-------------:|-----------:|------------:|--------------:|---------:|
| F1_ordered_path         | F0_aggregate          |         1 | -0.00133664  | -0.0139802 |  0.0123938  |        0.5825 |        1 |
| F1_ordered_path         | F0_aggregate          |         5 | -0.0249857   | -0.0376769 | -0.0133733  |        1      |        1 |
| F1_ordered_path         | F0_aggregate          |        15 | -0.0421638   | -0.0585327 | -0.0260215  |        1      |        1 |
| F1_ordered_path         | F0_aggregate          |        45 | -0.0466879   | -0.0745628 | -0.0295353  |        1      |        1 |
| F6_full_structure_image | F0_aggregate          |         1 | -0.00944085  | -0.0215632 |  0.00687048 |        0.865  |        1 |
| F6_full_structure_image | F0_aggregate          |         5 | -0.0323498   | -0.0457203 | -0.0185681  |        1      |        1 |
| F6_full_structure_image | F0_aggregate          |        15 | -0.0498221   | -0.0697401 | -0.0299182  |        1      |        1 |
| F6_full_structure_image | F0_aggregate          |        45 | -0.0679375   | -0.104644  | -0.0467342  |        1      |        1 |
| F6_full_structure_image | P1_path_order_shuffle |         1 | -0.000214857 | -0.0105121 |  0.00941604 |        0.4875 |        1 |
| F6_full_structure_image | P1_path_order_shuffle |         5 | -0.00304757  | -0.0113394 |  0.00510273 |        0.7125 |        1 |
| F6_full_structure_image | P1_path_order_shuffle |        15 | -0.0146399   | -0.0228433 | -0.00650127 |        1      |        1 |
| F6_full_structure_image | P1_path_order_shuffle |        45 | -0.0117888   | -0.0208187 | -0.00435782 |        1      |        1 |

## Portfolio diagnostic

| variant                 | strategy_spec   |   weeks |   total_return |   annualized_return |     sharpe |   max_drawdown |   positive_week_rate |   active_week_rate |   average_holdings_when_active |   average_turnover |   average_holdings |
|:------------------------|:----------------|--------:|---------------:|--------------------:|-----------:|---------------:|---------------------:|-------------------:|-------------------------------:|-------------------:|-------------------:|
| F0_aggregate            | gated_top30     |     290 |      1.84397   |          0.199193   |  0.801626  |      -0.238742 |            0.0724138 |           0.165517 |                        1.5     |           0.3      |           0.248276 |
| I4_second_leg_only      | gated_top30     |     290 |      1.20439   |          0.147258   |  0.562899  |      -0.270682 |            0.0793103 |           0.172414 |                        1.34    |           0.32069  |           0.231034 |
| I7_state_events_no_path | gated_top30     |     290 |      0.768184  |          0.104126   |  0.450302  |      -0.336644 |            0.062069  |           0.155172 |                        1.57778 |           0.277586 |           0.244828 |
| I2_regime_only          | gated_top30     |     290 |      0.560468  |          0.0804044  |  0.266871  |      -0.484422 |            0.062069  |           0.144828 |                        1.40476 |           0.264368 |           0.203448 |
| F2_market_regime        | gated_top30     |     290 |      0.46591   |          0.0687307  |  0.266654  |      -0.592957 |            0.110345  |           0.2      |                        1.43103 |           0.337931 |           0.286207 |
| F5_climax               | gated_top30     |     290 |      0.335329  |          0.0515414  |  0.182462  |      -0.315253 |            0.103448  |           0.2      |                        1.48276 |           0.348276 |           0.296552 |
| F3_breakout_follow      | gated_top30     |     290 |      0.210789  |          0.0338004  |  0.122953  |      -0.49284  |            0.1       |           0.203448 |                        1.30508 |           0.358621 |           0.265517 |
| I4_second_leg_only      | ranking_top30   |     290 |      0.207067  |          0.0332474  |  0.152863  |      -0.30715  |            0.506897  |           1        |                       29.9931  |           0.621149 |          29.9931   |
| I3_follow_only          | ranking_top30   |     290 |      0.185206  |          0.0299706  |  0.139832  |      -0.335664 |            0.493103  |           1        |                       29.9931  |           0.627471 |          29.9931   |
| F0_aggregate            | ranking_top30   |     290 |      0.166452  |          0.0271195  |  0.127484  |      -0.332224 |            0.5       |           1        |                       29.9966  |           0.611494 |          29.9966   |
| F1_ordered_path         | gated_top30     |     290 |      0.109404  |          0.0182075  |  0.0697091 |      -0.48334  |            0.1       |           0.203448 |                        1.28814 |           0.351724 |           0.262069 |
| I6_reward_only          | ranking_top30   |     290 |      0.085206  |          0.0143125  |  0.0660153 |      -0.369672 |            0.506897  |           1        |                       29.9966  |           0.626667 |          29.9966   |
| F4_second_leg           | gated_top30     |     290 |      0.0331067 |          0.00567657 |  0.021674  |      -0.487165 |            0.0931034 |           0.186207 |                        1.2963  |           0.331034 |           0.241379 |
| I2_regime_only          | ranking_top30   |     290 |     -0.0222436 |         -0.0039018  | -0.0185216 |      -0.381919 |            0.496552  |           1        |                       29.9931  |           0.682644 |          29.9931   |
| I7_state_events_no_path | ranking_top30   |     290 |     -0.0372482 |         -0.00657541 | -0.030114  |      -0.407695 |            0.493103  |           1        |                       29.9931  |           0.735517 |          29.9931   |
| I5_climax_only          | ranking_top30   |     290 |     -0.0731558 |         -0.0131163  | -0.0621457 |      -0.431127 |            0.496552  |           1        |                       29.9966  |           0.659885 |          29.9966   |
| P1_path_order_shuffle   | gated_top30     |     290 |     -0.0897329 |         -0.0162068  | -0.0801518 |      -0.522665 |            0.0551724 |           0.131034 |                        1.44737 |           0.241379 |           0.189655 |
| F6_full_structure_image | gated_top30     |     290 |     -0.127053  |         -0.0233385  | -0.136672  |      -0.399339 |            0.0896552 |           0.182759 |                        1.64151 |           0.299138 |           0.3      |
| I6_reward_only          | gated_top30     |     290 |     -0.214619  |         -0.0411167  | -0.149977  |      -0.465501 |            0.0862069 |           0.193103 |                        1.44643 |           0.341379 |           0.27931  |
| F5_climax               | ranking_top30   |     290 |     -0.223118  |         -0.0429283  | -0.179274  |      -0.572977 |            0.472414  |           1        |                       29.9931  |           0.78977  |          29.9931   |
| F1_ordered_path         | ranking_top30   |     290 |     -0.230875  |         -0.044596   | -0.194769  |      -0.524043 |            0.472414  |           1        |                       29.9897  |           0.777218 |          29.9897   |
| P1_path_order_shuffle   | ranking_top30   |     290 |     -0.307059  |         -0.0617597  | -0.26194   |      -0.599925 |            0.47931   |           1        |                       29.9966  |           0.782299 |          29.9966   |
| F4_second_leg           | ranking_top30   |     290 |     -0.328894  |         -0.0669659  | -0.286772  |      -0.589987 |            0.489655  |           1        |                       29.9931  |           0.784253 |          29.9931   |
| F3_breakout_follow      | ranking_top30   |     290 |     -0.338902  |         -0.0693992  | -0.298958  |      -0.592156 |            0.472414  |           1        |                       29.9931  |           0.782184 |          29.9931   |
| F2_market_regime        | ranking_top30   |     290 |     -0.33982   |         -0.0696238  | -0.296907  |      -0.587689 |            0.475862  |           1        |                       29.9897  |           0.776643 |          29.9897   |
| F6_full_structure_image | ranking_top30   |     290 |     -0.375077  |         -0.0784561  | -0.330643  |      -0.617169 |            0.472414  |           1        |                       29.9897  |           0.797804 |          29.9897   |
| I5_climax_only          | gated_top30     |     290 |     -0.410043  |         -0.0876317  | -0.343623  |      -0.624308 |            0.0793103 |           0.231034 |                        1.64179 |           0.395402 |           0.37931  |
| I3_follow_only          | gated_top30     |     290 |     -0.437085  |         -0.0950414  | -0.503157  |      -0.532439 |            0.0517241 |           0.141379 |                        1.46341 |           0.265517 |           0.206897 |

The highest development-period total return is F0_aggregate (184.40%). This ranking is descriptive and is not a deployment decision.

## Interpretation rules

- F1 tests whether ordered paths add information beyond aggregate candle statistics.
- P1 independently shuffles each path block. Similar performance to F6 would weaken the claim that temporal order matters.
- F2-F6 are cumulative ablations, so an improvement must first appear at the step that introduced it.
- Portfolio performance is reported separately from RankIC. Neither result implies the other.