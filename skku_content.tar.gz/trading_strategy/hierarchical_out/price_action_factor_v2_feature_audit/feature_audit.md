# 价格结构图像因子 v2：特征可用性审计

## 边界

- 本产物只从每个案例截至决策日的 OHLCV 和既有因果结构状态提取特征。
- 不读取未来收益、标签、MFE/MAE、历史邻居结果或 2025 年数据；不生成订单、试仓、行业门控或收益结论。
- 旧版状态机、旧盲图包和旧回测均未修改。这里的 `ELIGIBLE` 仅指冻结初值下可计算的收益空间资格，不是买入建议。
- 日频 OHLCV 只能提供价格与成交量代理；“附近确认阻力”表示历史确认 pivot 的几何统计，不表示真实订单簿、机构成本或订单流。

## 分层定义

| 层 | 记录内容 | 不做的推断 |
|---|---|---|
| 结构事实 | 周线背景、既有模型/阶段、已观察突破与确认时间 | 不把 `READY` 等同于应下单 |
| 经济资格 | 保护距离、上方空间、收益风险比 | 不改变原结构事件或优化阈值 |
| 调整与位置 | 事件后已知的回撤深度/时长、周线箱体位置、历史确认高点密度 | 不用未来摆动终点定义调整 |
| 分阶段量价 | 突破日、截止日和事件期间相对前 20 个有效日的成交量 | 不把放量当作普适确认规则 |
| 检索接口 | 拟议连续字段及既有语义匹配 | 不运行 KNN/HB-RAG 或读取邻居结果 |

## 60 个遮挡案例的字段覆盖率

| 字段 | 可用比例 |
|---|---:|
| `zone_to_break_sessions` | 20.0% |
| `break_age_sessions` | 20.0% |
| `break_relative_volume_20` | 20.0% |
| `overhead_space_atr` | 31.7% |
| `reward_risk` | 31.7% |
| `adjustment_fraction` | 31.7% |
| `protected_distance_atr` | 48.3% |
| `adjustment_depth_atr` | 66.7% |
| `adjustment_age_sessions` | 66.7% |
| `event_relative_volume_mean` | 66.7% |
| `nearby_resistance_spread_atr` | 86.7% |
| `weekly_range_position` | 96.7% |
| `nearby_confirmed_resistance_count` | 100.0% |
| `current_relative_volume_20` | 100.0% |
| `volume_data_coverage` | 100.0% |

## 八个已知案例的复核清单

这 4 个校准案例和 4 个反例只能检查解释是否更清楚，不能用作泛化或收益证据。

| 案例 | 角色 | 结构事实 | 经济资格 | 量价证据 | 关注 |
|---|---|---|---|---|---|
| RANGE-08 | CALIBRATION | NO_ACTIVE_EVENT | NOT_EVALUABLE | CAUSAL_PHASED_DESCRIPTIVE | WAIT |
| RANGE-12 | COUNTEREXAMPLE | NO_CONFIRMED_EVENT | ELIGIBLE_BY_FROZEN_INITIAL_RULE | CAUSAL_PHASED_DESCRIPTIVE | WAIT |
| TREND-03 | CALIBRATION | CONFIRMED_EVENT | ELIGIBLE_BY_FROZEN_INITIAL_RULE | CAUSAL_PHASED_DESCRIPTIVE | WATCH |
| TREND-04 | COUNTEREXAMPLE | CONFIRMED_EVENT | ELIGIBLE_BY_FROZEN_INITIAL_RULE | CAUSAL_PHASED_DESCRIPTIVE | WATCH |
| TREND-05 | CALIBRATION | BREAK_OBSERVED_AWAITING_CONFIRMATION | NOT_EVALUABLE | CAUSAL_PHASED_DESCRIPTIVE | WAIT |
| TREND-13 | COUNTEREXAMPLE | NO_ACTIVE_EVENT | NOT_EVALUABLE | CAUSAL_PHASED_DESCRIPTIVE | WAIT |
| WAIT-06 | CALIBRATION | NO_CONFIRMED_EVENT | NOT_EVALUABLE | UNRESOLVED | AVOID |
| WAIT-08 | COUNTEREXAMPLE | NO_CONFIRMED_EVENT | NOT_EVALUABLE | UNRESOLVED | AVOID |

## 下一道门槛

1. 先用四维协议复核这八例是否将结构事实、证据充分性、行动偏好与时点清晰度分开。
2. 对通过定义的字段运行独立 D01-D16 与成熟标签/邻居覆盖审计。
3. 只有语义验收、数据审计和检索时点审计通过后，才可激活 KNN/HB-RAG 或进入收益实验。
