# 正式 60 例反馈归档与裁定

## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: validate
- Verification Status: 协议计数可复算；人工正式验收按下方冻结门槛裁定。
- Version Label: formal60_v2_response_summary
- 数据范围：仅冻结案例事实与本次人工回答，无未来收益。

## 原协议裁定

**结构验收未通过。**
四维完整回答 60/60，含文字意见 30 例。
完整作答不等于验收通过；不自动更改选择，不把行动偏好当作结构评分。

| 类别 | 结构准确 | 证据足够 | 行动符合 | 时点清晰 | 结构 18/20 门槛 |
|---|---:|---:|---:|---:|---|
| 趋势 | 19/20 | 17/20 | 17/20 | 19/20 | 达到 |
| 震荡 | 17/20 | 13/20 | 10/20 | 13/20 | 未达到 |
| 等待 | 14/20 | 14/20 | 14/20 | 14/20 | 未达到 |

上述比例只是本包单次人工判断的描述统计，不是模型预测准确率、胜率或市场总体估计。
未计算显著性、置信区间或评审者间一致性，也不由趋势单项过线推导该分支可交易。

### 阻断项

- human reviewer identifier required
- F-TREND-01: timing not cleared
- F-RANGE-02: timing not cleared
- F-RANGE-15: timing not cleared
- F-RANGE-16: timing not cleared
- F-RANGE-17: timing not cleared
- F-RANGE-18: timing not cleared
- F-RANGE-19: timing not cleared
- F-RANGE-20: timing not cleared
- F-WAIT-03: timing not cleared
- F-WAIT-07: timing not cleared
- F-WAIT-08: timing not cleared
- F-WAIT-11: timing not cleared
- F-WAIT-17: timing not cleared
- F-WAIT-18: timing not cleared
- RANGE: requires at least 18/20 accurate structure judgments
- WAIT: requires at least 18/20 accurate structure judgments

审核人字段若为空，原样保存，不用账户名或对话身份代填；补身份也不能消除结构与时点未通过。
时点有问题/不清楚代表人工未确认，不直接证明代码发生未来信息泄漏，也不能据工程测试改为清晰。
震荡 READY 的候选覆盖缺口仍在，不借其他阶段或合成测试放行。

## 逐例意见与原状态

下表完整保留全部非空意见。文字均为审核者判断，不视为已验证收益、订单流事实或自动交易指令。
没有文字的案例也保存在 [完整 60 例关联台账](case_reviews.json)。

| 案例及图 | 标的 / 截止日 | 周线背景 / 当前阶段 / 旧关注 | 四维原回答（结构 / 证据 / 行动 / 时点） | 原意见 |
|---|---|---|---|---|
| [F-TREND-01](../../charts/F-TREND-01.png) | 000158 / 2020-04-21 | UP / READY / WATCH | NEEDS_CHANGE / INSUFFICIENT / NEEDS_CHANGE / ISSUE | 明显是突破失败后的一段深度回调，没有任何价值 |
| [F-TREND-04](../../charts/F-TREND-04.png) | 000020 / 2022-09-08 | UP / READY / WATCH | ACCURATE / INSUFFICIENT / MATCH / CLEAR | 随着交易量的下滑，价格下降，说明市场当中的空头多，市场的调整还没有结束 |
| [F-TREND-11](../../charts/F-TREND-11.png) | 003023 / 2024-07-09 | UP / INVALIDATED / WAIT | ACCURATE / SUFFICIENT / NEEDS_CHANGE / CLEAR | 交易量没有显著上涨，还有调整的时间 |
| [F-TREND-19](../../charts/F-TREND-19.png) | 002364 / 2023-02-24 | UP / WAIT_TRIGGER / WAIT | ACCURATE / INSUFFICIENT / NEEDS_CHANGE / CLEAR | 明显收到了周线上限的压制，突破无力后的回踩 |
| [F-RANGE-02](../../charts/F-RANGE-02.png) | 002969 / 2023-10-16 | RANGE / BREAK_CONFIRMED / WAIT | ACCURATE / UNCLEAR / UNCLEAR / UNCLEAR | 交易量放量显著，不是震荡而是突破 |
| [F-RANGE-09](../../charts/F-RANGE-09.png) | 600213 / 2024-01-31 | RANGE / INVALIDATED / WAIT | ACCURATE / SUFFICIENT / NEEDS_CHANGE / CLEAR | 上涨无力，还会继续下跌 |
| [F-RANGE-11](../../charts/F-RANGE-11.png) | 603585 / 2019-08-09 | RANGE / FAILED_BREAK_PENDING / WAIT | ACCURATE / SUFFICIENT / NEEDS_CHANGE / CLEAR | 上涨无力，还会继续下跌 |
| [F-RANGE-12](../../charts/F-RANGE-12.png) | 002285 / 2021-09-13 | RANGE / FAILED_BREAK_PENDING / WAIT | ACCURATE / INSUFFICIENT / NEEDS_CHANGE / CLEAR | 上涨结构被强势破坏，转变为下跌趋势，等待企稳后才有反弹/反转的可能性 |
| [F-RANGE-13](../../charts/F-RANGE-13.png) | 002213 / 2024-01-17 | RANGE / FAILED_BREAK_PENDING / WAIT | ACCURATE / SUFFICIENT / MATCH / CLEAR | 量能持续萎缩，下降阶段没有结束 |
| [F-RANGE-14](../../charts/F-RANGE-14.png) | 600674 / 2024-10-25 | RANGE / FAILED_BREAK_PENDING / WAIT | ACCURATE / SUFFICIENT / MATCH / CLEAR | 上方空头压制力量很强，还需要很长时间的震荡/下跌，才能获得上涨的机会 |
| [F-RANGE-15](../../charts/F-RANGE-15.png) | 000922 / 2023-09-01 | RANGE / FAILED_BREAK_PENDING / WAIT | ACCURATE / SUFFICIENT / NEEDS_CHANGE / ISSUE | 突破失败，后续可能是长时间的小幅震荡下行，上涨的希望不大，预计有2周级别的调整时间 |
| [F-RANGE-16](../../charts/F-RANGE-16.png) | 002541 / 2022-05-09 | RANGE / WAIT_TRIGGER / WAIT | ACCURATE / INSUFFICIENT / NEEDS_CHANGE / ISSUE | 下降通道开启，长时间的下降概率大 |
| [F-RANGE-17](../../charts/F-RANGE-17.png) | 300289 / 2019-01-31 | RANGE / WAIT_TRIGGER / WAIT | ACCURATE / INSUFFICIENT / NEEDS_CHANGE / ISSUE | 下降阶段没有结束，没有看到反弹/反转的可能性 |
| [F-RANGE-18](../../charts/F-RANGE-18.png) | 300886 / 2021-07-06 | RANGE / WAIT_TRIGGER / WAIT | NEEDS_CHANGE / INSUFFICIENT / NEEDS_CHANGE / ISSUE | 下降阶段没有结束，没有看到反弹/反转/维持的可能性 |
| [F-RANGE-19](../../charts/F-RANGE-19.png) | 300139 / 2020-05-06 | RANGE / WAIT_TRIGGER / WAIT | NEEDS_CHANGE / INSUFFICIENT / NEEDS_CHANGE / ISSUE | 同上一个回答一样 |
| [F-RANGE-20](../../charts/F-RANGE-20.png) | 603421 / 2020-04-30 | RANGE / WAIT_TRIGGER / WAIT | NEEDS_CHANGE / INSUFFICIENT / NEEDS_CHANGE / ISSUE | 没有等待的必要，下降还没有结束，还没有开启盘整阶段 |
| [F-WAIT-01](../../charts/F-WAIT-01.png) | 688083 / 2024-11-20 | UP / WAIT / WAIT | ACCURATE / SUFFICIENT / MATCH / CLEAR | 突破被压制，会开启一段下降/盘整，值得观察 |
| [F-WAIT-03](../../charts/F-WAIT-03.png) | 300757 / 2022-09-08 | UP / WAIT / WAIT | NEEDS_CHANGE / INSUFFICIENT / NEEDS_CHANGE / ISSUE | 突破失败，价格下降伴随着交易量萎缩，下降通道完全开启 |
| [F-WAIT-05](../../charts/F-WAIT-05.png) | 601226 / 2024-12-06 | UP / WAIT / WAIT | ACCURATE / SUFFICIENT / MATCH / CLEAR | 上涨阶段的最后时刻，观察是否有增量资金/利好，没有的话可能转为阶段性的下降调整 |
| [F-WAIT-06](../../charts/F-WAIT-06.png) | 301188 / 2023-11-06 | DOWN / WAIT / AVOID | ACCURATE / SUFFICIENT / MATCH / CLEAR | 买入的好机会 |
| [F-WAIT-07](../../charts/F-WAIT-07.png) | 300436 / 2021-09-27 | DOWN / WAIT / AVOID | NEEDS_CHANGE / INSUFFICIENT / NEEDS_CHANGE / ISSUE | 周线级别的支撑跌破后没有收回，交易量持续萎缩，价格下跌空间巨大，有可能开启新的下跌阶段 |
| [F-WAIT-08](../../charts/F-WAIT-08.png) | 688068 / 2022-08-11 | DOWN / WAIT / AVOID | NEEDS_CHANGE / INSUFFICIENT / NEEDS_CHANGE / ISSUE | 下方并没有安全空间，还有20%程度的下跌空间，但是可以观望后续的走势，如果有企稳的信号，可以建仓 |
| [F-WAIT-09](../../charts/F-WAIT-09.png) | 600749 / 2020-06-09 | DOWN / WAIT / AVOID | ACCURATE / SUFFICIENT / MATCH / CLEAR | 洗盘结束，随时可能开启上涨阶段 |
| [F-WAIT-10](../../charts/F-WAIT-10.png) | 600999 / 2021-08-30 | DOWN / WAIT / AVOID | ACCURATE / SUFFICIENT / MATCH / CLEAR | 到达支撑位置，可以等待建仓信号 |
| [F-WAIT-11](../../charts/F-WAIT-11.png) | 603059 / 2020-09-22 | RANGE / WAIT / WAIT | NEEDS_CHANGE / INSUFFICIENT / NEEDS_CHANGE / ISSUE | 没有明确的支撑位置，下方还有下跌空间，等待下跌企稳后才有企稳上涨的可能性 |
| [F-WAIT-12](../../charts/F-WAIT-12.png) | 688173 / 2024-07-31 | RANGE / WAIT / WAIT | ACCURATE / SUFFICIENT / MATCH / CLEAR | 等待突破信号才能买入，鉴于之前的下跌趋势过大，考虑退市/换壳等合规性 |
| [F-WAIT-13](../../charts/F-WAIT-13.png) | 002533 / 2020-07-15 | RANGE / WAIT / WAIT | ACCURATE / SUFFICIENT / MATCH / CLEAR | 洗盘-盘整结束，建议建仓/等待信号 |
| [F-WAIT-17](../../charts/F-WAIT-17.png) | 001318 / 2023-06-26 | TRANSITION / WAIT / WAIT | NEEDS_CHANGE / INSUFFICIENT / NEEDS_CHANGE / ISSUE | 跌破发行价的小盘股没有任何参考性 |
| [F-WAIT-18](../../charts/F-WAIT-18.png) | 600327 / 2024-02-05 | TRANSITION / WAIT / WAIT | NEEDS_CHANGE / INSUFFICIENT / NEEDS_CHANGE / ISSUE | 只有反弹的可能性，没有反转的趋势成立条件 |
| [F-WAIT-20](../../charts/F-WAIT-20.png) | 002370 / 2023-05-08 | TRANSITION / WAIT / WAIT | ACCURATE / SUFFICIENT / MATCH / CLEAR | 进入防御性的位置了，可以观察是否有上涨可能性 |

## 来源与后续边界

- 原始文件 SHA256：`44ed5c9e66b8046f58229ef9dbb48a338f76eac52324a1dcbe8d909a5420adf5`。
- 案例包 SHA256：`1072569952899926a77f7d098de37db2c457ab37eb3a60a6fce3a263bfa79ecf`。
- [原始回答](raw_response.json)、[冻结协议裁定](assessment.json)、[计数与门控摘要](feedback_summary.json)。
- 本次处理仅归档与诊断；正式包、结构代码、人工回答和门槛均未修改。
- 事件面板、KNN/HB-RAG、收益实验、2025 数据访问均未开启。
- [分歧解释与修订顺序](../../../../price_action_dual/FORMAL60_FEEDBACK_FINDINGS.md)。
