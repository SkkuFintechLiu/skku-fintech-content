# Price Action structure-image factor: development experiment

> This is exploratory evidence using data no later than 2024. It does not alter the frozen confirmatory pipeline and must not be described as 2025 confirmation.

## Data

- Source files: 500
- Usable assets: 495
- Weekly rows before liquidity filtering: 215,635
- Candidate observations: 92,502
- Assets in candidate panel: 462
- Dates: 2015-07-01 to 2024-12-30

## Best model by horizon

|   horizon | variant         |   mean_rank_ic |   hac_t |   observations |
|----------:|:----------------|---------------:|--------:|---------------:|
|         1 | F1_ordered_path |      0.0189289 | 3.02373 |          58200 |
|         5 | F0_aggregate    |      0.0465396 | 6.93386 |          58200 |
|        15 | F0_aggregate    |      0.07099   | 8.14194 |          58200 |
|        45 | F0_aggregate    |      0.087889  | 6.41528 |          58200 |

## Full structure-image factor

|   horizon |   mean_rank_ic |   hac_t |   positive_ic_rate |   mean_neighbor_distance |   mean_effective_n |
|----------:|---------------:|--------:|-------------------:|-------------------------:|-------------------:|
|         1 |      0.0161806 | 2.6425  |           0.556701 |                   3.3168 |            29.7639 |
|         5 |      0.0310394 | 5.2652  |           0.591065 |                   3.3168 |            29.7639 |
|        15 |      0.0514886 | 7.01659 |           0.67354  |                   3.3168 |            29.7639 |
|        45 |      0.0567218 | 6.3079  |           0.704467 |                   3.3168 |            29.7639 |

## Increment relative to F0

| variant                 |   horizon |   mean_delta |      ci_low |      ci_high |   p_one_sided |   holm_p |
|:------------------------|----------:|-------------:|------------:|-------------:|--------------:|---------:|
| F1_ordered_path         |         1 |   0.00597823 | -0.00419633 |  0.0158652   |         0.175 |        1 |
| F1_ordered_path         |         5 |  -0.00720185 | -0.0205861  |  0.00397947  |         0.925 |        1 |
| F1_ordered_path         |        15 |  -0.0135168  | -0.021983   | -0.00440711  |         1     |        1 |
| F1_ordered_path         |        45 |  -0.0289015  | -0.0457575  | -0.0153227   |         1     |        1 |
| F6_full_structure_image |         1 |   0.00322991 | -0.0122183  |  0.0119148   |         0.325 |        1 |
| F6_full_structure_image |         5 |  -0.0155003  | -0.0288746  | -0.00497203  |         1     |        1 |
| F6_full_structure_image |        15 |  -0.0195013  | -0.0319986  | -0.00709615  |         1     |        1 |
| F6_full_structure_image |        45 |  -0.0311672  | -0.0434287  | -0.0161594   |         1     |        1 |
| P1_path_order_shuffle   |         1 |   0.00502172 | -0.00374093 |  0.0115048   |         0.3   |        1 |
| P1_path_order_shuffle   |         5 |  -0.00795464 | -0.0161566  |  0.000470533 |         0.95  |        1 |
| P1_path_order_shuffle   |        15 |  -0.019664   | -0.0292695  | -0.0119916   |         1     |        1 |
| P1_path_order_shuffle   |        45 |  -0.0303072  | -0.0394517  | -0.019535    |         1     |        1 |

## Portfolio diagnostic

| variant                 |   weeks |   total_return |   annualized_return |    sharpe |   max_drawdown |   positive_week_rate |   average_turnover |   average_holdings |
|:------------------------|--------:|---------------:|--------------------:|----------:|---------------:|---------------------:|-------------------:|-------------------:|
| F0_aggregate            |     291 |       1.40898  |           0.165091  |  0.678285 |      -0.197853 |            0.103093  |           1        |           0.271478 |
| F3_breakout_follow      |     291 |       0.741365 |           0.101197  |  0.48888  |      -0.298162 |            0.130584  |           1        |           0.312715 |
| F4_second_leg           |     291 |       0.486389 |           0.0713106 |  0.32972  |      -0.389788 |            0.127148  |           1        |           0.305842 |
| F5_climax               |     291 |      -0.139482 |          -0.0257695 | -0.109934 |      -0.513299 |            0.106529  |           0.999427 |           0.426117 |
| F2_market_regime        |     291 |      -0.351488 |          -0.0722627 | -0.290858 |      -0.635265 |            0.0962199 |           1        |           0.274914 |
| P1_path_order_shuffle   |     291 |      -0.367879 |          -0.0766201 | -0.441369 |      -0.513647 |            0.0687285 |           1        |           0.33677  |
| F1_ordered_path         |     291 |      -0.403655 |          -0.0856401 | -0.429401 |      -0.579031 |            0.0859107 |           1        |           0.329897 |
| F6_full_structure_image |     291 |      -0.416913 |          -0.0894873 | -0.432764 |      -0.535871 |            0.0927835 |           1        |           0.439863 |

The highest development-period total return is F0_aggregate (140.90%). This ranking is descriptive and is not a deployment decision.

## Interpretation rules

- F1 tests whether ordered paths add information beyond aggregate candle statistics.
- P1 independently shuffles each path block. Similar performance to F6 would weaken the claim that temporal order matters.
- F2-F6 are cumulative ablations, so an improvement must first appear at the step that introduced it.
- Portfolio performance is reported separately from RankIC. Neither result implies the other.