# 价格结构图像因子 v2：四维小样本复核协议

## 材料边界

- 样本为 4 个已校准案例和 4 个固定反例，均非独立测试。
- 每例独立回答结构事实、证据充分性、行动偏好、时点清晰度；不合成为通过率。
- KNN/HB-RAG、收益标签、订单、试仓和行业门控均关闭。
- `ELIGIBLE_BY_FROZEN_INITIAL_RULE` 仅为已知空间的冻结初值资格，不表示建议买入。

## 问题定义

1. 结构事实：周线背景、事件状态、突破/确认时点和失效原因是否准确描述截至当日的信息？
2. 证据充分性：位置/调整/量价的可见记录，是否足以支持当前的结构解释？
3. 行动偏好：`WAIT`、`WATCH`、`AVOID` 与 `NONE` 是否符合处理意图？这不是收益判断。
4. 时点清晰度：是否明确只使用截至决策日的资料，且未使用未来行情、标签或邻居结果？

## TREND-03（CALIBRATION）

- 截止日 `2023-08-23`，标的 `300688`，来源时点核验 `True`。
- 背景 `UP`；结构 `TREND/READY`；事件 `CONFIRMED_EVENT`。
- 经济资格 `ELIGIBLE_BY_FROZEN_INITIAL_RULE`；保护距离 `2.6192074403558427` ATR；上方空间 `7.823695915891626` ATR；R/R `2.9870470720825026`。
- 量价 `CAUSAL_PHASED_DESCRIPTIVE`；突破相对量 `1.8026524053818227`；截止日相对量 `1.1099712481738462`。
- 关注 `WATCH`；仓位意图 `NONE`；candidate_for_future_semantic_review_not_an_order。

## TREND-05（CALIBRATION）

- 截止日 `2023-09-15`，标的 `600595`，来源时点核验 `True`。
- 背景 `UP`；结构 `TREND/BREAK_CONFIRMED`；事件 `BREAK_OBSERVED_AWAITING_CONFIRMATION`。
- 经济资格 `PENDING_CONFIRMATION`；保护距离 `2.622522522522523` ATR；上方空间 `None` ATR；R/R `None`。
- 量价 `CAUSAL_PHASED_DESCRIPTIVE`；突破相对量 `3.4598411861519556`；截止日相对量 `3.4598411861519556`。
- 关注 `WAIT`；仓位意图 `NONE`；no_confirmed_price_event。

## RANGE-08（CALIBRATION）

- 截止日 `2023-10-27`，标的 `600955`，来源时点核验 `True`。
- 背景 `UP`；结构 `RANGE/INVALIDATED`；事件 `NO_ACTIVE_EVENT`。
- 经济资格 `NOT_APPLICABLE_NO_CONFIRMED_EVENT`；保护距离 `None` ATR；上方空间 `None` ATR；R/R `None`。
- 量价 `CAUSAL_PHASED_DESCRIPTIVE`；突破相对量 `None`；截止日相对量 `1.6903286022786208`。
- 关注 `WAIT`；仓位意图 `NONE`；no_confirmed_price_event。

## WAIT-06（CALIBRATION）

- 截止日 `2022-04-14`，标的 `600667`，来源时点核验 `True`。
- 背景 `DOWN`；结构 `NONE/WAIT`；事件 `NO_CONFIRMED_EVENT`。
- 经济资格 `NOT_APPLICABLE_NO_CONFIRMED_EVENT`；保护距离 `None` ATR；上方空间 `None` ATR；R/R `None`。
- 量价 `UNRESOLVED`；突破相对量 `None`；截止日相对量 `0.6576145754518624`。
- 关注 `AVOID`；仓位意图 `NONE`；unresolved_down_background_no_long_setup。

## TREND-04（COUNTEREXAMPLE）

- 截止日 `2019-06-21`，标的 `000421`，来源时点核验 `True`。
- 背景 `UP`；结构 `TREND/READY`；事件 `CONFIRMED_EVENT`。
- 经济资格 `ELIGIBLE_BY_FROZEN_INITIAL_RULE`；保护距离 `2.68252427184466` ATR；上方空间 `13.86407766990288` ATR；R/R `5.168295331161769`。
- 量价 `CAUSAL_PHASED_DESCRIPTIVE`；突破相对量 `1.931934035373491`；截止日相对量 `2.2140379530648016`。
- 关注 `WATCH`；仓位意图 `NONE`；candidate_for_future_semantic_review_not_an_order。

## RANGE-12（COUNTEREXAMPLE）

- 截止日 `2022-03-23`，标的 `300449`，来源时点核验 `True`。
- 背景 `RANGE`；结构 `RANGE/FAILED_BREAK_PENDING`；事件 `NO_CONFIRMED_EVENT`。
- 经济资格 `NOT_APPLICABLE_NO_CONFIRMED_EVENT`；保护距离 `0.1333333333333335` ATR；上方空间 `5.166666666666671` ATR；R/R `38.749999999999986`。
- 量价 `CAUSAL_PHASED_DESCRIPTIVE`；突破相对量 `None`；截止日相对量 `0.8070619674852293`。
- 关注 `WAIT`；仓位意图 `NONE`；no_confirmed_price_event。

## WAIT-08（COUNTEREXAMPLE）

- 截止日 `2019-08-08`，标的 `600283`，来源时点核验 `True`。
- 背景 `DOWN`；结构 `NONE/WAIT`；事件 `NO_CONFIRMED_EVENT`。
- 经济资格 `NOT_APPLICABLE_NO_CONFIRMED_EVENT`；保护距离 `None` ATR；上方空间 `None` ATR；R/R `None`。
- 量价 `UNRESOLVED`；突破相对量 `None`；截止日相对量 `0.7384567599659632`。
- 关注 `AVOID`；仓位意图 `NONE`；unresolved_down_background_no_long_setup。

## TREND-13（COUNTEREXAMPLE）

- 截止日 `2024-12-06`，标的 `301048`，来源时点核验 `True`。
- 背景 `TRANSITION`；结构 `TREND/INVALIDATED`；事件 `NO_ACTIVE_EVENT`。
- 经济资格 `NOT_APPLICABLE_NO_CONFIRMED_EVENT`；保护距离 `None` ATR；上方空间 `None` ATR；R/R `None`。
- 量价 `CAUSAL_PHASED_DESCRIPTIVE`；突破相对量 `None`；截止日相对量 `0.5660591799566108`。
- 关注 `WAIT`；仓位意图 `NONE`；no_confirmed_price_event。

## 回答边界

全部回答仅表示该测量协议可以审查，不能授权检索激活、收益实验或交易规则。任何 `NEEDS_CHANGE`、`INSUFFICIENT`、`ISSUE` 或 `UNCLEAR` 都必须附说明，并优先修订定义。
