# 因子 v2：成熟标签与邻居覆盖就绪度审计

## 裁定

- 状态：`BLOCKED_NO_LAWFUL_RETRIEVAL_PANEL`。
- 未读取未来收益或邻居结果；本审计只检查字段、时点和可连接性。

## 阻断原因

- v2 feature audit is a 60-case cutoff ledger, not an event-level retrieval panel; it lacks date, event_id, model, stage
- v2 feature audit has no mature-label end dates
- legacy labelled panel cannot be joined to v2 because its semantic keys/features do not identify v2 structural events
- v2 four-dimension semantic protocol is not approved

## 需要重建的最小接口

- 事件面板键：`date, asset, event_id, weekly_context, model, stage`。
- 特征：每个事件日的因子 v2 字段，均按当时截断计算。
- 标签：每个期限有 `label_end_{H}`，并严格要求早于查询日。
- 覆盖率：先报告语义匹配、事件去重、成熟标签、有效邻居和拒绝率，之后才可读取邻居结果。

## 禁止捷径

不得将旧标签面板与 v2 台账按日期或资产松散拼接，更不得据此声称 v2 的 KNN/HB-RAG 覆盖率或预测有效性。
