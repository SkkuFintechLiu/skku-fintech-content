# 因子 v2：D01-D16 门控审计

## 结论

- 状态：`GATED_NOT_READY_FOR_RETRIEVAL`。
- 计数：通过 10，失败 0，阻断 2，未实现 4。
- 检索激活：`BLOCKED`；收益实验授权：`False`。

## 明细

| 编号 | 范围 | 状态 | 证据 |
|---|---|---|---|
| D01 | 因果追加不变性 | `PASS` | 60 个案例在追加人为未来条后，截至原 cutoff 的特征完全一致；60 个源均通过截止日核验。 |
| D02 | 相对量基准 | `PASS` | 相对量使用截止日前 20 个有效日中位数；当日前值被 shift 排除，样本不足不产生比率。 |
| D03 | 结构与量价分离 | `PASS` | 4 个确认事件与量价字段独立保存；所有记录 position_intent=NONE，量价缺失不会生成订单。 |
| D04 | 阶段量价时点 | `PASS` | 突破相对量、事件期相对量和调整状态均在 cutoff 截断后计算，并随 D01 的追加检验。 |
| D05 | 未批准意图不下单 | `PASS` | v2 合约固定 probe_enabled=false、position_intent=NONE、orders_generated=false。 |
| D06 | 事件不按未来结局筛除 | `PASS` | 台账保留 56 个未确认/失效状态和 4 个确认状态；本轮未读取任何结果列。 |
| D07 | 共同邻居与成熟标签 | `BLOCKED` | v2 特征台账不含标签终止日或邻居结果。须先提供允许开发期的事件级标签库，才能审计 label_end < query_date、共同邻居与最小覆盖率。 |
| D08 | 追加事件 | `NOT_IMPLEMENTED` | 试仓/追加意图模块按约定保持关闭。 |
| D09 | 成交与取消台账 | `NOT_IMPLEMENTED` | 执行模块未接入 v2，未生成任何订单。 |
| D10 | 仓位/止损预算 | `NOT_IMPLEMENTED` | 仓位系统未接入 v2，不能声明风险预算性质已验证。 |
| D11 | 不可成交与持仓账本 | `NOT_IMPLEMENTED` | 执行模块未接入 v2，不能以旧回测替代。 |
| D12 | 背景切换与旧事件 | `PASS` | v2 只读取既有因果状态且不创建事件/订单；背景切换后的旧事件在台账中仅显示 NO_ACTIVE_EVENT 或 WAIT。 |
| D13 | 行业与订单流表述边界 | `PASS` | 台账没有行业防御标签、订单流或机构成本字段；成交量只标注为 descriptive phased proxy。 |
| D14 | AVOID 不删样本 | `PASS` | 全部 60 个遮挡案例均保留状态记录；关注状态不会过滤源样本。 |
| D15 | 关注状态与 KNN 分离 | `PASS` | attention 仅为 WAIT/WATCH/AVOID/DATA_UNRESOLVED；合约明确 knn_hb_rag_outcomes_read=false、retrieval_integration=NOT_ACTIVATED。 |
| D16 | 语义确认不等于正式验收 | `BLOCKED` | v2 四维协议状态为 PENDING_HUMAN_SEMANTIC_REVIEW；即使完成也不能代替 60 例正式盲图门槛或打开收益实验。 |
