# 解释性状态与证据台账 v1

## Material Passport

- 目的：检查程序是否把背景、结构、量价、关注和仓位意图分层表达。
- 样本：4 个已校准案例 + 4 个按阶段配对的反例；均为已经看过的开发期材料。
- 时点：所有记录只使用各案例决策日前数据；不读取未来收益、邻居结果或 2025 结果。
- 交易边界：`position_intent=NONE`；试仓和行业门控均关闭；本产物不生成订单。
- 解释边界：这是程序语义和证据可用性的审计，不是泛化测试、收益测试或策略验收。

## 案例摘要

| 案例 | 角色 | 背景 | 结构阶段 | 量价状态 | 关注 | 仓位意图 |
|---|---|---|---|---|---|---|
| TREND-03 | CALIBRATION | UP | READY | DESCRIPTIVE_ONLY | WATCH | NONE |
| TREND-05 | CALIBRATION | UP | BREAK_CONFIRMED | DESCRIPTIVE_ONLY | WATCH | NONE |
| RANGE-08 | CALIBRATION | UP | INVALIDATED | DESCRIPTIVE_ONLY | WATCH | NONE |
| WAIT-06 | CALIBRATION | DOWN | WAIT | DESCRIPTIVE_ONLY | AVOID | NONE |
| TREND-04 | COUNTEREXAMPLE | UP | READY | DESCRIPTIVE_ONLY | WATCH | NONE |
| RANGE-12 | COUNTEREXAMPLE | RANGE | FAILED_BREAK_PENDING | DESCRIPTIVE_ONLY | WATCH | NONE |
| WAIT-08 | COUNTEREXAMPLE | DOWN | WAIT | DESCRIPTIVE_ONLY | AVOID | NONE |
| TREND-13 | COUNTEREXAMPLE | TRANSITION | INVALIDATED | DESCRIPTIVE_ONLY | WATCH | NONE |

## 五层解释

每个案例按相同顺序阅读：

1. 背景：最近已完成周线能否提供 UP、DOWN、RANGE 或 TRANSITION。
2. 结构：位置、事件阶段、事件年龄、保护位、目标位和失效原因。
3. 量价：只展示截止日相对前 20 个有效交易日的描述值；阶段性量价确认尚未定义。
4. 关注：`WATCH` 代表保留观察资格，`AVOID` 代表暂不进入主动多头候选，二者都不等于 KNN 的 SELL。
5. 仓位意图：本版本强制为 `NONE`，不会把 READY、量价描述或用户意见变成成交。

### TREND-03（CALIBRATION）

- 截止日：`2023-08-23`；标的：`300688`。
- 原意见：结合交易量，需要一个确认信号。
- 背景：`UP`，周线有效截至 `2023-08-18 00:00:00`。
- 结构：`TREND/READY`，事件 `300688:TREND:2023-08-11`，失效原因 `none`。
- 量价：`DESCRIPTIVE_ONLY`，相对量 `1.1099712481738462`；该值不是门槛。
- 关注：`WATCH`，原因 `structure_observed_but_volume_gate_not_defined`。
- 仓位：`NONE / DISABLED_READ_ONLY`；试仓、追加和行业门控没有被启用。

### TREND-05（CALIBRATION）

- 截止日：`2023-09-15`；标的：`600595`。
- 原意见：可以进入头寸建仓，当确认结构成立后再追加仓位。
- 背景：`UP`，周线有效截至 `2023-09-15 00:00:00`。
- 结构：`TREND/BREAK_CONFIRMED`，事件 `600595:TREND:2023-09-08`，失效原因 `none`。
- 量价：`DESCRIPTIVE_ONLY`，相对量 `3.4598411861519556`；该值不是门槛。
- 关注：`WATCH`，原因 `structure_observed_but_volume_gate_not_defined`。
- 仓位：`NONE / DISABLED_READ_ONLY`；试仓、追加和行业门控没有被启用。

### RANGE-08（CALIBRATION）

- 截止日：`2023-10-27`；标的：`600955`。
- 原意见：如果是防御性板块则是绝佳的买入位置，量能极度萎缩，情绪低点，价格洼地。
- 背景：`UP`，周线有效截至 `2023-10-27 00:00:00`。
- 结构：`RANGE/INVALIDATED`，事件 `600955:RANGE:2023-10-20`，失效原因 `BACKGROUND_CHANGED`。
- 量价：`DESCRIPTIVE_ONLY`，相对量 `1.6903286022786208`；该值不是门槛。
- 关注：`WATCH`，原因 `old_event_invalidated_new_event_required`。
- 仓位：`NONE / DISABLED_READ_ONLY`；试仓、追加和行业门控没有被启用。

### WAIT-06（CALIBRATION）

- 截止日：`2022-04-14`；标的：`600667`。
- 原意见：不值得等待，未结束下跌趋势。
- 背景：`DOWN`，周线有效截至 `2022-04-08 00:00:00`。
- 结构：`NONE/WAIT`，事件 `NONE`，失效原因 `BACKGROUND_DOWN`。
- 量价：`DESCRIPTIVE_ONLY`，相对量 `0.6576145754518624`；该值不是门槛。
- 关注：`AVOID`，原因 `unresolved_down_background_no_long_setup`。
- 仓位：`NONE / DISABLED_READ_ONLY`；试仓、追加和行业门控没有被启用。

### TREND-04（COUNTEREXAMPLE）

- 截止日：`2019-06-21`；标的：`000421`。
- 原意见：需要结合交易量，等待确认信号。
- 背景：`UP`，周线有效截至 `2019-06-21 00:00:00`。
- 结构：`TREND/READY`，事件 `000421:TREND:2019-06-14`，失效原因 `none`。
- 量价：`DESCRIPTIVE_ONLY`，相对量 `2.2140379530648016`；该值不是门槛。
- 关注：`WATCH`，原因 `structure_observed_but_volume_gate_not_defined`。
- 仓位：`NONE / DISABLED_READ_ONLY`；试仓、追加和行业门控没有被启用。

### RANGE-12（COUNTEREXAMPLE）

- 截止日：`2022-03-23`；标的：`300449`。
- 原意见：无法买入，破位未反弹，量能萎缩严重。
- 背景：`RANGE`，周线有效截至 `2022-03-18 00:00:00`。
- 结构：`RANGE/FAILED_BREAK_PENDING`，事件 `300449:RANGE:2022-03-23`，失效原因 `none`。
- 量价：`DESCRIPTIVE_ONLY`，相对量 `0.8070619674852293`；该值不是门槛。
- 关注：`WATCH`，原因 `no_active_buy_intent_in_read_only_ledger`。
- 仓位：`NONE / DISABLED_READ_ONLY`；试仓、追加和行业门控没有被启用。

### WAIT-08（COUNTEREXAMPLE）

- 截止日：`2019-08-08`；标的：`600283`。
- 原意见：无明显上涨信号，可以放弃买入。
- 背景：`DOWN`，周线有效截至 `2019-08-02 00:00:00`。
- 结构：`NONE/WAIT`，事件 `NONE`，失效原因 `BACKGROUND_DOWN`。
- 量价：`DESCRIPTIVE_ONLY`，相对量 `0.7384567599659632`；该值不是门槛。
- 关注：`AVOID`，原因 `unresolved_down_background_no_long_setup`。
- 仓位：`NONE / DISABLED_READ_ONLY`；试仓、追加和行业门控没有被启用。

### TREND-13（COUNTEREXAMPLE）

- 截止日：`2024-12-06`；标的：`301048`。
- 原意见：位置过高，参与博弈的成本较大，需要更严格的止损和盈亏比，才能入场。
- 背景：`TRANSITION`，周线有效截至 `2024-12-06 00:00:00`。
- 结构：`TREND/INVALIDATED`，事件 `301048:TREND:2024-11-22`，失效原因 `BACKGROUND_CHANGED`。
- 量价：`DESCRIPTIVE_ONLY`，相对量 `0.5660591799566108`；该值不是门槛。
- 关注：`WATCH`，原因 `old_event_invalidated_new_event_required`。
- 仓位：`NONE / DISABLED_READ_ONLY`；试仓、追加和行业门控没有被启用。

## 本轮结论

- 四个校准案例的已确认转述可以被台账逐层承载。
- 反例显示：量价未定义、旧事件失效、下跌背景和高位置应分别记录，不能压成一个 BUY/WAIT 标签。
- 当前最重要的程序边界是：结构事实可以保留，证据不足只能进入观察或数据未解决状态，不能自动建仓。
- 后续若实现新规则，必须新建版本并运行 D01-D16；不能修改本台账后声称旧盲图已通过。

