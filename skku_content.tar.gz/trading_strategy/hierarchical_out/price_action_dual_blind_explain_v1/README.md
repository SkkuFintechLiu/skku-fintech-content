# Price Action Dual Explain v1

这是按四项语义校准后重新生成的独立结构盲图验收包。它绑定了原价格结构引擎、原配置和只读解释层 `explain_state.py`，但没有改变交易逻辑。

## 入口

- [60 例盲图验收页面](index.html)
- [解释性状态台账](../price_action_dual_explain_v2/index.html)
- [版本元数据](explain_packet_metadata.json)
- [实现状态](implementation_status.json)
- [交付核验](delivery_verification.json)
- [本次人工意见与量价反馈](review_submissions/c37c8abc4d0bbc16/index.html)
- [四维小范围验收协议 v2](protocol_v2_1/index.html)

## 样本与边界

- 360 个标的，2015-01-05 至 2024-12-31，625,210 个股票日。
- TREND、RANGE、WAIT 各 20 例；固定种子和阶段配额，与原开发期抽样协议一致。
- 60/60 个案例通过独立前缀重放；图表不读取未来价格、收益、邻居结果或 2025 结果。
- `explain_state_v1` 仅用于显示背景、结构、量价证据、关注状态和仓位意图。
- 试仓、行业门控、KNN/HB-RAG、收益实验和实际订单均未启用。

## 审阅规则

请按当时信息判断程序是否正确表达背景、位置、结构阶段、量价证据和失效原因。`READY` 不等于买入，`WATCH/AVOID` 不等于 KNN 的 SELL/WAIT/BUY。

正式验收仍需原门槛：TREND、RANGE、WAIT 各至少 18/20 通过，且 60 例时点全部明确。请导出与该包绑定的正式 `price_action_review_decisions.json` 后再进行冻结；四案例校准答复不能替代正式 60 例验收。

## 验证状态

- `verify_packet`：通过。
- 180 个案例源表、60 张图：通过。
- 32 项原核心测试：通过；解释层另有 21 项逐项协议测试，总联合测试 66 项通过。
- 受保护历史产物：29 个未改变。
- 当前 `human_acceptance`：`PENDING`。
- 本次意见已原样归档，但正式门槛结果为 TREND `9/20`、RANGE `18/20`、WAIT `14/20`；时点为 `41 CLEAR / 17 ISSUE / 2 未选`，审核人字段为空，因此没有创建冻结锁。
- 当前正式 `check`：预期返回退出码 2，原因是尚未有人完成新包的正式盲图验收。

## 四维协议

四维页面只要求审阅 4 个已校准案例和 4 个反例，分别回答结构事实、证据充分性、行动偏好和时点清晰度。填写后导出 `price_action_four_dimension_review_v2.json` 发回对话；它只用于修订测量协议，不替代正式 60 例验收。
