# 价格行为验收反馈分析

## Material Passport

- 类型：人工规则标注的描述性复核，不是收益统计检验。
- Verification Status: VERIFIED（版本及原始选择计数）；结构语义解释仍待核对。
- 来源：用户导出的 JSON；原文件按字节归档，未改姓名、选项或意见。
- 当前裁定：未通过原定结构验收；不创建批准锁，不运行收益实验。

## 原始选择

| 类别 | 通过 | 存疑 | 不通过 | 未选 |
|---|---:|---:|---:|---:|
| 趋势 | 9 | 5 | 6 | 0 |
| 震荡 | 18 | 0 | 2 | 0 |
| 等待 | 14 | 2 | 4 | 0 |

各类原定门槛为至少 18/20 通过，且全部时点明确无误。上表是原始选项计数，不是模型准确率，也不是你与程序的最终结构一致率。
时点选项：41 CLEAR，17 ISSUE，2 未选。
14 个 ISSUE 不能自动称为 14 个未来信息错误；备注多在讨论入场确认、量能和风险。自动前缀测试通过，也不能据此替你改成 CLEAR。

## 为什么不能直接解读通过率

1. 原页面把结构识别、交易行动和信息时点揉在一起，问题设计有歧义，应先修正测量方式。
2. RANGE-12 至 RANGE-16 等案例，程序已在等待；你写不能买入/未企稳，并不必然反对程序当前的不入场动作。保留 FAIL，不自动改 PASS。
3. TREND-14、RANGE-06 的做空意见对应原程序已失效状态；可支持放弃多头的解释，但不能当作已验证可做空策略。
4. WAIT-06 的不值得等待，提示应区分不交易中的继续观察与暂时排除，不能让一个 WAIT 承担所有含义。
5. 原盲图没有成交量面板。关于量能的意见是需要量价证据/量价规则的反馈，不等于已核实的成交量事实。

## 从反馈提炼的修订方向

以下为分析者归纳，不是替换你的原始标签，不计入通过数；尚未改变模型。

| 优先级 | 修订方向 | 反馈来源 | 边界 |
|---|---|---|---|
| P0 | 分开记录背景/结构、行动偏好、证据充分性、数据时点 | RANGE-12、WAIT-06、TREND-03 | 先修验收定义，不调参数以追求通过 |
| P1 | 补成交量及相对量，并按突破、回撤、反转阶段解释 | TREND-03/04/15、RANGE-02/08/17 | 量大不总是好、量小不总是坏，不设统一量能越大越好门槛 |
| P2 | 拒绝、观察、试探仓、确认仓分别建模 | TREND-05、RANGE-11/18/19 | 试探仓属于待定义的新策略，不直接启用或赋任意仓位比例 |
| P3 | 识别反弹与反转，检查上方阻力及下方支撑 | TREND-08/13/20、RANGE-14/20、WAIT-12/13 | 避免把局部抬高等同于大结构已反转 |
| P4 | 行业与板块背景作为条件信息 | TREND-17、RANGE-08、WAIT-12 | 必须有历史时点数据；不能用当前行业分类或事后板块走势回填 |

## 已补齐的量价证据

5 个提到量能的案例已补同一截止日的周线、日线、成交量和相对量图。
相对量 = 当日有效成交量 / 之前 20 个交易日有效成交量中位数。基准排除当日；缺失交易日不删除、不前向填充；不足完整窗口则保留缺失。
这些是展示证据，不是新入场规则；没有重新计算模型信号，没有读取任何决策日后的价格。原始量单位和公司行为调整尚未完全核验，不能宣称识别真实买卖盘或资金净流入。

## 需要保留的未完成项

- 审核人字段为空；不从账号、路径或聊天身份自动填写。
- RANGE-11、RANGE-17、RANGE-19、RANGE-20 有文字意见，但结构与时点选项未选择；保留原状。
- TREND-02 为存疑但未写原因。
- 这些字段即便补齐，也不会让三类自动达到 18/20；核心工作是修正规则与验收语义，而非催你补表。

## 下一步

无需立刻重做 60 例。先用 TREND-03（缺确认）、TREND-05（分阶段建仓）、RANGE-08（低量的情境作用）、WAIT-06（观察与排除）四个分歧校准定义。
原定正式验收条件保留；小范围校准不能替代正式重审。新定义另开新版本并重新验收后才冻结，保留本次未通过裁定，不根据未来盈亏调参。

## 逐例原始意见

### TREND-01 · READY
原选择：FAIL；时点：ISSUE。
> 无法确定趋势的确定性

### TREND-02 · READY
原选择：PASS；时点：ISSUE。
> 需要等待右侧更明确的信号，或者此时的交易量显著放大

### TREND-03 · READY
原选择：UNCERTAIN；时点：ISSUE。
> 需要根据交易量确认这个位置是否有支撑

### TREND-04 · READY
原选择：PASS；时点：CLEAR。
> （无文字意见）

### TREND-05 · BREAK_CONFIRMED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### TREND-06 · BREAK_CONFIRMED
原选择：UNCERTAIN；时点：未选。
> 前面的阳线没有突破压力结构，需要查看交易量判断是否有买入的价值

### TREND-07 · BREAK_CONFIRMED
原选择：FAIL；时点：ISSUE。
> 上方的套牢资金并没有释放，此时买入，并不会明显上涨，反而会陷入震荡当中

### TREND-08 · BREAK_CONFIRMED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### TREND-09 · INVALIDATED
原选择：FAIL；时点：ISSUE。
> 上方抛压太大，无法确定是反弹还是开启上涨阶段，结合成交量判断

### TREND-10 · INVALIDATED
原选择：UNCERTAIN；时点：ISSUE。
> 结合成交量分析

### TREND-11 · INVALIDATED
原选择：UNCERTAIN；时点：ISSUE。
> 明显被上方的资金抛压压制，可以进入等待

### TREND-12 · INVALIDATED
原选择：FAIL；时点：ISSUE。
> 已经突破进入第二次突破后的调整阶段，后续的资金进入存疑

### TREND-13 · INVALIDATED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### TREND-14 · INVALIDATED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### TREND-15 · WAIT_TRIGGER
原选择：PASS；时点：CLEAR。
> （无文字意见）

### TREND-16 · WAIT_TRIGGER
原选择：PASS；时点：CLEAR。
> （无文字意见）

### TREND-17 · WAIT_TRIGGER
原选择：FAIL；时点：ISSUE。
> 调整幅度不够，没有办法把大部分人的筹码通过洗盘洗走

### TREND-18 · WAIT_TRIGGER
原选择：PASS；时点：CLEAR。
> （无文字意见）

### TREND-19 · WAIT_TRIGGER
原选择：UNCERTAIN；时点：ISSUE。
> 我认为还有一波调整

### TREND-20 · WAIT_TRIGGER
原选择：FAIL；时点：ISSUE。
> 明显还存在一段震荡

### RANGE-01 · BREAK_CONFIRMED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-02 · BREAK_CONFIRMED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-03 · BREAK_CONFIRMED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-04 · BREAK_CONFIRMED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-05 · INVALIDATED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-06 · INVALIDATED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-07 · INVALIDATED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-08 · INVALIDATED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-09 · INVALIDATED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-10 · INVALIDATED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-11 · FAILED_BREAK_PENDING
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-12 · FAILED_BREAK_PENDING
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-13 · FAILED_BREAK_PENDING
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-14 · FAILED_BREAK_PENDING
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-15 · FAILED_BREAK_PENDING
原选择：FAIL；时点：ISSUE。
> 加速下跌，建立下跌趋势

### RANGE-16 · WAIT_TRIGGER
原选择：FAIL；时点：ISSUE。
> 单边下跌

### RANGE-17 · WAIT_TRIGGER
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-18 · WAIT_TRIGGER
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-19 · WAIT_TRIGGER
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-20 · WAIT_TRIGGER
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-01 · WAIT
原选择：FAIL；时点：ISSUE。
> 已经上涨完成，没有等待的意义

### WAIT-02 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-03 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-04 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-05 · WAIT
原选择：PASS；时点：ISSUE。
> 明显的反弹结束，进入震荡

### WAIT-06 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-07 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-08 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-09 · WAIT
原选择：UNCERTAIN；时点：CLEAR。
> 不知道这个股票处于的板块是否存在后续反转的可能性

### WAIT-10 · WAIT
原选择：FAIL；时点：未选。
> 也可能开启了下跌趋势

### WAIT-11 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-12 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-13 · WAIT
原选择：FAIL；时点：ISSUE。
> 明显没有结束下跌趋势

### WAIT-14 · WAIT
原选择：UNCERTAIN；时点：CLEAR。
> 还有一段时间震荡

### WAIT-15 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-16 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-17 · WAIT
原选择：FAIL；时点：ISSUE。
> 没有结束下跌

### WAIT-18 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-19 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-20 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）
