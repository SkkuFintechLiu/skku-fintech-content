# 价格行为验收反馈分析

## Material Passport

- 类型：人工规则标注的描述性复核，不是收益统计检验。
- Verification Status: VERIFIED（版本及原始选择计数）；结构语义解释仍待核对。
- 来源：用户导出的 JSON；原文件按字节归档，未改姓名、选项或意见。
- 当前裁定：未通过原定结构验收；不创建批准锁，不运行收益实验。

## 原始选择

| 类别 | 通过 | 存疑 | 不通过 | 未选 |
|---|---:|---:|---:|---:|
| 趋势 | 11 | 8 | 1 | 0 |
| 震荡 | 4 | 7 | 5 | 4 |
| 等待 | 14 | 1 | 5 | 0 |

各类原定门槛为至少 18/20 通过，且全部时点明确无误。上表是原始选项计数，不是模型准确率，也不是你与程序的最终结构一致率。
时点选项：42 CLEAR，14 ISSUE，4 未选。
14 个 ISSUE 不能自动称为 14 个未来信息错误；备注多在讨论入场确认、量能和风险。自动前缀测试通过，也不能据此替你改成 CLEAR。

## 为什么不能直接解读通过率

1. 原页面把结构识别、交易行动和信息时点揉在一起，问题设计有歧义，应先修正测量方式。
2. RANGE-12 至 RANGE-16 等案例，程序已在等待；你写不能买入/未企稳，并不必然反对程序当前的不入场动作。保留 FAIL，不自动改 PASS。
3. TREND-14、RANGE-06 的做空意见对应原程序已失效状态；可支持放弃多头的解释，但不能当作已验证可做空策略。
4. WAIT-06 的不值得等待，提示应区分不交易中的继续观察与暂时排除，不能让一个 WAIT 承担所有含义。
5. 原盲图没有成交量面板。关于量能的意见是需要量价证据/量价规则的反馈，不等于已核实的成交量事实。

## 从反馈提炼的修订方向

以下为分析者归纳，不是替换你的原始标签，不计入通过数；尚未改变模型。

| 优先级 | 修订方向 | 反馈来源 | 边界 |
|---|---|---|---|
| P0 | 分开记录背景/结构、行动偏好、证据充分性、数据时点 | RANGE-12、WAIT-06、TREND-03 | 先修验收定义，不调参数以追求通过 |
| P1 | 补成交量及相对量，并按突破、回撤、反转阶段解释 | TREND-03/04/15、RANGE-02/08/17 | 量大不总是好、量小不总是坏，不设统一量能越大越好门槛 |
| P2 | 拒绝、观察、试探仓、确认仓分别建模 | TREND-05、RANGE-11/18/19 | 试探仓属于待定义的新策略，不直接启用或赋任意仓位比例 |
| P3 | 识别反弹与反转，检查上方阻力及下方支撑 | TREND-08/13/20、RANGE-14/20、WAIT-12/13 | 避免把局部抬高等同于大结构已反转 |
| P4 | 行业与板块背景作为条件信息 | TREND-17、RANGE-08、WAIT-12 | 必须有历史时点数据；不能用当前行业分类或事后板块走势回填 |

## 已补齐的量价证据

13 个提到量能的案例已补同一截止日的周线、日线、成交量和相对量图。
相对量 = 当日有效成交量 / 之前 20 个交易日有效成交量中位数。基准排除当日；缺失交易日不删除、不前向填充；不足完整窗口则保留缺失。
这些是展示证据，不是新入场规则；没有重新计算模型信号，没有读取任何决策日后的价格。原始量单位和公司行为调整尚未完全核验，不能宣称识别真实买卖盘或资金净流入。

## 需要保留的未完成项

- 审核人字段为空；不从账号、路径或聊天身份自动填写。
- RANGE-11、RANGE-17、RANGE-19、RANGE-20 有文字意见，但结构与时点选项未选择；保留原状。
- TREND-02 为存疑但未写原因。
- 这些字段即便补齐，也不会让三类自动达到 18/20；核心工作是修正规则与验收语义，而非催你补表。

## 下一步

无需立刻重做 60 例。先用 TREND-03（缺确认）、TREND-05（分阶段建仓）、RANGE-08（低量的情境作用）、WAIT-06（观察与排除）四个分歧校准定义。
原定正式验收条件保留；小范围校准不能替代正式重审。新定义另开新版本并重新验收后才冻结，保留本次未通过裁定，不根据未来盈亏调参。

## 逐例原始意见

### TREND-01 · READY
原选择：PASS；时点：CLEAR。
> （无文字意见）

### TREND-02 · READY
原选择：UNCERTAIN；时点：CLEAR。
> （无文字意见）

### TREND-03 · READY
原选择：UNCERTAIN；时点：ISSUE。
> 结合交易量，需要一个确认信号

### TREND-04 · READY
原选择：UNCERTAIN；时点：ISSUE。
> 需要结合交易量，等待确认信号

### TREND-05 · BREAK_CONFIRMED
原选择：UNCERTAIN；时点：CLEAR。
> 可以进入头寸建仓，当确认结构成立后再追加仓位

### TREND-06 · BREAK_CONFIRMED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### TREND-07 · BREAK_CONFIRMED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### TREND-08 · BREAK_CONFIRMED
原选择：UNCERTAIN；时点：CLEAR。
> 需要观察接下来的价格能否突破上方的压力位

### TREND-09 · INVALIDATED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### TREND-10 · INVALIDATED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### TREND-11 · INVALIDATED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### TREND-12 · INVALIDATED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### TREND-13 · INVALIDATED
原选择：FAIL；时点：CLEAR。
> 位置过高，参与博弈的成本较大，需要更严格的止损和盈亏比，才能入场

### TREND-14 · INVALIDATED
原选择：PASS；时点：CLEAR。
> 做空信号

### TREND-15 · WAIT_TRIGGER
原选择：UNCERTAIN；时点：CLEAR。
> 需要结合交易量分析，如果没有足够的交易量支撑，可能该段行情市反弹行情

### TREND-16 · WAIT_TRIGGER
原选择：PASS；时点：CLEAR。
> （无文字意见）

### TREND-17 · WAIT_TRIGGER
原选择：PASS；时点：ISSUE。
> 这个位置很有可能会失效，需要观察交易量、行业整体动态、板块轮动，该位置不是最佳买点

### TREND-18 · WAIT_TRIGGER
原选择：PASS；时点：CLEAR。
> 快进快出类型的买入位置

### TREND-19 · WAIT_TRIGGER
原选择：UNCERTAIN；时点：CLEAR。
> 上升通道的依旧存在

### TREND-20 · WAIT_TRIGGER
原选择：UNCERTAIN；时点：CLEAR。
> 突破无力，结合之前的动态，可能转为破位下跌

### RANGE-01 · BREAK_CONFIRMED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-02 · BREAK_CONFIRMED
原选择：UNCERTAIN；时点：CLEAR。
> 反转的发生需要结合交易量

### RANGE-03 · BREAK_CONFIRMED
原选择：UNCERTAIN；时点：ISSUE。
> 交易量不够支撑反转，可以可能是震荡下行的洗盘，

### RANGE-04 · BREAK_CONFIRMED
原选择：PASS；时点：CLEAR。
> （无文字意见）

### RANGE-05 · INVALIDATED
原选择：UNCERTAIN；时点：ISSUE。
> 量能过低

### RANGE-06 · INVALIDATED
原选择：PASS；时点：CLEAR。
> 跌破支撑位置，做空/暂时放弃买入机会

### RANGE-07 · INVALIDATED
原选择：UNCERTAIN；时点：ISSUE。
> 跌破了上升通道，从量能看已经结束了这次反弹，震荡下行或成为接下来主要的一段趋势。

### RANGE-08 · INVALIDATED
原选择：PASS；时点：CLEAR。
> 如果是防御性板块则是绝佳的买入位置，量能极度萎缩，情绪低点，价格洼地

### RANGE-09 · INVALIDATED
原选择：UNCERTAIN；时点：ISSUE。
> 没有可以确认的信号

### RANGE-10 · INVALIDATED
原选择：UNCERTAIN；时点：ISSUE。
> 还在震荡阶段

### RANGE-11 · FAILED_BREAK_PENDING
原选择：未选；时点：未选。
> 快进快出，严格止损，轻仓位尝试反弹的一个机会

### RANGE-12 · FAILED_BREAK_PENDING
原选择：FAIL；时点：CLEAR。
> 无法买入，破位未反弹，量能萎缩严重

### RANGE-13 · FAILED_BREAK_PENDING
原选择：FAIL；时点：CLEAR。
> 不是买入的好机会

### RANGE-14 · FAILED_BREAK_PENDING
原选择：FAIL；时点：CLEAR。
> 下跌趋势未结束

### RANGE-15 · FAILED_BREAK_PENDING
原选择：FAIL；时点：CLEAR。
> 极端行情，不值得入场

### RANGE-16 · WAIT_TRIGGER
原选择：FAIL；时点：CLEAR。
> 未企稳，需要后续观察

### RANGE-17 · WAIT_TRIGGER
原选择：未选；时点：未选。
> 没有交易量的支撑，短暂反弹后依旧可能会下跌

### RANGE-18 · WAIT_TRIGGER
原选择：UNCERTAIN；时点：ISSUE。
> 可以尝试买入

### RANGE-19 · WAIT_TRIGGER
原选择：未选；时点：未选。
> 轻仓埋伏，等待大阳线的出现

### RANGE-20 · WAIT_TRIGGER
原选择：未选；时点：未选。
> 虽然进入超卖区域，但是不可以进行埋伏。因为还没有企稳，下跌趋势的惯性还存在

### WAIT-01 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-02 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-03 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-04 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-05 · WAIT
原选择：UNCERTAIN；时点：CLEAR。
> 值得观察，从K线形态来说，分歧较大

### WAIT-06 · WAIT
原选择：FAIL；时点：CLEAR。
> 不值得等待，未结束下跌趋势

### WAIT-07 · WAIT
原选择：PASS；时点：CLEAR。
> 等待破位

### WAIT-08 · WAIT
原选择：FAIL；时点：CLEAR。
> 无明显上涨信号，可以放弃买入

### WAIT-09 · WAIT
原选择：PASS；时点：CLEAR。
> 破位

### WAIT-10 · WAIT
原选择：PASS；时点：ISSUE。
> 放量下跌，等待企稳后，进行买入

### WAIT-11 · WAIT
原选择：PASS；时点：ISSUE。
> 低点上抬，继续观察

### WAIT-12 · WAIT
原选择：FAIL；时点：ISSUE。
> 根据资产类型判断，没有买入的价值，上方的压力太大

### WAIT-13 · WAIT
原选择：FAIL；时点：ISSUE。
> 下方没有支撑，向下空间很大

### WAIT-14 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-15 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-16 · WAIT
原选择：FAIL；时点：ISSUE。
> 交易量太小，震荡时间不足

### WAIT-17 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-18 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-19 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）

### WAIT-20 · WAIT
原选择：PASS；时点：CLEAR。
> （无文字意见）
