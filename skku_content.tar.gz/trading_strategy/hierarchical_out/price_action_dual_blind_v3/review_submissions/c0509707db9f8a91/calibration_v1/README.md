# 四案例规则校准

打开 [四张校准卡](index.html)，逐张看“你的原话”和“请核对的转述”。每卡只需选择转述准确、需要修改或仍不清楚；需要修改时写一句具体意见。

| 案例 | 核对的核心含义 |
|---|---|
| TREND-03 | 价格突破与站稳，不等于量价证据已足以支持入场 |
| TREND-05 | 试探建仓与确认后追加分开，比例和触发条件尚未确定 |
| RANGE-08 | 条件性板块判断、缩量比较阶段，以及旧模板失效与新机会的区别 |
| WAIT-06 | 暂时排除候选与继续观察分开，不永久删除股票数据 |

填写后点击“导出校准意见”，将 `price_action_four_case_calibration.json` 发回当前对话。只发送“完成”不会传回浏览器里的选择。也可直接按四个编号在对话中回复，不要求必须使用表单。

所有选择默认空白；原始 PASS/FAIL/ISSUE 不改写。四张认可也不代表60例验收通过，不批准实际买入、不更改仓位或量能阈值、不启动收益实验。尚未确定的条件另列在可展开的草案区，不冒充你的原话。

## 证据与验证

- 四张图和源表均止于各自原决策日，没有未来行情或收益字段。
- 原反馈的字节哈希与原案例版本均已核对。
- 45 项 Python 测试与 17 项 JavaScript 单元测试通过。
- 导航、选择保留、导入导出和本地保存失败提示在内存 DOM 中测试；真实浏览器端到端点击尚未验证。此前本地文件访问限制未被绕过。
- 机器可读核验：`delivery_checks.json`。完整校准文字：`four_case_calibration.md`。

## 开发复现

在项目根目录，构建时使用新的空目录，不覆盖当前包或用户答复：

```bash
python3 -m trading_strategy.price_action_dual.qa.build_calibration build --packet trading_strategy/hierarchical_out/price_action_dual_blind_v3 --submission trading_strategy/hierarchical_out/price_action_dual_blind_v3/review_submissions/c0509707db9f8a91 --out /path/to/new_calibration_packet
```

收到实际导出文件后：

```bash
python3 -m trading_strategy.price_action_dual.qa.build_calibration ingest --out trading_strategy/hierarchical_out/price_action_dual_blind_v3/review_submissions/c0509707db9f8a91/calibration_v1 --response /path/to/price_action_four_case_calibration.json
```

`READY_TO_DRAFT_RULES` 只表示转述一致；`NEEDS_DISCUSSION` 表示有修改/不清楚；`INCOMPLETE` 表示字段未填或格式不符。三种状态均不等于正式接受模型。
