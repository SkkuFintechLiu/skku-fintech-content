# 研究架构 v2：结构门控、历史检索与风险拒绝

## 1. 总体决策链

```text
原始行情/行业/市场数据
        ↓
point-in-time 特征与结构事件
        ↓
HTF/MTF/LTF 状态机 + 可交易性门控
        ↓
候选池（结构只负责资格，不负责最终排序）
        ↓
同状态 KNN + HB-RAG 历史路径检索
        ↓
候选内横截面排序与不确定性估计
        ↓
独立风险标签：高风险拒绝 / 风险缩放
        ↓
执行模拟：下一可交易价格、成本、容量、持仓状态
        ↓
预测有效性、交易转化、稳定性与审计
```

核心原则：预测信息、可交易性和风险控制是三个独立主张，必须分别验证；任何一层失败都只能输出 `WAIT`，不能由下一层补救。

## 2. 模块边界

### A. `data_contract`

输入原始行情、行业指数、市场基准和交易约束；输出带有 `asof_date`、`signal_date`、`execution_date`、`label_end_date` 的冻结面板。

硬约束：特征只能使用 `asof_date <= signal_date` 的信息；标签必须在 `label_end_date < signal_date` 后才可进入历史检索；任何无法证明时点关系的字段标记为 `quarantined`。

### B. `structure_state`

输出确认过的 swing、BOS、CHoCH、sweep、POI、HTF/MTF/LTF 趋势和状态机阶段。每个事件至少保存：

```text
event_type, direction, level, creation_time,
confirmation_time, invalidation_time, source_window
```

结构层只做三件事：确认市场/行业/个股是否处于允许交易的状态，识别候选 POI，计算止损与目标的结构边界。它不直接承担候选内收益排序。

### C. `retrieval`

在结构状态和可观测市场制度一致的历史集合内执行两类检索：

- KNN：对当前状态向量进行距离检索，输出未来收益、胜率、MAE、MFE 和邻居覆盖度；
- HB-RAG：对历史路径进行分层检索，输出收益路径分布、止损先触发概率、等待时间和持有期分布。

检索结果必须附带 `neighbor_count`、`distance_quantile`、`state_coverage` 和 `ood_flag`。低覆盖或 OOD 不是低分，而是拒绝交易的理由。

### D. `risk_rejection`

独立于收益排序，使用未来 5 日风险标签和可执行性字段判断是否拒绝入场：跳空、涨跌停、流动性不足、极端波动、止损不可成交、MAE 超过风险预算等均进入该层。

风险层不得被 KNN/HB-RAG 的高收益预测绕过；最终动作集合固定为 `BUY`、`SELL`、`WAIT`，并记录具体拒绝原因。

### E. `execution`

统一使用下一可交易价格成交，显式处理交易成本、容量、停牌、涨跌停、跳空、持仓冷却、最大持有期和结构失效退出。执行状态与信号状态分离，避免把回测成交价写回信号日。

## 3. 统一中间数据契约

每条候选记录必须至少包含：

```text
asset, signal_date, execution_date
htf_state, mtf_state, ltf_state, structure_phase
poi_low, poi_high, stop_level, target_level, reward_space
knn_mu, knn_win, knn_mae, knn_mfe, knn_neighbors
hbrag_mu, hbrag_stop_prob, hbrag_hold_p50, hbrag_ood
risk_label, risk_reject, reject_reason
score, action, position_size
```

所有正式结果必须同时输出 `run_manifest.json`，记录代码哈希、数据哈希、参数、时间切分、成本、容量和样本覆盖率。

## 4. 验证顺序

1. **时点审计**：验证特征、结构确认、邻居成熟和执行价格不存在未来信息。
2. **结构层消融**：比较结构门控、结构排序和无结构候选池，确认结构只做资格是否更稳健。
3. **检索层确认**：在固定候选池上比较 KNN、HB-RAG、联合模型及置换基线，主指标为 RankIC、HAC、正 IC 比例和 OOD 覆盖率。
4. **风险层确认**：固定排序后只改变风险拒绝模块，报告风险事件召回、拒绝率、收益损失和回撤变化。
5. **交易转化**：固定全部前置模块，比较统一执行规则下的收益、Sharpe、回撤、成本敏感性和容量敏感性。
6. **未见时期与跨市场验证**：先完成冻结确认期，再做外部市场；不得用外部结果反向调参。

## 5. 当前实现映射与下一步

现有 `hierarchical_structure_strategy.py` 对应 A/B/E 的原型，`validate_knn_hbrag_effectiveness.py` 对应 C 的诊断，`ashare_risk_label_overlay.py` 对应 D 的原型。下一步应把三者的输出统一成上述中间契约，并增加拒绝原因、OOD 状态和执行审计字段；在此之前不继续调联合权重。

