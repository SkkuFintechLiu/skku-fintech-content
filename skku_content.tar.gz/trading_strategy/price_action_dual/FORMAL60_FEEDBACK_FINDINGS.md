# 正式 60 例反馈：分歧定位与修订顺序

## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: validate
- Verification Status: 原协议计数已复算；下文区分源字段事实、解释假设及尚未批准的规则。
- Version Label: formal60_v2_feedback_44ed5c9e66b8046f
- 范围：原决策截止日的冻结事实、代码和本次人工回答；不读取未来价格或收益。

## 1. 裁定与工作边界

本次 60 例四维均已作答，30 例含文字意见。结构事实认可数为趋势 19/20、震荡 17/20、等待 14/20；时点清晰为 46/60，其余 13 例选择“有问题”、1 例“不清楚”。**正式结构验收未通过。** 审核人为空也是记录完整性问题，但不是此次未通过的唯一原因，补姓名不会令本轮自动通过。

[自动生成的完整反馈摘要](../hierarchical_out/price_action_v3_formal60_v2/responses/44ed5c9e66b8046f/feedback_summary.md) 和 [60 例关联台账](../hierarchical_out/price_action_v3_formal60_v2/responses/44ed5c9e66b8046f/case_reviews.json) 是计数与原意见来源。原始文件、原选项、备注及旧门槛均不覆盖。软件可解码图片、通过前缀重放，不代表人工已确认语义或时点。

这些比例是本包单次人工判断，不是预测准确率、胜率、独立评审者一致性或泛化结果。新版本若依据本轮意见修订，这 60 例即属于已见修订材料，不能重新包装成独立盲测。

## 2. 已核实的表征缺口

### R1：事件短段不是完整回撤背景

F-TREND-01（000158，2020-04-21）记录为周线 UP、日线 READY、FOLLOW_CONFIRMED，`adjustment_depth_atr=0`、`adjustment_age_sessions=0`。源函数 [adjustment_features](qa/structure_factor_v3.py) 仅使用 `zone_time` 到截止日的收盘序列。本例事件起于 2020-04-10，故该数值不覆盖此前从高位回落的路径。

这是明确的**描述范围不匹配**：事件内创出新高可以使短段回撤为零，却不能说明大结构回撤已完成。原计算按短窗口定义未必算错，但不足以支持整体回踩质量判断。你的“突破失败后深度回调”意见应推动补全父级推进/回撤段，而不是把零改成一个迎合意见的分数。

优先设计：分别保存父级推进锚点、父级回撤起点和确认时点、进入关注区时间、事件内反应；保留父段深度/持续时间与事件短段深度两个字段。父段尚未定义或无法因果确认时记 UNKNOWN，不用局部零值冒充调整结束。数值阈值与“失败突破”的层级定义仍需另行确认。

### R2：周线背景、日线事件和箱体边界必须分开

F-RANGE-02（002969，2023-10-16）的事实并非完全没有识别突破：截至 10-13 的已完成周线为 RANGE，而 10-16 已记录 `BREAK_CONFIRMED`、`WAIT_FOLLOW`，当日相对量约 8.7984。图中目标约 3.69 已低于当前收盘，字段 `overhead_space_atr` 为负。

因此“不是震荡而是突破”的分歧至少包含展示层级：不能用单一“震荡”标题概括当前事件，也不能因日线放量就把尚未完成周线改为 UP。还应明确突破的是内部触发位、日线外部位，还是周箱上沿；三个对象不能互换。原箱体中点目标已耗尽时只表示该模板空间不足，不能偷偷把目标换成上沿以获得入场资格。

F-RANGE-12、15-20 的意见则要求检查当前日线下跌与旧周箱资格的关系。改进方向是记录箱体上下边界的确认、穿越、收回、失效和有效期，并给出日线下跌/企稳状态。究竟是箱体过期、日线尚未企稳，还是文字称呼不清，目前未完成逐例根因验证，不能把所有分歧直接判成同一代码错误。

## 3. 协议与行动的分歧

### R3：WAIT 是“不执行”，不等于“值得等买点”

F-WAIT-07 和 F-WAIT-08 的原事实已经是 `weekly_context=DOWN`、`legacy_attention=AVOID`、`position_intent=NONE`。F-WAIT-18 是 TRANSITION、无已确认事件，也没有声称反转成立。它们仍被归入统一“等待”抽样组，容易把样本类别、结构阶段、关注价值和交易动作混在一起。

下一版应在展示中明确“抽样组不是行情结论”，先呈现周线/日线状态与原拒绝原因，再分别说明：当前不执行、是否值得观察、若观察还缺什么。不得为提高认可数把原结构“不准确”自动改为“准确”；不得把 AVOID 解释成应从股票池或持仓账本删除。

F-WAIT-06 勾选行动 MATCH，却备注“买入的好机会”，而原状态是 DOWN/AVOID/NONE。F-WAIT-09、13 也包含比原动作更积极的文字。保留选择和备注两条原记录，登记为待解释差异，不推定用户已经批准买入或试仓分支。

### R4：时点问题与未来方向判断不相同

14 例的时点选项尚未清晰，其中多条备注描述的是“还会下跌”“需两周调整”等方向或持续时间预期，未指出具体发生日/确认日错误。这不允许程序擅自撤销 ISSUE，也不足以认定 14 例均发生数据泄漏。

后续对这些案例补充更直接的三时点对照：极值发生、规则首次可确认、当前截止日。记录具体是哪个标记/时间缺失或提前；若原意见实际针对结构成熟程度，则另留语义修订记录，旧回答仍保留。不通过要求用户把“不清楚”改成“清晰”来完成验收。

## 4. 量价及风险意见如何吸收

- F-TREND-04/11/19、F-RANGE-02/13、F-WAIT-03/07 涉及量价与调整过程。优先补全推进、回撤、突破、跟随四阶段的量价序列与各自基准，而非拿单日量比替代全过程。
- “缩量下跌说明空头多”“洗盘结束”“增量资金”等是审核者解释，不是 OHLCV 能直接验证的订单流或机构行为事实。可以转成可检验的价格/成交量代理假设，但本轮未批准任何通用放量阈值。
- “两周调整”“20% 下跌空间”等保留为主观预期，不写入标签，不当成历史最优持有期，也不读取后续收益验证后反改结构。
- F-WAIT-17 关于发行价/小盘股，以及 F-WAIT-12 关于退市风险的意见，应归入证券状态与样本适用性审计。当前图与字段不能证明发行价、时点市值或退市风险，故不据此删样本，不宣称已经核实这些属性。

## 5. 固定修订顺序

1. 保留本次未通过裁定、30 条文字意见及全部 60 例选择。先完成父级回撤和子事件的锚点/生命周期定义与代码审计；不加权凑结构分数。
2. 解释周线背景、日线阶段、突破对象与 WAIT/AVOID 的差别。用原截止日重放分歧案例及适当反例；已见案例仅用于修订，不能充当新独立验收。
3. 量价、企稳、反弹/反转和箱体失效的新增条件需明确可观察字段与确认时点。未定义分支保持关闭，不根据收益选择阈值。
4. 新版本绑定代码、配置和图证，执行相关因果与 D01-D16 测试；语义明确后再按原门槛安排正式复核。震荡 READY 覆盖不足单列解决，不通过替换失败样本凑通过率。
5. 正式结构通过后，才进入事件级面板和数据审计；数据与检索时点审计通过后才激活联合预测；成交与账本审计通过后再做收益实验。当前未放行。

本轮无需重填原 60 例；下一项工作由开发侧完成，先给出可解释的修订差异，再确认真正新增的语义。审核人标识后续通过独立补充记录绑定原文件，不篡改原提交。

## 复现

本轮执行 59 项 Python 测试全部通过，包括原有因果/协议边界与新增反馈汇总测试。新增测试验证空审核人不代填、行动分歧不混入结构计数、备注不重编码时点、重复案例拒绝以及备注转义。原始提交与归档逐字节一致，原 60 例包仍通过工程哈希核验；这些均不改变人工未通过裁定。

从项目根目录运行：

```sh
python3 -m trading_strategy.price_action_dual.qa.formal_review_v3 ingest --out trading_strategy/hierarchical_out/price_action_v3_formal60_v2 --response /Users/liuhongchuan/Downloads/price_action_v3_formal60_review.json
python3 -m trading_strategy.price_action_dual.qa.summarize_formal_feedback_v3 --packet-root trading_strategy/hierarchical_out/price_action_v3_formal60_v2 --response-dir trading_strategy/hierarchical_out/price_action_v3_formal60_v2/responses/44ed5c9e66b8046f
python3 -m unittest trading_strategy.price_action_dual.qa.test_summarize_formal_feedback_v3 trading_strategy.price_action_dual.qa.test_formal_review_v3 trading_strategy.price_action_dual.qa.test_protocol_v3 trading_strategy.price_action_dual.qa.test_structure_factor_v3 trading_strategy.price_action_dual.test_core -q
```

这是反馈入库和计数流程，不会运行策略。`verification.json` 的 PENDING 是原包工程核验的通用状态；本次提交的人工作业裁定以对应 `responses/44ed5c9e66b8046f/assessment.json` 为准，不能把工程 VERIFIED 当成人工通过。
