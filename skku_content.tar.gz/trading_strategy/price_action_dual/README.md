# 周线背景与日线执行双模型

本目录是独立开发实现，不修改旧实验、正式论文裁定或 2025 确认配置。当前交付止于**结构实现、审计和 KNN+HB-RAG 机器结构确认**；不是收益实验交付，更不是实盘交易系统。

## 当前入口

- 最新研究计划：[结构图像因子研究计划 v3](LATEST_RESEARCH_PLAN.md)，配套 [机器结构确认协议](MACHINE_STRUCTURE_CONFIRMATION.md)、[任务表](research_plan_v3.json) 与 [机器证据包](../hierarchical_out/price_action_knn_hbrag_structure_confirmation_v2/index.html)。人工确认已退出门控；下一项为数据、退市、复权、成交和标签可得性审计，不是直接激活收益实验。
- 口径更正：历史 v2 报告的部分 D01-D16 PASS 是固定文案，不能当作独立测试通过；调整时长和有效量比也有已复现的问题。下列旧入口与完成数量保留为历史记录，当前放行状态以 v3 计划及其后续证据为准。
- 最新进展：[四项校准已确认与分层规则草案](../hierarchical_out/price_action_dual_blind_v3/review_submissions/c0509707db9f8a91/calibration_v1/responses/87634ca82fd1b47f/rule_draft_v1.md)。2026-08-28 上传答复四项均为 `ACCURATE`，已原样归档；仅允许起草规则，不代表参数获批、代码已改或60例验收通过。下一项是独立版本的解释性状态与证据台账，暂不开启试仓或收益实验。
- 原校准入口：[四案例规则校准卡](../hierarchical_out/price_action_dual_blind_v3/review_submissions/c0509707db9f8a91/calibration_v1/index.html)。本轮已收到答复，无需再次填写同一表单。
- 最新人工反馈：[原始意见分析与13个量价补图](../hierarchical_out/price_action_dual_blind_v3/review_submissions/c0509707db9f8a91/index.html)。原始通过数为趋势11/20、震荡4/20、等待14/20，尚未通过正式验收。标注语义存在歧义，不将这些数值解释为模型准确率，也不自动更改选项。
- 最新盲图验收：[60 个阶段分层案例](../hierarchical_out/price_action_dual_blind_v3/index.html)。
- 新版结构盲图归档：[Price Action Dual Explain v1](../hierarchical_out/price_action_dual_blind_explain_v1/index.html)。该包绑定只读解释层，60/60 前缀重放通过；不再等待人工验收，也不作为机器标签。
- 新版解释台账：[4 个校准案例 + 4 个反例](../hierarchical_out/price_action_dual_explain_v2/index.html)，对应的 [Markdown 记录](../hierarchical_out/price_action_dual_explain_v2/explanation_ledger.md)。
- [知识规则映射与验收边界](RULE_MAPPING.md)。
- [旧实现审计与结论更正](AUDIT_CORRECTION.md)。
- [后续实验执行协议](EXPERIMENT_PROTOCOL.md)。

## 已实现

1. 完成周线的因果确认、日线外部/内部 pivot、背景分类、水平位生命周期。
2. 趋势回踩和震荡边界失败下破的独立候选状态机；位置、突破、跟随、确认、失效分别记录。
3. KNN/HB-RAG 机器结构确认已实现并重放 60 例；二者共用严格成熟的历史结构邻居、ID、距离和权重，排除同资产与同事件，覆盖不足或类别混合时保持未确认。
4. 现金加复权份额的日频研究账户原语；下一开盘执行、挂起订单、收盘退出、计划风险上限、不依未来收益是否缺失删除持仓。
5. 32 项合成数据测试；每个实证盲图另以截断到当日的输入重建状态，检查历史不被未来改写。解释层新增 21 项逐项协议测试，联合测试共 66 项通过。
6. 原 60 例人工界面和逐例意见继续留档；新的机器包绑定代码、配置、案例、结构参考库与图表哈希，并提供逐例邻居证据台账。

## 尚未完成与不得宣称

- 机器结构确认已经通过，但真实历史邻居收益、净值、RankIC 和显著性结果没有生成；结构确认不能替代预测或交易验证。
- 尚未完成退市现金结算、异常复权来源、历史证券状态真实性和开盘成交可得性的逐项核验。现有日频状态是保守代理，不等于真实开盘可成交状态。
- 波动率目标仅实现滞后波动率约束下的新仓规模控制；尚不是完整的组合协方差估计、持续降仓和交易约束投影控制器。
- 面向结构生命周期的 KNN/HB-RAG 已有真实开发参考库；面向金融收益的标签生成、历史最佳等待/持有期诊断、每日持仓风险面板和辅助 OOD/流动性门控仍未接入。不得把结构确认写成收益预测能力。
- `execution.py` 的份额是源复权价格对应的研究份额，不是实际券商整手委托。缺失持仓保留旧估值并标记为未解决，不假定退市价格为零或按最后价格卖出。
- 旧基线的账户重算、单变量收益实验、匹配持仓数/暴露对照、安慰剂和 Holm 校正均未运行。先完成 P3 数据/执行审计和面向金融结果的 P4 检索时点审计，再运行这些实验。
- 不读取 2025 结果。2019–2024 是已看过的开发数据，不能重新称作未见测试。

## 重现命令

在项目根目录运行：

```bash
python3 -m unittest trading_strategy.price_action_dual.test_core -v
python3 -m unittest trading_strategy.price_action_dual.test_structure_confirmation -v
python3 -m trading_strategy.price_action_dual.qa.build_machine_confirmation verify
python3 -m trading_strategy.price_action_dual.qa.verify_delivery --out trading_strategy/hierarchical_out/price_action_dual_blind_v3
python3 -m unittest trading_strategy.price_action_dual.qa.test_feedback -v
python3 -m trading_strategy.price_action_dual prepare --out trading_strategy/hierarchical_out/new_blind_packet --assets 360
python3 -m trading_strategy.price_action_dual check --out trading_strategy/hierarchical_out/price_action_dual_blind_v3
```

`prepare` 只读 2015–2024 股票 OHLCV 与状态，另只读取基准的日期列，用于完成周的交易日历。它拒绝覆盖非空目录。`check` 在未验收时返回退出码 2，这是预期的阻止状态，不是计算失败。

在页面逐例审核后导出 JSON，导入冻结的命令为：

```bash
python3 -m trading_strategy.price_action_dual freeze --out trading_strategy/hierarchical_out/price_action_dual_blind_v3 --review /path/to/price_action_review_decisions.json
```

以上 `freeze` 流程是旧人工协议的历史复现入口，不再属于当前放行条件。原回答不得被程序代填，也不得迁移成机器标签；任何旧冻结状态都不授权预测实验或实盘下单。

`v1` 因拼接 dtype 核验失败中止，`v2` 为纯随机阶段的诊断包，遗漏 READY 案例。`v3` 改用固定阶段配额以覆盖完整状态链，保留两版以审计抽样变化；三版均未使用后续盈亏。当前股票扫描中震荡 READY 为零，其最终入场路径只有合成单测覆盖，没有真实候选证据。

## 产物约定

| 文件 | 内容 |
|---|---|
| `index.html` | 离线人工验收界面，无外部脚本或跟踪 |
| `cases.json`、`charts/` | 60 个当日案例元数据与不含未来的图片 |
| `case_sources/` | 每例截至决策日的日线、周线、水平位生命周期 |
| `snapshots/` | 标注抽样股票的开发期输入及因果状态，不含标签 |
| `event_ledger.parquet` | 阶段变化台账，不是实际成交记录 |
| `data_audit_by_asset.csv` | 缺失、无效 OHLC、状态未知、上市退市边界等 |
| `legacy_audit.json` | 旧代码问题的可复现计数，不重写原始结果 |
| `artifact_manifest.json` | 代码、配置、输入与图表来源哈希 |
| `implementation_status.json` | 实际完成范围、未解决事项与实验禁行状态 |

本轮没有实际成交，因此不生成虚构的持仓台账或回测图。结构邻居证据已经生成，但仅记录结构生命周期；收益邻居和持仓结果须在后续数据与检索审计通过后生成。

## 历史人工反馈归档

`qa.ingest_feedback` 将上传记录按内容哈希归档至 `review_submissions/`，保持原文件和所有选项不变；生成逐例对照、原门槛检验和截至原决策日的量价补充图。它不调用 `freeze`，不新增实际交易信号，也不访问未来收益。补图属于证据展示，不是已经生效的模型改版。

```bash
python3 -m trading_strategy.price_action_dual.qa.ingest_feedback --packet trading_strategy/hierarchical_out/price_action_dual_blind_v3 --review /Users/liuhongchuan/Downloads/price_action_review_decisions.json
```

四案例校准使用单独的响应类型与哈希，不能提交给原正式 `freeze` 接口。即使全选“转述准确”，也只允许继续起草新规则；不实施试仓、量能阈值、行业门控，不授权收益实验。CLI `qa.build_calibration ingest` 会原样归档新意见并输出语义校准状态，不改原始60例记录。

```bash
python3 -m unittest trading_strategy.price_action_dual.qa.test_calibration -v
node --test trading_strategy/price_action_dual/qa/calibration_logic.test.cjs trading_strategy/price_action_dual/qa/calibration_ui.test.cjs
```

页面逻辑在内存 DOM 中测试，未访问真实浏览器、真实本地存储或网络；不等于已完成真实浏览器端到端测试。
