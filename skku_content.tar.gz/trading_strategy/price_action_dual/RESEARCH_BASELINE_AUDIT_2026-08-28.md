# 研究计划 v3 的基线核查

日期：2026-08-28。范围：只读代码、既有开发台账、Parquet 元数据和合成反例。本轮未读旧收益列的数值、未读 2025 结果、未运行真实预测或交易回测；没有修改旧实验。

## 结论口径修订

此前“10 项通过、0 项失败”的报告是生成器输出，不足以证明 D01-D16 所要求的独立性质。保留原报告作为历史产物，最新计划将相应结论标为需要重新验证。本文不把缺测试自动解释为模型无效，也不把现有单元测试数量解释为金融预测有效性。

## 直接复现的问题

| ID | 证据 | 观察 | 研究影响 |
|---|---|---|---|
| A01 | `qa/v2_gate_audit.py::_tests` 的 AST | D03/D05/D06/D12/D13/D14/D15 的 status 直接为字面量 PASS | 原报告中的七项不能作为独立自动验证证据 |
| A02 | `_adjustment_state` 输入 `[100,110,108,106]`，ATR=2 | 深度=2 ATR、回撤比例=0.4，但时长=0；应为距最高收盘价 2 个交易间隔 | 关键调整过程特征错误；现有 60 行台账中 40 个非空时长均为 0 |
| A03 | `_prior_relative_volume` 输入前 20 日有效量=100，当前量=200、bar_valid=false | 返回 2.0 | 当前无效条没有被拒绝，可错误显示正常量价证据 |
| A04 | `structure_fact` 输入 INVALIDATED、旧 break/confirmation 时间和 BACKGROUND_CHANGED | 返回 CONFIRMED_EVENT | 可防守边界未处理：历史已确认事实可能覆盖当前失效；这是合成反例，不声称 60 例均发生该问题 |
| A05 | 当前代码哈希与 feature_ledger.implementation_hash 对比 | 不相等，见下表 | 历史包无法证明当前代码行为；需新绑定和重生成 |
| A06 | v2 四维页面 HTML 和 `_record_view` | 页面没有嵌入图或源图链接；未传递完整结构特征；可见摘要没有完整时点/位置证据 | 不能据此要求用户充分判断结构、调整和时点；先补展示 |

小型反例在当前生产函数上运行；没有改变这些函数的行为。

## 源码检查发现的进一步缺口

- `structure.py::setup_states` 只有 R/R 合格时才写 `confirmed_time`；空间不足时记 INVALIDATED。展示层将 confirmed 与 eligibility 分开，并未从事件源头完成解耦。
- `qa/build_factor_protocol_v1.py::ingest` 归档回答与格式校验，但没有产生独立语义批准记录；`retrieval_readiness.py` 等待一个不会由该导入路径写出的 `SEMANTIC_REVIEW_PASSED`。需定义明确的人工裁定状态机，不能让完整表单自动批准模型。
- `qa/retrieval_readiness.py::_schema` 用无列投影的 `pd.read_parquet(path)` 载入旧面板，却固定记录 `outcome_fields_read=false`。Parquet schema 中实际有 `fwd_return_* / fwd_mfe_* / fwd_mae_*`。可确认读取实现与声明不一致；没有证据表明它进行了收益选择或参数调整。
- 旧 CSV 不含某些键，并不意味着底层缺数据。现有 360 个 daily 快照均为候选数据源；至少已检查的快照 schema 有 date/asset/event_id/weekly_context/model/stage。需重建带 v2 特征的事件库，不可松散拼接旧收益。
- `v2_gate_audit.py` 的追加测试在已经构建好的日线状态上截断特征，不能独自替代原始数据到 pivot、周线、事件的端到端前缀测试。
- 现有量比实现是前 20 个交易行均需有效的滚动中位数，与文案“前 20 个有效观测”在缺失/停牌情况下不同，定义需明确。

## 数据范围

| 项目 | 核查值 | 证据性质 |
|---|---:|---|
| v2 案例 | 60 | 已生成 CSV 计数 |
| v2 标的 | 56 | 已生成 CSV 唯一资产数 |
| 案例截止日 | 2019-04-09 至 2024-12-25 | 不是全部源数据时间范围 |
| daily 快照文件 | 360 | 路径枚举 |
| daily 快照行数 | 625,210 | Parquet metadata 汇总 |
| 子样本审计表范围 | 2015-01-05 至 2024-12-31 | 审计 CSV 的 start/end 汇总 |
| 有效股票日 | 609,886 | 既有审计 CSV 汇总，不是本轮重新认证 |
| 证券状态未知股票日 | 12,610 | 同上，需保留未知状态 |
| 开发期内退市标的 | 10 | 同上，不等于退市收益结算已验证 |
| 上市前/退市后行 | 0 / 0 | 同上，不证明整体股票池没有幸存者偏差 |
| 旧结构因子面板 | 58,200 行 | 仅检查 Parquet schema 与 metadata |

360 只股票是已保存的开发子样本，不是 2015-2024 时点全 A 股股票池。不能以这些计数主张全市场覆盖达标。

## 版本证据

| 对象 | SHA256 / 包标识 |
|---|---|
| v2 台账记录的代码 | `be9b1db5a780ef8465e2086c33a99356dc37e115279c61dd68503e2a86649408` |
| 当前 structure_factor_v2.py | `c5c6029dc5fcdb179a5397b79e950e07bcdc5c97e5e66c8330689d9249e940b0` |
| feature_ledger.json | `b5df3c6e3820538a2245b3ca7a46b0c786f8b408557e9e3b43f5580403c99a65` |
| v2 四维协议 | `034ed4bef05e2c8711fb246a1d441fdce211882af718f2891829b1d4810ddd48` |
| 源盲图包 | `476316d6aa482ab5b32fc40e55f6190643835d64837f680f3cdfb04ff41f75f0` |

## 本轮没有完成的事项

- 没有修复 A01-A06 或重新生成台账。
- 没有将旧意见自动拆成新的四维回答。
- 没有生成标签、正式邻居覆盖、RankIC、净值或收益显著性。
- 没有将计划阶段的技术核查当作新的正式结构验收。

下一步按 [最新研究计划](LATEST_RESEARCH_PLAN.md) 的 P0 执行。

## 可追溯来源

- [因子实现](qa/structure_factor_v2.py)、[门控审计生成器](qa/v2_gate_audit.py)、[原结构状态机](structure.py)。
- [四维协议生成器](qa/build_factor_protocol_v1.py)、[检索就绪度生成器](qa/retrieval_readiness.py)。
- [v2 特征面板](../hierarchical_out/price_action_factor_v2_feature_audit_r1/feature_panel.csv)、[v2 特征台账](../hierarchical_out/price_action_factor_v2_feature_audit_r1/feature_ledger.json)。
- [子样本数据审计](../hierarchical_out/price_action_dual_blind_explain_v1/data_audit_by_asset.csv)、[旧门控报告](../hierarchical_out/price_action_factor_v2_feature_audit_r1/gate_audit_v1/gate_audit.json)。
