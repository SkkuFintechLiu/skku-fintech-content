# v4：父级回撤、日线阶段与关注意图修订

## 当前交付

[打开新版图文对照](../hierarchical_out/price_action_v4_semantic_repair_v1/index.html)。原 60 例、58 只标的和原截止日均保留，范围为 2019-01-31 至 2024-12-13。本轮是已经看过案例的解释性修订，不是新正式盲测，也不是事件级预测面板。

新代码为 [structure_v4.py](structure_v4.py)。旧 v3 检测器、正式包、原始人工回答及 19/17/14、时点 46/60 的未通过裁定未修改。量价、自动观察名单、KNN/HB-RAG、收益实验及 2025 数据访问均未启用。

## 1. 父级回撤与局部反弹分开

父级定义为：在事件进入关注区当时，已经确认的最近周线高点，以及发生在该高点之前、价格低于高点的最近确认周线低点。无事件时以当前截止日取参考。这是一个明确、可复算的周线参考，不宣称识别“全历史最重要的波段”或最优锚点。锚点选择的语义仍待复核，不能把其效果提前写成结论。

- `parent.reference_frozen_at`：该事件的锚点冻结日；后续才确认的周线 pivot 不替换该事件的参考。
- `parent.high/low`：分别保存价位、所属周结束日、确认后可用时间及匹配到的实际日线极值日期。
- `parent.peak_to_current_pct`：`max(0, 1 - 当日收盘/参考高点)`，表示当前距父级峰值回落，不是策略最大回撤。
- `parent.peak_to_trough_pct`：参考峰值发生日之后至截止日的最低价回落；排除峰值当日内高低顺序不明的路径。期间有缺价时不报告完整低谷统计。
- `parent.advance_retraced_fraction`：`max(0, 高点-收盘)/(高点-先前低点)`，允许超过 100%，不截断以掩盖下破。
- `parent.rebound_from_trough_pct`：最低价至当前收盘的反弹；不等于趋势反转。
- `local_event_window`：保留旧关注区起点之后的局部回撤与年龄，显式标注 `ZONE_TO_CUTOFF_ONLY`。

缺锚点、当前价格无效或无法定位来源时标为 UNKNOWN/空值，不以零代替。父级低点是结构参考，不自动充当可成交止损。没有加入“回撤超过多少就必然失败”的新阈值。

本轮 25/60 例同时存在“局部回撤为零”和“父级峰值至当前仍有回落”。这是字段范围差异的描述，不是因子收益或有效性证据。

## 2. 周线、日线及突破对象分开

`weekly.background/available_at` 只使用原交易日历下已完成周线。`daily.external_structure` 保留以确认外部高低点形成的日线结构；`daily.local_reaction` 单列内部突破、跟随、失效或尚无确认事件。局部突破不自动确认周线趋势反转。

`break_objects_today` 与 `break_objects_at_event` 分别记录当前日和原突破日的内部高/低点、日线外部高/低点、周线高/低点或周箱上/下沿。每项保留参考值、来源、可用时点、观察日、收盘关系及是否当日跨越并满足实体位移。

突破对象严格取观察日之前已确认的参考，沿用原 `0.1 ATR` 缓冲及 `0.5 ATR` 实体位移定义。`CLOSE_BEYOND` 不等于当日新突破，`WICK_ONLY` 不等于收盘突破；周箱仍需区分其背景及日线行为。源事件与原触发价核对成功后才写 `event.break_object=INTERNAL_HIGH`。

原目标已低于当前收盘时如实标注空间已耗尽，不自动换成更远目标。原样保留结构与执行的边界。

## 3. 执行与关注分开

`attention.execution_action=NO_TRADE` 与 `position_intent=NONE` 始终保持，理由是研究门控关闭，不是预测以后会下跌。新增 `review_attention` 仅为待人工确认的解释性分类：

| 分类 | 本版明确条件 | 不代表什么 |
|---|---|---|
| UNKNOWN | 当前价格或证券状态未核实 | 不冒充回避或安全 |
| AVOID_NEW_LONG | 周线/日线外部 DOWN、收盘跌破周线下界及原缓冲、低于父级参考低点，或记录了保护位/收回/突破跟随失败之一 | 不生成卖单、不删股票或既有持仓 |
| WATCH_FOR_REVIEW | 无上述风险；局部跟随确认且旧关注为 WATCH，日线外部为 UP/RANGE，父级高低参考均可用 | 仅值得检查，不是买入条件，也未证明风险收益合格 |
| NOT_QUALIFIED_FOR_WATCH | 其余条件尚不完整 | 当前不具明确关注资格，不宣称没有未来上涨机会 |

这些是本次修订提出的语义定义，不是已经获得人工批准的筛选条件。`human_approved=false`、`watchlist_filter_enabled=false`。特别是“日线外部 TRANSITION 暂不赋 WATCH”是明确披露的保守工程定义，不由后续收益优化而来，仍可在语义复核中被否定。

本轮对应 2 例待复核关注、25 例回避新多头、33 例尚未取得关注资格；不把这组分布解释成选股覆盖率、获利概率或风险控制收益。

## 4. 三个案例的变化

1. [F-TREND-01](../hierarchical_out/price_action_v4_semantic_repair_v1/cases/F-TREND-01.html)：局部窗口回撤仍为零，但距父级峰值回落 30.36%，峰值至之后低谷回落 43.48%，父级推进回吐 51.52%。显示“日线过渡 + 内部向上突破已有跟随”，关注状态为“尚未取得关注资格”，不把局部反弹直接解释成父级修复。
2. [F-RANGE-02](../hierarchical_out/price_action_v4_semantic_repair_v1/cases/F-RANGE-02.html)：已完成周线背景仍 RANGE；日线内部高点突破已经发生，而周箱上沿仅影线越过。新增表格明确不同对象，保留原中点目标空间已耗尽的事实。
3. [F-WAIT-07](../hierarchical_out/price_action_v4_semantic_repair_v1/cases/F-WAIT-07.html)：周线 DOWN、日线 DOWN、低于父级低点及周线下界，显示“当前回避新多头”；“不交易”单独展示，不再由“等待组”暗示值得等买点。

## 5. 工程验证与限制

- 本轮完整命令共通过 81 项测试：14 项新增 v4 因果/语义单元测试、8 项实际产物离线测试，以及原有 59 项边界/反馈测试。自动测试不是人工验收。
- 60 例重新生成字段与图片，并对每例前 1、前 5 个观测的截止切片比较，共 120 次 v4 前缀一致性检查。它检查新增解释层，不替代原始行情/复权/交易状态审计。
- 新增单元测试覆盖未来追加、周线不可提前见、pivot 延迟、事件冻结锚点、父级与局部脱钩、缺失数据、突破对象、三种关注状态不产生交易及无目标替换。
- 所有图用静态 HTML 的真实图片路径，不依赖 JavaScript 初始化或源模板占位符。离线验证页面链接、图片与原回答保真；未声称完成真实浏览器交互测试。
- 图片均解码，抽查代表案例的版式和时间线，不声称完成 60 例人工语义验收。图上圆圈为极值发生，方块为确认可用，父级参考横线从确认时点开始。
- 本轮只覆盖这三项修订的相关工程性质，不新宣称 D01-D16 所有模块完成。原数据、退市、交易与检索审计仍保持原门槛。

工程输出：[汇总](../hierarchical_out/price_action_v4_semantic_repair_v1/summary.json)、[字段](../hierarchical_out/price_action_v4_semantic_repair_v1/records.json)、[文件及代码哈希](../hierarchical_out/price_action_v4_semantic_repair_v1/manifest.json)、[核验](../hierarchical_out/price_action_v4_semantic_repair_v1/verification.json)。

下一步仅确认新增的父级锚点、日线分层与关注语义，不重填未变化的旧表，也不据旧例重复通过宣布泛化。新规则冻结后再按原每类 18/20、全部时点清晰的门槛安排正式验收；震荡 READY 无样本的旧覆盖缺口尚未解决。

## 复现

```sh
python3 -m trading_strategy.price_action_dual.qa.build_semantic_v4 verify --out trading_strategy/hierarchical_out/price_action_v4_semantic_repair_v1
PRICE_ACTION_V4_REPAIR_DIR=trading_strategy/hierarchical_out/price_action_v4_semantic_repair_v1 python3 -m unittest trading_strategy.price_action_dual.qa.test_semantic_v4_artifacts trading_strategy.price_action_dual.test_structure_v4 -q
```

重新生成须使用新的空目录，避免覆盖既有图证及回答；CLI 为 `build --source <原正式60例目录> --out <新目录>`。
