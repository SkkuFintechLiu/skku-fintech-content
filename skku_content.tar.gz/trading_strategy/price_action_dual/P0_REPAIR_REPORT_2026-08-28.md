# P0 修复报告：结构图像因子 v3

## Material Passport

- Origin Skill: academic-research-suite / experiment-agent
- Origin Mode: run + validate
- Origin Date: 2026-08-28
- Verification Status: VERIFIED for feature-only repair artifact; no prediction or economic result was generated.
- Version Label: P0_repair_v3
- Allowed data: existing 2015-2024 development snapshots and 60 as-of case sources only; no 2025 access.

## 修复范围

| 问题 | v3 修复 | 验收 |
|---|---|---|
| 调整时长恒为零 | 使用实际收盘最高点最后一次出现的位置，而非 running-high 平台的末端 | `[100,110,108,106]`、ATR=2 得到 2 个交易间隔和 2 ATR 深度 |
| 无效 bar 仍有量比 | 当前 bar 必须有效、成交量正；基准为其前 20 个有效成交量观测 | 当前无效返回空值；中间无效观测不破坏前 20 个有效观测计算 |
| 历史确认与当前有效混淆 | 独立字段记录 `historical_event_status`、`current_event_status`、`event_active`、确认来源和失效时间 | BACKGROUND_CHANGED 后保留历史跟随确认，但当前状态为 `INACTIVE_AFTER_INVALIDATION` |
| 未来检索入口不清 | 新增 metadata-only 成熟邻居预检，严格 `reference date < query date` 且 `label_end_date < query date`、事件去重 | 合成表中剔除未来和未成熟行，只保留合法唯一事件 |
| 产物验证误报 | 禁止字段按 `_` token 精确检查，不再把 `volume_data_coverage` 误报为 RAG | v3 台账核验通过 |

旧 `structure.py` 与旧 v2 台账没有被改写。`structure_v3.py` 是独立的事实/当前状态适配层；它不改变旧事件检测结果，也不宣称已经完成正式结构验收。

## 自动验证

- `54` 项测试通过：原结构核心、v2 回归、协议与新增 v3 反例测试。
- 新台账包含 `60` 个原截止日案例；`12` 个案例的调整时长现在为非零值，说明旧“全部为零”的编码错误已被实际修复。
- 新台账只含结构、位置、调整和量价字段；无收益、MFE、MAE、标签、KNN、RAG、评分或订单字段。
- 产物哈希、源盲图包哈希、记录数和只读契约均已通过验证。

## 仍然阻断的事项

- 当前 60 行台账不是事件级横截面面板，尚缺 `date/event_id/phase/model/stage` 的完整每事件记录与 `label_end_date`。
- 没有运行 KNN/HB-RAG，没有读取标签或收益结果，也没有生成任何订单。
- 四维语义复核、正式 60 例结构验收、数据/退市/复权/成交审计仍未完成。

## 产物

- [v3 状态适配层](structure_v3.py)
- [v3 因子台账实现](qa/structure_factor_v3.py)
- [成熟邻居元数据预检](qa/retrieval_preflight_v3.py)
- [v3 自动测试](qa/test_structure_factor_v3.py)
- [v3 特征台账](../hierarchical_out/price_action_factor_v3_repair_audit/feature_ledger.json)
- [v3 特征面板](../hierarchical_out/price_action_factor_v3_repair_audit/feature_panel.csv)
- [产物核验](../hierarchical_out/price_action_factor_v3_repair_audit/artifact_verification.json)
- [检索就绪度](../hierarchical_out/price_action_factor_v3_repair_audit/retrieval_readiness/retrieval_readiness.json)

下一步是 P1：用 v3 事实字段制作八例的完整周线/日线/量价时点复核包，再由人工确认新增语义。之后才重建事件级面板。
