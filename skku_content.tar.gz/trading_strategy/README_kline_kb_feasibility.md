# K线图像/数值“知识库检索增强概率模型”可行性验证（Python MVP）

这个小脚本用于快速验证你的论文观点是否“跑得通”：

- 日线窗口 **L=60**
- 预测地平线 **H=3**
- **ATR 屏障三分类**：TP / SL / None
- 新增一组“**博弈力度**”特征，用来近似缠论里的多空推进、阻力、量价配合与结构位置
- 输出：
  - 三分类概率（用于触发概率、条件胜率、期望盈亏等）
  - 3日对数收益 **分位数**（近似收益分布）
- “知识库”=训练集样本库；推理时对每个样本检索 top-k 相似窗口，融合邻居统计再预测
- 相似度空间支持：
  - `emb`：仅embedding
  - `hybrid`：数值特征 + embedding 混合（更稳，默认）

> 说明：embedding 默认使用“形态embedding”（对窗口收盘价路径做归一化后的向量），可选叠加简易K线图像embedding（更慢）。

脚本现在会输出三层对照：

- `core`：普通技术特征 + embedding
- `force`：普通技术特征 + 博弈力度特征 + embedding
- `retrieval_aug`：在 `force` 基础上再加知识库检索统计

---

## 1) 运行（合成数据 demo，无需真实数据）

```bash
python3 kline_kb_feasibility.py --demo --out-dir kb_out_demo
```

你会在终端看到关键对比（baseline vs 检索增强），并在输出目录得到：

- `kb_out_demo/results.json`

---

## 2) 用你的真实数据运行

准备一个文件夹，里面每个资产一个 CSV，例如：

```
data/
  BTC.csv
  ES_F.csv
  AAPL.csv
```

CSV 必须包含列（列名大小写不敏感）：

- Date, Open, High, Low, Close, Volume

运行：

```bash
python3 kline_kb_feasibility.py \
  --data-dir ./data \
  --out-dir kb_out_real \
  --L 60 --H 3 \
  --atr-n 14 \
  --tp-m 2.0 --sl-n 1.0 \
  --k 20 \
  --sim-space hybrid
```

---

## 3) 可选：启用简易K线图像 embedding（更慢）

需要 Pillow（脚本会用它把matplotlib图读回为灰度数组）。

```bash
pip install pillow --break-system-packages
python3 kline_kb_feasibility.py --demo --use-image-embedding --img-size 32
```

---

## 4) 输出如何解释（你要的“可行性证据”）

终端会打印类似：

- `cls_baseline.test.f1_macro`
- `cls_force.test.f1_macro`
- `cls_retrieval_aug.test.f1_macro`
- `cls_core.test.logloss`
- `cls_force.test.logloss`
- `cls_retrieval_aug.test.logloss`
- `q_core.test.pinball_0.5`
- `q_force.test.pinball_0.5`
- `q_retrieval_aug.test.pinball_0.5`

经验判断：

- `force` 优于 `core`：支持“博弈力度”确实包含可总结的规律
- `retrieval_aug` 优于 `force`：支持“相似博弈局面可以从知识库复用”
- 分位数 pinball loss 下降、cover90 更接近 0.90：支持“收益分布预测更可靠”

---

## 5) 统计检验与对比图（推荐用于论文）

### Bootstrap 显著性检验（paired bootstrap）

对同一测试集做配对 bootstrap，估计 `ΔMacro-F1 = retrieval_aug - force` 的均值、标准差与 95% CI，并输出直方图：

```bash
python3 kline_kb_feasibility.py \
  --data-dir ashare_data \
  --out-dir kb_out_ashare_bootstrap \
  --bootstrap 1000
```

产物：

- `kb_out_ashare_bootstrap/bootstrap_summary.json`
- `kb_out_ashare_bootstrap/plots/bootstrap_delta_f1.png`

### k 扫描曲线（证明不是碰巧选了 k）

```bash
python3 kline_kb_feasibility.py \
  --data-dir ashare_data \
  --out-dir kb_out_ashare_bootstrap \
  --k-sweep 1,5,10,20,50
```

产物：

- `kb_out_ashare_bootstrap/k_sweep.json`
- `kb_out_ashare_bootstrap/plots/k_sweep_f1.png`

---

## 5) 后续论文级别增强（你下一步可以做的）

1. 把 embedding 替换成 CNN/ViT（对K线图像做对比学习预训练）
2. 检索从 sklearn KNN 换成 FAISS（更快更大规模）
3. 融合器从“邻居统计 + Logistic”升级为 attention 融合网络
4. 三分类概率做温度缩放校准，报告 ECE / reliability diagram

---

## 6) 当前“博弈力度”特征

脚本里加入的近似特征包括：

- `body_pct`：实体长度占整根K线比例
- `signed_body`：带方向的实体强度
- `upper_wick_pct` / `lower_wick_pct`：上影/下影阻力与承接
- `close_pos_in_bar`：收盘在K线区间中的位置
- `atr_pct` / `range_to_atr`：波动强弱与当日冲击力度
- `trend_slope_10` / `trend_slope_20`：短中期推进斜率
- `drawdown_20`：相对20日高点回撤
- `distance_to_breakout_20`：离突破20日高点还有多远
- `channel_pos_20`：当前在20日通道中的位置
- `efficiency_10`：10日趋势效率
- `volume_price_force`：量价共振强度

如果你想只跑旧版对照，可以加：

```bash
python3 kline_kb_feasibility.py --demo --disable-game-force
```
