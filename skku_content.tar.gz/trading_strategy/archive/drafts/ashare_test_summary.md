# Ashare 实测摘要

## 数据来源

- 使用 `mpquant/Ashare` 的 `get_price()` 下载日线 OHLCV。
- 本次测试抓取了 10 个 A 股/指数代码，每个代码约 2600 根日线。

## 下载命令

```bash
python3 ashare/download_ashare_data.py \
  --out-dir ashare_data \
  --count 2600
```

## 验证命令

```bash
python3 kline_kb_feasibility.py \
  --data-dir ashare_data \
  --out-dir kb_out_ashare \
  --max-assets 10 \
  --max-samples 15000 \
  --k 20 \
  --sim-space hybrid \
  --gbr-estimators 80 \
  --gbr-depth 3 \
  --gbr-lr 0.06
```

## 关键结果

- `cls_core.test.f1_macro = 0.2864`
- `cls_force.test.f1_macro = 0.2936`
- `cls_retrieval_aug.test.f1_macro = 0.3434`

- `cls_core.test.logloss = 0.9203`
- `cls_force.test.logloss = 0.9229`
- `cls_retrieval_aug.test.logloss = 1.0460`

## 初步结论

- “博弈力度”特征相对 `core` 带来正向增益：`+0.0072`
- 检索增强相对 `force` 带来更明显增益：`+0.0498`
- 在这批真实 A 股/指数数据上，研究主张比合成数据更容易被验证出来

## 结果文件

- 数据目录：`ashare_data/`
- 实验结果：`kb_out_ashare/results.json`

