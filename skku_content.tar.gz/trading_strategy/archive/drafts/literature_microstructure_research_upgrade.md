# 市场微观结构、K线结构与 KNN+HB-RAG：文献学习及研究升级

## 1. 学习目标与结论先行

本笔记回答三个问题：市场微观结构文献能够为本文提供什么理论基础；日频 K 线能够观测到什么、不能观测到什么；这些边界如何转化为下一轮可证伪的实验。

结论是：本文不能把日频 K 线称为订单流或限价订单簿的重建。更严谨的定位是，OHLCV 是交易制度、信息到达、流动性供给与订单流共同作用后的低频聚合结果。实体、影线、区间、收盘位置和成交量可以构成价格形成结果的结构代理，但不能单独识别主动买卖方向、撤单、盘口深度、信息不对称或知情交易。KNN+HB-RAG 的作用也不是恢复这些不可观测机制，而是在一个明确的低频状态空间中估计历史条件分布。

因此，当前最稳健的研究主张仍是：KNN 与 HB-RAG 提供统计显著的横截面排序信息；“博弈力度”是操作性命名，不是已被识别的微观结构因果变量；从排序到绝对买卖和退出的稳定映射尚未确认。

## 2. 来源筛选规则

### 2.1 纳入主证据链

| 文献 | 证据层级 | 可支持的内容 | 不能据此声称的内容 |
|---|---|---|---|
| Madhavan (2000), *Market Microstructure: A Survey* | 同行评审综述 | 微观结构研究价格形成、市场设计、透明度及其与其他金融领域的联系 | 日频蜡烛图可以识别具体订单簿机制 |
| Biais, Glosten, and Spatt (2005) | 同行评审综述 | 订单处理、库存与逆向选择成本，以及制度、策略行为和福利之间的关系 | 任一 OHLCV 特征可被唯一解释为信息不对称 |
| Cont, Kukanov, and Stoikov (2014) | 同行评审实证 | 高频短区间内，OFI 与价格变化近似线性，价格冲击系数与深度负相关；成交量关系更噪声化 | 日成交量等于 OFI，或日线量价变量可替代盘口数据 |
| Amihud (2002) | 同行评审实证 | 可用日收益绝对值/成交额构造低频非流动性代理 | 该代理等于买卖价差、市场深度或订单流毒性 |
| Corwin and Schultz (2012) | 同行评审方法 | 可从日高低价构造低频买卖价差估计量 | 估计价差等于真实逐笔有效价差 |
| Lo, Mamaysky, and Wang (2000) | 同行评审实证 | 主观技术形态可被算法化；应比较条件与无条件收益分布并使用 bootstrap/Monte Carlo | 形态有信息必然意味着可交易超额收益 |
| Tsinaslanidis and Zapranis (2016) | 学术专著 | 规则化形态识别、统计评估与动态时间规整可形成统一流程 | 技术分析能普遍稳定盈利 |
| Velay and Daniel (2018) | 预印本 | CNN/LSTM 可用于图表形态识别，适合作为模型家族对照 | 可作为高等级金融实证或经济机制证据 |
| Said et al. (2026) | 同行评审综述 | 微观结构的核心主题包括流动性与价格发现、信息不对称、市场设计、高频交易和市场碎片化；新兴市场与跨市场比较仍有缺口 | 其文献计量结果直接证明本文因子有效 |
| Haddad and Muir (2025) | NBER/Annual Review | “市场宏观结构”研究关键机构与持仓结构如何影响资产价格 | 它不是订单簿微观结构理论，不能与 market microstructure 混用 |

### 2.2 仅作方法启发

`A Model of Market Making and Price Impact`、半马尔可夫逐笔价格模型、条件 OFI 价格冲击等 arXiv 论文可用于扩展模型设计，但在未核实同行评审状态、样本与复现结果前，不承担主结论。ICAIF 论文集可用于寻找最新 AI 金融方法，不替代金融实证的识别与统计检验。

### 2.3 排除主证据链

ResearchGate 镜像、Wikipedia、CSDN、知乎、格隆汇、新浪和一般交易博客不用于支持学术结论；可以作为术语或实践动机线索，但引用应回到原论文。检索结果中的色谱、食品检测、荧光成像等论文属于关键词污染，与本研究无关，应删除。

## 3. 理论链路的正确写法

本文的理论链路应写成以下四层，而不是“订单流直接生成某根 K 线，所以影线等于卖压”。

1. **潜在机制层**：信息到达、交易者需求、库存约束、流动性供给和交易制度共同影响订单提交、撤单与成交。
2. **高频可观测层**：逐笔成交、报价、盘口深度、订单方向与 OFI 能更接近地刻画短期价格形成和价格冲击。
3. **低频聚合层**：OHLCV 保存价格路径的极值、终点、区间和总成交活动，但丢失事件顺序、买卖方向、撤单与深度。
4. **统计状态层**：本文把低频聚合结果编码为结构向量，再由 KNN 判别邻域状态、HB-RAG 汇总历史后续路径，估计条件分布与横截面排序。

由此得到三个可检验而非先验成立的假设：

- H1：OHLC 结构变量在常规技术特征之外具有增量排序信息。
- H2：OHLCV 低频流动性代理在 H1 之上具有增量信息，且增益在流动性较低或制度摩擦较高的样本中更强。
- H3：若获得逐笔/盘口数据，真实 OFI 与深度变量应在低频代理之上提供增量，并改善极端状态识别；若没有增量，则“博弈力度来自订单流”的机制解释不成立或只在更短周期成立。

H1 的现有证据主要是屏障分类和联合排序结果；H2、H3 尚未完成，不能在论文中写成事实。

## 4. 变量分层与命名修正

### T0：纯价格结构

`signed_body`、上下影线比例、`close_pos_in_bar`、区间、通道位置、趋势斜率、回撤、突破距离和路径效率。建议统一称为“蜡烛图结构变量”，不称为订单流变量。

### T1：日频流动性与交易活跃度代理

- Amihud 非流动性：`abs(return) / amount`，需成交额而不是仅成交量。
- Corwin-Schultz 高低价差估计：由相邻一日/两日高低价构造。
- 换手率、成交额分位、零收益日比例、成交量冲击和量价符号交互。
- 若缺少流通股本或成交额，应明确降级，不能用原始 Volume 跨股票直接比较。

### T2：逐笔成交与报价

有效价差、实现价差、报价价差、交易方向不平衡、日内实现波动、Kyle lambda 等。需要 TAQ 或等价逐笔成交报价数据。

### T3：限价订单簿

最优价位及多档深度、OFI、撤单、队列失衡与盘口恢复速度。只有这一层才能直接讨论 Cont 等文献中的订单簿供需不平衡。

论文主样本可以停留在 T0+T1；T2/T3 应作为小样本机制验证，而不是伪装成全市场已有变量。

## 5. KNN+HB-RAG 的方法定位

KNN 与 HB-RAG 不是两个竞争模型，而是同一条件分布估计过程的两个步骤：

1. KNN 在历史可得状态中确定局部参照集，并给出离散状态概率或状态边际。
2. HB-RAG 在同一邻域中汇总未来收益、MFE、MAE、尾部分位、胜率、邻居距离与有效样本量。
3. 联合因子应首先被解释为横截面排序统计量，而不是预期收益点预测。
4. OOD 拒绝应使用邻居距离、覆盖率、市场波动和流动性状态，避免在缺乏代表性邻域时强制生成绝对交易判断。

该定位与 Lo et al. 的边界一致：条件分布发生变化只能证明图形/状态具有信息，不自动证明扣除风险和成本后的交易利润。

## 6. 下一轮确认性实验

### 6.1 单变量递进矩阵

保持标签、样本、切分、KNN 参数和 HB-RAG 规则不变，只逐层增加信息：

| 模型 | 新增信息 | 主要比较 |
|---|---|---|
| M0 | 常规技术特征 | 基线 |
| M1 | M0 + T0 蜡烛图结构 | 检验 H1 |
| M2 | M1 + T1 流动性代理 | 检验 H2 |
| M3 | M2 + KNN | 邻域状态增量 |
| M4 | M3 + HB-RAG 路径统计 | 联合检索增量 |
| M5 | M4 + OOD 拒绝 | 稳健性与覆盖率代价 |
| M6 | T2/T3 数据子样本 | 检验 H3，不与全市场主结果混合 |

每个相邻版本只能改变一个信息层。主要终点为 RankIC 及 HAC-t；次要终点为分层单调性、最高组绝对收益、覆盖率、换手、成本后收益和最大回撤。分类 Macro-F1 与 LogLoss 保留为机制性辅助结果，不再作为选股研究的唯一主结果。

### 6.2 统计检验

- 日度 RankIC 使用 Newey-West/HAC 标准误，并报告均值、t 值、正 IC 比例和 ICIR。
- 相邻模型的 RankIC 差使用以日期为块的 bootstrap，不能按窗口独立重采样。
- 分层收益使用日历时间块 bootstrap，并同时报告经济量级与置信区间。
- 多个代理、周期和市场并行检验时，使用 Romano-Wolf 或 Benjamini-Hochberg 控制多重比较。
- 使用条件随机化或日期内置换检验，确认增量不是结构预筛和市场共同波动的机械结果。
- 报告交易覆盖率；零交易不能被解释为零风险盈利。

### 6.3 异质性与机制检验

- 按流动性、规模、波动、涨跌停暴露、市场状态和长假间隔预先分组。
- 检验 T1 增量是否在低流动性组更强；这是比“A股散户多所以有效”更直接的机制证据。
- A 股与美股差异应先报告效应量及交互项，再讨论制度解释；不能由“一边显著、一边不显著”直接推出两边显著不同。
- 2020 年疫情状态作为 OOD 案例，不再用于继续调阈值；新的确认期必须保持未见。

## 7. 论文重组建议

### 总论文

研究对象是“低频结构状态的横截面信息含量与风险受限映射”。主线依次为：低频状态表示、历史条件分布、排序有效性、OOD 与风险控制边界。

### 小论文 1：低频结构代理是否有增量信息

只比较 M0、M1、M2，研究蜡烛图结构与低频流动性代理。核心贡献是表示层和制度/流动性异质性，不使用“重建订单流”表述。

### 小论文 2：KNN+HB-RAG 条件分布与排序

比较 M2、M3、M4、M5。主结果是严格时间外 RankIC、邻域代表性、校准与 OOD 覆盖率，不以生成式语言模型为卖点。

### 机制附录或后续论文

使用 WRDS TAQ 或中国逐笔盘口子样本比较 T1 与 T2/T3。如果真实 OFI 能解释 T0/T1 的增量，才可把“博弈力度”进一步连接到订单流机制。

## 8. 当前必须删改的结论

- 将“影线反映未被满足的订单压力”改为“影线记录区间极值相对收盘的回撤，可能由多种交易过程共同产生”。
- 将“重建订单流信息”改为“构造低频价格形成结果的结构代理”。
- 将“美股更有效所以信息已充分反映”改为“当前样本未检测到增量；制度效率只是待检验解释”。
- 将“P=1.0”统一改为正确方向的经验 p 值或支持概率，避免把 bootstrap 中 `Pr(delta>0)` 写成 p 值。
- 将“结构因子可预测性基础已经成立”改为“屏障分类增量不能替代选股 RankIC 和交易映射检验”。
- 将“趋势是订单流持续性的结果”降格为候选机制；当前 ACF 和日频数据只能证明部分波动状态持续，不能识别其订单流来源。

## 9. 核心参考文献

1. Madhavan, A. (2000). Market microstructure: A survey. *Journal of Financial Markets*, 3(3), 205-258. https://doi.org/10.1016/S1386-4181(00)00007-0
2. Biais, B., Glosten, L., & Spatt, C. (2005). Market microstructure: A survey of microfoundations, empirical results, and policy implications. *Journal of Financial Markets*, 8(2), 217-264. https://doi.org/10.1016/j.finmar.2004.11.001
3. Cont, R., Kukanov, A., & Stoikov, S. (2014). The price impact of order book events. *Journal of Financial Econometrics*, 12(1), 47-88. https://doi.org/10.1093/jjfinec/nbt003
4. Amihud, Y. (2002). Illiquidity and stock returns: Cross-section and time-series effects. *Journal of Financial Markets*, 5(1), 31-56. https://doi.org/10.1016/S1386-4181(01)00024-6
5. Corwin, S. A., & Schultz, P. (2012). A simple way to estimate bid-ask spreads from daily high and low prices. *The Journal of Finance*, 67(2), 719-760. https://doi.org/10.1111/j.1540-6261.2012.01729.x
6. Lo, A. W., Mamaysky, H., & Wang, J. (2000). Foundations of technical analysis: Computational algorithms, statistical inference, and empirical implementation. *The Journal of Finance*, 55(4), 1705-1765. https://doi.org/10.1111/0022-1082.00265
7. Tsinaslanidis, P. E., & Zapranis, A. D. (2016). *Technical Analysis for Algorithmic Pattern Recognition*. Springer. https://doi.org/10.1007/978-3-319-23636-0
8. Velay, M., & Daniel, F. (2018). Stock chart pattern recognition with deep learning. arXiv:1808.00418. https://arxiv.org/abs/1808.00418
9. Said, B., Raza, M. W., Elshahat, A., Paltrinieri, A., & Oriani, M. E. (2026). Decoding the DNA of stock market microstructure: A comprehensive bibliometric and content review analysis. *Research in International Business and Finance*, 86, 103384. https://doi.org/10.1016/j.ribaf.2026.103384
10. Haddad, V., & Muir, T. (2025). Market macrostructure: Institutions and asset prices. *Annual Review of Financial Economics*. NBER Working Paper 33434. https://doi.org/10.3386/w33434

