# 实验结果段落（含统计检验）

在真实 A 股与指数日线数据上，本文构建了包含 10 个标的的样本池，并在统一设置（窗口长度 `L=60`，预测地平线 `H=3`，ATR 屏障三分类 TP/SL/None）下评估所提方法。实验结果显示，基础模型 `core`（普通技术特征 + 形态 embedding）的测试集 Macro-F1 为 `0.2923`；在加入“博弈力度”特征后，`force` 的 Macro-F1 提升至 `0.2999`，表明将 K 线中的实体/影线结构、趋势斜率、通道位置与量价共振等变量作为多空博弈强度的近似刻画，能够带来稳定的分类增益。进一步地，在 `force` 基础上引入知识库检索增强后，`retrieval_aug` 的测试集 Macro-F1 提升至 `0.3291`，相对 `force` 增加 `0.0292`，说明历史相似博弈局面的检索与复用对短期屏障事件预测具有显著帮助（即，博弈局面具有可复现的统计相似性）。

从概率质量看，`core` 与 `force` 的测试集 LogLoss 分别为 `0.9230` 与 `0.9257`，两者接近；而 `retrieval_aug` 的 LogLoss 上升至 `1.0389`。该结果表明，当前检索增强版本主要提升了类别判别能力，但概率校准尚未同步优化，后续需要结合温度缩放或更强融合器进一步改善概率输出质量。对于收益分布任务，`core` 与 `force` 的 `Pinball Loss@0.5` 分别为 `0.00908` 与 `0.00910`，而 `retrieval_aug` 为 `0.00921`，提示当前检索增强对事件分类更敏感，对连续收益分布的增益尚不明显。

为检验 `retrieval_aug` 相对 `force` 的提升是否具有统计显著性，本文进一步在测试集上进行配对 bootstrap（`B=1000`），得到 \u0394Macro-F1 = `retrieval_aug - force` 的均值为 `0.0291`，标准差 `0.0090`，95% 置信区间为 `[0.0109, 0.0468]`，且单侧经验 p 值为 `0.0`（在 1000 次重采样中未观察到 \u0394 ≤ 0），支持检索增强的提升并非偶然波动。

此外，为验证“检索增强不是碰巧选了某个 k”，对 `k ∈ {1,5,10,20,50}` 进行扫描：测试集 Macro-F1 在 `k=1` 时达到 `0.3577`，随后在不同 k 下保持在 `0.3291~0.3452` 区间，说明检索增强在一段 k 范围内均能提供增益，但最优 k 可能依赖市场状态与样本量。

## 图注建议

- 图 1：A 股测试集上 `core`、`force` 与 `retrieval_aug` 的 Macro-F1 对比（`kb_out_ashare_bootstrap/results.json`）。
- 图 2：A 股测试集上 `core`、`force` 与 `retrieval_aug` 的 LogLoss 对比（`kb_out_ashare_bootstrap/results.json`）。
- 图 3：配对 bootstrap 的 \u0394Macro-F1 分布（`kb_out_ashare_bootstrap/plots/bootstrap_delta_f1.png`）。
- 图 4：检索邻居数 k 的扫描曲线（`kb_out_ashare_bootstrap/plots/k_sweep_f1.png`）。

