# finshare 接入摘要

已新增 `finshare` 作为第三个数据源，主要用于补充：

- A 股历史日线 K 线
- 国内期货主连/连续合约日线

## 新增文件

- `finshare_download.py`：下载并统一导出为 CSV
- `finshare_data/`：通过 finshare 下载的样本数据

## 示例命令

```bash
python3 finshare_download.py \
  --out-dir finshare_data \
  --start 2019-01-01 \
  --end 2025-08-11
```

## 本次下载结果

- 股票：`600519.SH`, `000001.SZ`, `601318.SH`, `600036.SH`, `000333.SZ`
- 期货：`cu0`, `au0`, `rb0`, `al0`, `zn0`

共成功导出 10 个 CSV，可直接并入你的跨资产实验数据池。

## 当前状态

- `Ashare`：已完成 A 股测试
- `yfinance`：已补充海外期货与加密
- `finshare`：已补充 A 股与国内期货

跨资产联合测试的数据池已经准备完成，但当前 `kline_kb_feasibility.py` 中的 `PCA + 线性分类器 + 分位数GBDT` 组合在三类市场混合后存在数值稳定性问题，下一步建议改成更稳健的融合器或对不同市场分层标准化后再跑正式对比。

