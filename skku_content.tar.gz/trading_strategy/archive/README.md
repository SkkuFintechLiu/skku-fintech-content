# 交易策略归档

- `drafts/`：方法演进期草稿，不与当前学术正文混写。
- `generated_outputs/`：demo、smoke 和空试验目录的可再生成产物。
- `duplicate_data/cross_asset_data_v1/`：已验证逐字节包含于活动版 `cross_asset_data_v2/` 的旧数据集合。

活动研究只从 `trading_strategy/` 顶层数据目录和已登记的 `hierarchical_out/` 读取。
