# trading_strategy — 交易策略谱系

## 这是什么

**K线博弈力度显式结构化 + 知识库检索增强（HB-RAG）/ KNN** 的交易策略研究。研究问题：
将 body/wick/close-pos/trend/volume-price 等微观博弈力度特征显式结构化后，能否改善未来 H 日
ATR 屏障事件（止盈 TP / 止损 SL / 无 None）的判别，并落地为可执行的入场/过滤规则。

- 目标变量：TP/SL/None 三分类（窗口 L=60，地平线 H=3，ATR 窗口 n=14，tp_m=2.0，sl_n=1.0）
- 核心引擎：`kline_kb_feasibility.py`（特征构建 + 标签 + 检索 + 分类）、`run_calendar_split.py`（严格时间外）
- 检索/KNN 实验：`knn_experiments.py`、`run_ashare_leader.py`、`run_cross_asset_retrieval.py`、`mtf_resonance_retrieval.py`
- 策略落地：`hierarchical_structure_strategy.py`（分层结构策略 + no-trade 状态）、`structure_timing_surface.py`、`index_futures_beta_hedge.py`（股指期货 beta 对冲）、`maotai_position_poc.py`（茅台仓位 PoC）
- 历史稿件：`archive/drafts/`（与 `academic_research/manuscript` 无关，不作为当前论文证据）

## 运行入口（在 trading_strategy/ 内执行）

- 主实验 + 严格时间外验证：`python run_calendar_split.py`
- KNN 消融/扫描：`python knn_experiments.py --data-dir us_stock_data --out-dir kb_out_knn/us --bootstrap 2000`
- 分层结构策略回测：`python hierarchical_structure_strategy.py`
- 茅台仓位 PoC：`python maotai_position_poc.py`

## 数据依赖（符号链接，勿删）

- `ashare_full_data` → `../shared_data/ashare_full_data`（**含幸存者偏差，仅开发期使用，勿进入确认结论**）
- `us_stock_data` → `../shared_data/us_stock_data`
- `market_data_audit` → `../shared_data/market_data_audit`
- 自带目录：`ashare_data/`、`ashare_leader_data/`、`crypto_data/`、`cross_asset_data_v2/`、`figures/`、`data/maotai_position_poc/`、`kb_out_*/`、`hierarchical_out/`

## 产物规则

- `cross_asset_data_v2/` 是跨市场开发数据的唯一活动版本；旧版本已验证为其逐字节子集并移入 `archive/duplicate_data/`。
- `demo`、`smoke` 和空输出目录不放在活动层；需要溯源的版本保存在 `archive/generated_outputs/`。
- `hierarchical_out/` 中被学术证据登记表引用的诊断结果不得改名或删除。
- 多代校准与 KNN 消融属于探索性证据；清理前须先核对稿件和结果登记表引用。

## 诚实边界（结论定调）

- 检索增强（same-asset 时间制度复现）是跨市场最稳健贡献（A股 +0.063 / 美股 +0.064，均 P≈1.0）。
- 博弈力度特征在 A 股显著（+0.016），在美股零增量（force≈0）。
- **不是方向性 alpha，也不是行业轮动 alpha**：主效应是同标的自身历史的时间制度复现，方法价值在于
  屏障事件结构化判别 / 风险刻画 / 入场过滤。
- 宏观博弈力度（期权 PCR / 期指净持仓 / 两融）与跨市场联动仍待同窗数据验证。

## 完整性校验

`python -c "import os; print(os.path.exists('kline_kb_feasibility.py') and os.path.exists('ashare_full_data') and os.path.exists('us_stock_data'))"`

应为 `True`。若 `ashare_full_data` 等返回 False，说明符号链接未生效（跨机器拷贝后常见）——见根目录 README。
