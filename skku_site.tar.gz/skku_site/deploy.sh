#!/usr/bin/env bash
# SKKU-Fintech deploy: copy built site into webroot, install nginx config, restart.
set -e
SRC=/tmp/skku_site
DEST=/var/www/skku-fintech

echo "[deploy] copying site -> $DEST"
mkdir -p "$DEST"
rm -rf "$DEST"/*
cp -r "$SRC/site/." "$DEST/"

echo "[deploy] installing nginx config"
mkdir -p /etc/nginx/conf.d
cp "$SRC/nginx_skku.conf" /etc/nginx/conf.d/skku-fintech.conf
rm -f /etc/nginx/sites-enabled/default

echo "[deploy] testing nginx config"
nginx -t

echo "[deploy] (re)starting nginx"
if command -v systemctl >/dev/null 2>&1; then
  systemctl enable nginx >/dev/null 2>&1 || true
  systemctl restart nginx || systemctl start nginx
else
  service nginx restart 2>/dev/null || nginx -s reload 2>/dev/null || nginx
fi

echo "[deploy] DONE. webroot contents:"
ls "$DEST"
echo "[deploy] curl self-check:"
curl -s -o /dev/null -w "HTTP %{http_code}\n" http://127.0.0.1/index.html || true
