// SKKU-Fintech: nav search, active highlight, mobile drawer
(function () {
  // active link + open ancestors
  var cur = location.pathname.replace(/index\.html$/, '');
  if (cur === '' || cur === '/') cur = '/index.html';
  var links = document.querySelectorAll('#nav a');
  links.forEach(function (a) {
    var p = a.getAttribute('data-path');
    if (p && (p === cur || (cur === '/index.html' && p === '/docs/root/README.html'))) {
      a.classList.add('active');
      var el = a;
      while (el && el !== document.body) {
        if (el.tagName === 'DETAILS') el.open = true;
        el = el.parentElement;
      }
    }
  });

  // search filter
  var box = document.getElementById('navsearch');
  if (box) {
    box.addEventListener('input', function () {
      var q = box.value.trim().toLowerCase();
      links.forEach(function (a) {
        var hit = a.textContent.toLowerCase().indexOf(q) !== -1;
        if (a.parentElement) a.parentElement.style.display = hit ? '' : 'none';
      });
      document.querySelectorAll('#nav details').forEach(function (d) {
        var any = Array.prototype.some.call(d.querySelectorAll('a'), function (a) {
          return a.parentElement && a.parentElement.style.display !== 'none';
        });
        d.style.display = any ? '' : 'none';
      });
    });
  }

  // mobile drawer
  var toggle = document.querySelector('.menutoggle');
  if (toggle) {
    toggle.addEventListener('click', function () { document.body.classList.toggle('nav-open'); });
    document.querySelector('.content').addEventListener('click', function () {
      document.body.classList.remove('nav-open');
    });
  }
})();
